# JDV_J114_Pays_ENREG - Terminologies de Santé v1.10.0

## ValueSet: JDV_J114_Pays_ENREG 

 
Référentiel dérivé des pays provenant de la norme INSEE pour ENREG 

 **References** 

Ce jeu de valeurs n'est pas utilisé ici ; il peut être utilisé autre part (par exemple dans les spécifications et / ou implémentations qui utilisent ce contenu)

###  Recherche en live sur le SMT 

Indiquer un mot clé puis taper sur "enter" :

```
Requête sur le SMT
```

### Définition logique (CLD)

 

### Expansion

Expansions are not generated for retired value sets

-------

 [Description du (des) tableau(x) ci-dessus](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "JDV-J114-Pays-ENREG",
  "meta" : {
    "versionId" : "5",
    "lastUpdated" : "2025-07-02T17:04:49.110+00:00",
    "profile" : ["http://hl7.org/fhir/StructureDefinition/shareablevalueset"]
  },
  "language" : "fr-FR",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/resource-effectivePeriod",
    "valuePeriod" : {
      "start" : "2020-05-29T12:00:00+01:00",
      "end" : "2024-01-26T12:00:00+01:00"
    }
  }],
  "url" : "https://mos.esante.gouv.fr/NOS/JDV_J114-Pays-ENREG/FHIR/JDV-J114-Pays-ENREG",
  "identifier" : [{
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:oid:1.2.250.1.213.1.6.1.185"
  }],
  "version" : "20240126120000",
  "name" : "JDV_J114_Pays_ENREG",
  "status" : "retired",
  "experimental" : false,
  "date" : "2024-01-26T12:00:00+01:00",
  "publisher" : "Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris",
  "description" : "Référentiel dérivé des pays provenant de la norme INSEE pour ENREG",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "FR",
      "display" : "France (la)"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "https://mos.esante.gouv.fr/NOS/TRE_R20-Pays/FHIR/TRE-R20-Pays",
      "concept" : [{
        "code" : "99100",
        "display" : "France"
      },
      {
        "code" : "99101",
        "display" : "Danemark"
      },
      {
        "code" : "99102",
        "display" : "Islande"
      },
      {
        "code" : "99103",
        "display" : "Norvège"
      },
      {
        "code" : "99104",
        "display" : "Suède"
      },
      {
        "code" : "99105",
        "display" : "Finlande"
      },
      {
        "code" : "99106",
        "display" : "Estonie"
      },
      {
        "code" : "99107",
        "display" : "Lettonie"
      },
      {
        "code" : "99108",
        "display" : "Lituanie"
      },
      {
        "code" : "99109",
        "display" : "Allemagne"
      },
      {
        "code" : "99110",
        "display" : "Autriche"
      },
      {
        "code" : "99111",
        "display" : "Bulgarie"
      },
      {
        "code" : "99112",
        "display" : "Hongrie"
      },
      {
        "code" : "99113",
        "display" : "Liechtenstein"
      },
      {
        "code" : "99114",
        "display" : "Roumanie"
      },
      {
        "code" : "99116",
        "display" : "République tchèque"
      },
      {
        "code" : "99117",
        "display" : "Slovaquie"
      },
      {
        "code" : "99118",
        "display" : "Bosnie-Herzégovine"
      },
      {
        "code" : "99119",
        "display" : "Croatie"
      },
      {
        "code" : "99120",
        "display" : "Monténégro"
      },
      {
        "code" : "99121",
        "display" : "Serbie"
      },
      {
        "code" : "99122",
        "display" : "Pologne"
      },
      {
        "code" : "99123",
        "display" : "Russie"
      },
      {
        "code" : "99125",
        "display" : "Albanie"
      },
      {
        "code" : "99126",
        "display" : "Grèce"
      },
      {
        "code" : "99127",
        "display" : "Italie"
      },
      {
        "code" : "99128",
        "display" : "Saint-Marin"
      },
      {
        "code" : "99129",
        "display" : "Vatican"
      },
      {
        "code" : "99130",
        "display" : "Andorre"
      },
      {
        "code" : "99131",
        "display" : "Belgique"
      },
      {
        "code" : "99132",
        "display" : "Royaume-Uni"
      },
      {
        "code" : "99133",
        "display" : "Gibraltar"
      },
      {
        "code" : "99134",
        "display" : "Espagne"
      },
      {
        "code" : "99135",
        "display" : "Pays-Bas"
      },
      {
        "code" : "99136",
        "display" : "Irlande"
      },
      {
        "code" : "99137",
        "display" : "Luxembourg"
      },
      {
        "code" : "99138",
        "display" : "Monaco"
      },
      {
        "code" : "99139",
        "display" : "Portugal"
      },
      {
        "code" : "99140",
        "display" : "Suisse"
      },
      {
        "code" : "99144",
        "display" : "Malte"
      },
      {
        "code" : "99145",
        "display" : "Slovénie"
      },
      {
        "code" : "99148",
        "display" : "Biélorussie"
      },
      {
        "code" : "99151",
        "display" : "Moldavie"
      },
      {
        "code" : "99155",
        "display" : "Ukraine"
      },
      {
        "code" : "99156",
        "display" : "Macédoine du nord"
      },
      {
        "code" : "99157",
        "display" : "Kosovo"
      },
      {
        "code" : "99201",
        "display" : "Arabie saoudite"
      },
      {
        "code" : "99203",
        "display" : "Iraq"
      },
      {
        "code" : "99204",
        "display" : "Iran"
      },
      {
        "code" : "99205",
        "display" : "Liban"
      },
      {
        "code" : "99206",
        "display" : "Syrie"
      },
      {
        "code" : "99207",
        "display" : "Israël"
      },
      {
        "code" : "99208",
        "display" : "Turquie"
      },
      {
        "code" : "99212",
        "display" : "Afghanistan"
      },
      {
        "code" : "99213",
        "display" : "Pakistan"
      },
      {
        "code" : "99214",
        "display" : "Bhoutan"
      },
      {
        "code" : "99215",
        "display" : "Népal"
      },
      {
        "code" : "99216",
        "display" : "Chine"
      },
      {
        "code" : "99217",
        "display" : "Japon"
      },
      {
        "code" : "99219",
        "display" : "Thaïlande"
      },
      {
        "code" : "99220",
        "display" : "Philippines"
      },
      {
        "code" : "99222",
        "display" : "Jordanie"
      },
      {
        "code" : "99223",
        "display" : "Inde"
      },
      {
        "code" : "99224",
        "display" : "Birmanie"
      },
      {
        "code" : "99225",
        "display" : "Brunei"
      },
      {
        "code" : "99226",
        "display" : "Singapour"
      },
      {
        "code" : "99227",
        "display" : "Malaisie"
      },
      {
        "code" : "99229",
        "display" : "Maldives"
      },
      {
        "code" : "99231",
        "display" : "Indonésie"
      },
      {
        "code" : "99234",
        "display" : "Cambodge"
      },
      {
        "code" : "99235",
        "display" : "Sri Lanka"
      },
      {
        "code" : "99236",
        "display" : "Taïwan"
      },
      {
        "code" : "99238",
        "display" : "République populaire démocratique de Corée"
      },
      {
        "code" : "99239",
        "display" : "République de Corée"
      },
      {
        "code" : "99240",
        "display" : "Koweït"
      },
      {
        "code" : "99241",
        "display" : "Laos"
      },
      {
        "code" : "99242",
        "display" : "Mongolie"
      },
      {
        "code" : "99243",
        "display" : "Viêt Nam"
      },
      {
        "code" : "99246",
        "display" : "Bangladesh"
      },
      {
        "code" : "99247",
        "display" : "Émirats arabes unis"
      },
      {
        "code" : "99248",
        "display" : "Qatar"
      },
      {
        "code" : "99249",
        "display" : "Bahreïn"
      },
      {
        "code" : "99250",
        "display" : "Oman"
      },
      {
        "code" : "99251",
        "display" : "Yémen"
      },
      {
        "code" : "99252",
        "display" : "Arménie"
      },
      {
        "code" : "99253",
        "display" : "Azerbaïdjan"
      },
      {
        "code" : "99254",
        "display" : "Chypre"
      },
      {
        "code" : "99255",
        "display" : "Géorgie"
      },
      {
        "code" : "99256",
        "display" : "Kazakhstan"
      },
      {
        "code" : "99257",
        "display" : "Kirghizistan"
      },
      {
        "code" : "99258",
        "display" : "Ouzbékistan"
      },
      {
        "code" : "99259",
        "display" : "Tadjikistan"
      },
      {
        "code" : "99260",
        "display" : "Turkménistan"
      },
      {
        "code" : "99261",
        "display" : "Etat de Palestine"
      },
      {
        "code" : "99262",
        "display" : "Timor oriental"
      },
      {
        "code" : "99301",
        "display" : "Egypte"
      },
      {
        "code" : "99302",
        "display" : "Liberia"
      },
      {
        "code" : "99303",
        "display" : "Afrique du Sud"
      },
      {
        "code" : "99304",
        "display" : "Gambie"
      },
      {
        "code" : "99306",
        "display" : "Sainte-Hélène"
      },
      {
        "code" : "99308",
        "display" : "Territoire britannique de l'océan Indien"
      },
      {
        "code" : "99309",
        "display" : "Tanzanie"
      },
      {
        "code" : "99310",
        "display" : "Zimbabwe"
      },
      {
        "code" : "99311",
        "display" : "Namibie"
      },
      {
        "code" : "99312",
        "display" : "République démocratique du Congo"
      },
      {
        "code" : "99313",
        "display" : "Provinces espagnoles d'Afrique"
      },
      {
        "code" : "99314",
        "display" : "Guinée équatoriale"
      },
      {
        "code" : "99315",
        "display" : "Ethiopie"
      },
      {
        "code" : "99316",
        "display" : "Libye"
      },
      {
        "code" : "99317",
        "display" : "Erythrée"
      },
      {
        "code" : "99318",
        "display" : "Somalie"
      },
      {
        "code" : "99319",
        "display" : "Açores, Madère"
      },
      {
        "code" : "99321",
        "display" : "Burundi"
      },
      {
        "code" : "99322",
        "display" : "Cameroun"
      },
      {
        "code" : "99323",
        "display" : "République Centrafricaine"
      },
      {
        "code" : "99324",
        "display" : "Congo"
      },
      {
        "code" : "99326",
        "display" : "Côte d'Ivoire"
      },
      {
        "code" : "99327",
        "display" : "Bénin"
      },
      {
        "code" : "99328",
        "display" : "Gabon"
      },
      {
        "code" : "99329",
        "display" : "Ghana"
      },
      {
        "code" : "99330",
        "display" : "Guinée"
      },
      {
        "code" : "99331",
        "display" : "Burkina"
      },
      {
        "code" : "99332",
        "display" : "Kenya"
      },
      {
        "code" : "99333",
        "display" : "Madagascar"
      },
      {
        "code" : "99334",
        "display" : "Malawi"
      },
      {
        "code" : "99335",
        "display" : "Mali"
      },
      {
        "code" : "99336",
        "display" : "Mauritanie"
      },
      {
        "code" : "99337",
        "display" : "Niger"
      },
      {
        "code" : "99338",
        "display" : "Nigeria"
      },
      {
        "code" : "99339",
        "display" : "Ouganda"
      },
      {
        "code" : "99340",
        "display" : "Rwanda"
      },
      {
        "code" : "99341",
        "display" : "Sénégal"
      },
      {
        "code" : "99342",
        "display" : "Sierra Leone"
      },
      {
        "code" : "99343",
        "display" : "Soudan"
      },
      {
        "code" : "99344",
        "display" : "Tchad"
      },
      {
        "code" : "99345",
        "display" : "Togo"
      },
      {
        "code" : "99346",
        "display" : "Zambie"
      },
      {
        "code" : "99347",
        "display" : "Botswana"
      },
      {
        "code" : "99348",
        "display" : "Lesotho"
      },
      {
        "code" : "99349",
        "display" : "Soudan du Sud"
      },
      {
        "code" : "99350",
        "display" : "Maroc"
      },
      {
        "code" : "99351",
        "display" : "Tunisie"
      },
      {
        "code" : "99352",
        "display" : "Algérie"
      },
      {
        "code" : "99389",
        "display" : "Sahara occidental"
      },
      {
        "code" : "99390",
        "display" : "Maurice"
      },
      {
        "code" : "99391",
        "display" : "Eswatini"
      },
      {
        "code" : "99392",
        "display" : "Guinée-Bissau"
      },
      {
        "code" : "99393",
        "display" : "Mozambique"
      },
      {
        "code" : "99394",
        "display" : "Sao Tomé-et-Principe"
      },
      {
        "code" : "99395",
        "display" : "Angola"
      },
      {
        "code" : "99396",
        "display" : "Cap-Vert"
      },
      {
        "code" : "99397",
        "display" : "Comores"
      },
      {
        "code" : "99398",
        "display" : "Seychelles"
      },
      {
        "code" : "99399",
        "display" : "Djibouti"
      },
      {
        "code" : "99401",
        "display" : "Canada"
      },
      {
        "code" : "99404",
        "display" : "États-Unis"
      },
      {
        "code" : "99405",
        "display" : "Mexique"
      },
      {
        "code" : "99406",
        "display" : "Costa Rica"
      },
      {
        "code" : "99407",
        "display" : "Cuba"
      },
      {
        "code" : "99408",
        "display" : "République dominicaine"
      },
      {
        "code" : "99409",
        "display" : "Guatemala"
      },
      {
        "code" : "99410",
        "display" : "Haïti"
      },
      {
        "code" : "99411",
        "display" : "Honduras"
      },
      {
        "code" : "99412",
        "display" : "Nicaragua"
      },
      {
        "code" : "99413",
        "display" : "Panama"
      },
      {
        "code" : "99414",
        "display" : "El Salvador"
      },
      {
        "code" : "99415",
        "display" : "Argentine"
      },
      {
        "code" : "99416",
        "display" : "Brésil"
      },
      {
        "code" : "99417",
        "display" : "Chili"
      },
      {
        "code" : "99418",
        "display" : "Bolivie"
      },
      {
        "code" : "99419",
        "display" : "Colombie"
      },
      {
        "code" : "99420",
        "display" : "Equateur"
      },
      {
        "code" : "99421",
        "display" : "Paraguay"
      },
      {
        "code" : "99422",
        "display" : "Pérou"
      },
      {
        "code" : "99423",
        "display" : "Uruguay"
      },
      {
        "code" : "99424",
        "display" : "Venezuela"
      },
      {
        "code" : "99425",
        "display" : "Territoires du Royaume-Uni aux Antilles"
      },
      {
        "code" : "99426",
        "display" : "Jamaïque"
      },
      {
        "code" : "99427",
        "display" : "Territoires du Royaume-Uni dans l'Atlantique sud"
      },
      {
        "code" : "99428",
        "display" : "Guyana"
      },
      {
        "code" : "99429",
        "display" : "Belize"
      },
      {
        "code" : "99430",
        "display" : "Groenland"
      },
      {
        "code" : "99432",
        "display" : "Territoires des Etats-Unis en Amérique"
      },
      {
        "code" : "99433",
        "display" : "Trinite-et-Tobago"
      },
      {
        "code" : "99434",
        "display" : "Barbade"
      },
      {
        "code" : "99435",
        "display" : "Grenade"
      },
      {
        "code" : "99436",
        "display" : "Bahamas"
      },
      {
        "code" : "99437",
        "display" : "Suriname"
      },
      {
        "code" : "99438",
        "display" : "Dominique"
      },
      {
        "code" : "99439",
        "display" : "Sainte-Lucie"
      },
      {
        "code" : "99440",
        "display" : "Saint-Vincent-et-les-Grenadines"
      },
      {
        "code" : "99441",
        "display" : "Antigua-et-Barbuda"
      },
      {
        "code" : "99442",
        "display" : "St-Christophe-et-Niévès"
      },
      {
        "code" : "99443",
        "display" : "Bonaire, Saint Eustache et Saba"
      },
      {
        "code" : "99444",
        "display" : "Curaçao"
      },
      {
        "code" : "99445",
        "display" : "Saint-Martin (partie néerlandaise)"
      },
      {
        "code" : "99501",
        "display" : "Australie"
      },
      {
        "code" : "99502",
        "display" : "Nouvelle-Zélande"
      },
      {
        "code" : "99503",
        "display" : "Pitcairn, île"
      },
      {
        "code" : "99505",
        "display" : "Territoires des Etats-Unis en Océanie"
      },
      {
        "code" : "99506",
        "display" : "Samoa occidentales"
      },
      {
        "code" : "99507",
        "display" : "Nauru"
      },
      {
        "code" : "99508",
        "display" : "Fidji"
      },
      {
        "code" : "99509",
        "display" : "Tonga"
      },
      {
        "code" : "99510",
        "display" : "Papouasie-Nouvelle-Guinée"
      },
      {
        "code" : "99511",
        "display" : "Tuvalu"
      },
      {
        "code" : "99512",
        "display" : "Salomon, îles"
      },
      {
        "code" : "99513",
        "display" : "Kiribati"
      },
      {
        "code" : "99514",
        "display" : "Vanuatu"
      },
      {
        "code" : "99515",
        "display" : "Marshall, îles"
      },
      {
        "code" : "99516",
        "display" : "Micronésie"
      },
      {
        "code" : "99517",
        "display" : "Palaos, îles"
      }]
    }]
  }
}

```
