# Terminologies - Terminologies de Santé v1.10.0

## Terminologies

Les terminologies sont des nomenclatures officielles créées et maintenues :
*  soit par l'agence du numérique en santé qui en est propriétaire. Par exemple, la TRE_R87-TypeCarte est une nomenclature regroupant les différents types de cartes des professionnels (CPx) fournies par l’agence du numérique en santé ; 
*  soit par une organisation externe à l'agence du numérique en santé ; dans ce cas, l'agence du numérique en santé extrait la terminologie, la formate selon ses conventions de nommage et de structure, pour l'intégrer dans ses systèmes. 

| | | | |
| :--- | :--- | :--- | :--- |
| Name | Description | date_maj | Status |
| [ATC](CodeSystem-terminologie-atc.md) | La classification ATC (anatomique, thérapeutique et chimique) classe les substances actives dans différents groupes selon l’organe ou le système sur lequel ils agissent et selon leurs propriétés thérapeutiques, pharmacologiques et chimiques. | 10/02/2026 | active |
| [ActCode](CodeSystem-v3-ActCode.md) | A code specifying the particular kind of Act that the Act-instance represents within its class.**Constraints:** The kind of Act (e.g. physical examination, serum potassium, inpatient encounter, charge financial transaction, etc.) is specified with a code from one of several, typically external, coding systems. The coding system will depend on the class of Act, such as LOINC for observations, etc.Conceptually, the Act.code must be a specialization of the Act.classCode. This is why the structure of ActClass domain should be reflected in the superstructure of the ActCode domain and then individual codes or externally referenced vocabularies subordinated under these domains that reflect the ActClass structure.Act.classCode and Act.code are not modifiers of each other but the Act.code concept should really imply the Act.classCode concept. For a negative example, it is not appropriate to use an Act.code "potassium" together with and Act.classCode for "laboratory observation" to somehow mean "potassium laboratory observation" and then use the same Act.code for "potassium" together with Act.classCode for "medication" to mean "substitution of potassium". This mutually modifying use of Act.code and Act.classCode is not permitted. | 30/05/2023 | active |
| [ActMood](CodeSystem-v3-ActMood.md) | OpenIssue: In Ballot 2009May, a strong Negative vote was lodged against several of the concept definitions in the vocabulary used for Act.moodCode. The vote was found "Persuasive With Mod", with the understanding that M and M would undertake a detailed review of these concept definitions for a future release of the RIM. | 30/05/2023 | active |
| [ActPriority](CodeSystem-v3-ActPriority.md) | A set of codes (e.g., for routine, emergency), specifying the urgency under which the Act happened, can happen, is happening, is intended to happen, or is requested/demanded to happen. | 20/03/2019 | active |
| [ActStatus](CodeSystem-v3-ActStatus.md) | Codes representing the defined possible states of an Act, as defined by the Act class state machine. | 20/03/2019 | active |
| [AdministrativeGender](CodeSystem-v3-AdministrativeGender.md) | The gender of a person used for adminstrative purposes (as opposed to clinical gender) | 20/03/2019 | active |
| [BDPM](CodeSystem-terminologie-bdpm.md) | LA BDPM est un des référentiels du médicament gérée et distribuée par l’ANSM. Elle recense l’ensemble des spécialités et des présentations effectivement commercialisées durant les 5 dernières années. De ce fait, elle ne propose pas un historique exhaustif des codes de présentation et spécialités, celui-ci peut être obtenu grâce à la base RCP disponible sur le site de l’ANSM | 01/06/2026 | active |
| [CCAM](CodeSystem-terminologie-ccam.md) | La Classification Commune des Actes Médicaux est la terminologie de facturation créée et maintenue par la CNAM. | 02/01/2026 | active |
| [CIM11_MMS](CodeSystem-terminologie-cim11-mms.md) | La Classification Internationale des Maladies (CIM) dans sa 11ème révision permet d’établir, partout dans le monde, les statistiques sanitaires. Fournissant un langage commun pour alimenter les dossiers patients électroniques, la CIM11 permet d’échanger des données médicales de manière cohérente et normalisée pour de nombreux cas d’usage (production de soins, coordination professionnelle, pilotage, et exploitation de données) | 02/06/2026 | active |
| [CIM_10_FR_PMSI](CodeSystem-terminologie-cim-10.md) | La Classification Internationale des Maladies (CIM) permet d’établir les statistiques sanitaires (morbi-mortalité) partout dans le monde. Elle est gérée par l’Organisation Mondiale de la Santé qui publie une mise à jour annuelle. En France l’ATIH édite et publie une version complète du volume 1 de la CIM–10 à usage PMSI. La CIM–10 est aussi utilisée pour alimenter les dossier médicaux électronique des patients.Elle est destinée à être progressivement remplacée par la CIM 11 | 20/12/2024 | active |
| [CISP_2](CodeSystem-terminologie-cisp.md) | La Classification internationale des soins primaires (CISP) est la version française de l’International Classification of Primary Care (ICPC). Elle permet de coder trois éléments de consultation de médecine générale : motifs de rencontre (du point de vue du patient), problèmes de santé diagnostiqués et procédures de soins.Elle trouve sa place au sein de la famille des classifications de l’OMS comme classification associée à la CIM (classification internationale des maladies), l’ICF (classification internationale du fonctionnement, du handicap et de la santé) et l'ICHI (classification internationale des interventions de santé). | 26/06/2019 | active |
| [ClaDiMed](CodeSystem-terminologie-cladimed.md) | La classification CLADIMED décrit le domaine des produits de santé (dispositifs médicaux (DM) et autres produits de santé (hors médicaments)). C’est une classification mono axiale inspirée de la classification internationale ATC des médicaments (Anatomique, Thérapeutique, Chimique). | 01/01/2021 | active |
| [ConceptProperties](CodeSystem-concept-properties.md) | CodeSystem permettant définir les propriétés NOS utilisées dans les CodeSystem NOS | 30/03/2026 | active |
| [ConditionClinicalStatusCodes](CodeSystem-condition-clinical.md) | Preferred value set for Condition Clinical Status. | 12/12/2025 | active |
| [ConditionVerificationStatus](CodeSystem-condition-ver-status.md) | The verification status to support or decline the clinical status of the condition or diagnosis. | 24/04/2024 | active |
| [Confidentiality](CodeSystem-v3-Confidentiality.md) | A set of codes specifying the security classification of acts and roles in accordance with the definition for concept domain "Confidentiality". | 30/05/2023 | active |
| [Dictionnaire_SMS_Substance_Management_Services_](CodeSystem-terminologie-sms.md) | Le dictionnaire des substances ou SMS a été conçu par l’European Medicines Agency (EMA) dans le cadre d’une démarche qualité. Ce dictionnaire contient les substances entrant dans la composition de médicaments destinés à un humain et/ou vétérinaire. | 05/05/2026 | active |
| [EMDN](CodeSystem-terminologie-emdn.md) | La nomenclature européenne des dispositifs médicaux (EMDN) est la nomenclature que doivent utiliser les fabricants pour enregistrer leurs dispositifs médicaux dans EUDAMED, base de données européenne sur les dispositifs médicaux. Il s'agit d'alimenter le système européen d’identification des dispositifs fondé sur un identifiant unique du dispositif (IUD) pour en faciliter la traçabilité. | 28/04/2022 | active |
| [EmploymentStatus](CodeSystem-v2-0066.md) | HL7-defined code system of concepts which specify an employment status of a person. Used in HL7 Version 2 messaging in the GT1 segment. | 01/12/2019 | active |
| [EntityCode](CodeSystem-v3-EntityCode.md) | **OpenIssue:** Missing description. | 20/03/2019 | active |
| [IcdO3](CodeSystem-icd-o-3.md) | International Classification of Diseases for Oncology, version 3. For more information see http://www.who.int/classifications/icd/adaptations/oncology/en/. | 20/03/2019 | active |
| [LAHN](CodeSystem-terminologie-lahn.md) | La liste des actes innovants hors nomenclature (LAHN) a été mise en place par la direction générale de l’offre de soins (DGOS) en 2024, dans le cadre du développement de l’innovation en santé. Elle est la fusion du RIHN et de la Liste Complémentaire (LC). L’objectif est de soutenir l’innovation et de la dynamiser par une prise en charge et une évaluation rapide des actes innovants. La LAHN contient une liste d’actes innovants (biologie et anatomocytopathologie) pris en charge à titre transitoire moyennant un recueil de données pour leur évaluation. | 02/06/2026 | active |
| [MediaType](CodeSystem-v3-mediaType.md) | Internet Assigned Numbers Authority (IANA) Mime Media Types. Identifies the type of the encapsulated data and identifies a method to interpret or render the data. The IANA defined domain of media types is established by the Internet standard RFC 2045 [http://www.ietf.org/rfc/rfc2045.txt] and 2046 [http://www.ietf.org/rfc/rfc2046.txt]. RFC 2046 defines the media type to consist of two parts:1. top level media type, and
1. media subtype
However, this HL7 datatypes specification treats the entire media type as one atomic code symbol in the form defined by IANA, i.e., top level type followed by a slash "/" followed by media subtype. Currently defined media types are registered in a database [http://www.iana.org/assignments/media-types/index.html] maintained by IANA. Currently several hundred different MIME media types are defined, with the list growing rapidly. In general, all those types defined by the IANA MAY be used. | 20/03/2019 | active |
| [NABM](CodeSystem-terminologie-nabm.md) | La NABM est la terminologie de facturation des actes de biologie médicale. Elle décrit la liste des actes de biologie dans une arborescence en chapitres et sous-chapitres ainsi que des règles de facturation. | 13/04/2026 | active |
| [NUVA](CodeSystem-terminologie-nuva.md) | La nomenclature unifiée des vaccins (NUVA) liste les spécialités vaccinales commercialisées ou ayant été commercialisées en France ou à l’étranger. Ces spécialités sont associées à une dénomination générique et à une description structurée notamment au niveau des valences et des pathologies cibles.Elle permet de constituer un historique vaccinal complet, aussi précis que le permettent les sources des données, interprétable par des systèmes d’information. | 06/05/2026 | active |
| [ObservationInterpretation](CodeSystem-v3-ObservationInterpretation.md) | One or more codes providing a rough qualitative interpretation of the observation, such as "normal" / "abnormal", "low" / "high", "better" / "worse", "resistant" / "susceptible", "expected" / "not expected". The value set is intended to be for ANY use where coded representation of an interpretation is needed. | 20/03/2019 | active |
| [ObservationMethod](CodeSystem-v3-ObservationMethod.md) | A code that provides additional detail about the means or technique used to ascertain the observation.**Examples:** Blood pressure measurement method: arterial puncture vs. sphygmomanometer (Riva-Rocci), sitting vs. supine position, etc.**OpenIssue:** Description copied from Concept Domain of same name. Must be verified. Note that the Domain has a full discussion about use of the attribute and constraining that is not appropriate for the code system description. Needs to be improved. | 20/03/2019 | active |
| [ObservationValue](CodeSystem-v3-ObservationValue.md) | This code system covers all concepts of HL7-defined values for the Observation value element, when it has a coded datatype. | 28/02/2024 | active |
| [OrderableDrugForm](CodeSystem-v3-orderableDrugForm.md) | **OpenIssue:** Missing description. | 20/03/2019 | active |
| [ParticipationFunction](CodeSystem-v3-ParticipationFunction.md) | This code is used to specify the exact function an actor had in a service in all necessary detail. This domain may include local extensions (CWE). | 20/03/2019 | active |
| [ParticipationType](CodeSystem-v3-ParticipationType.md) | A code specifying the meaning and purpose of every Participation instance. Each of its values implies specific constraints on the Roles undertaking the participation. | 20/03/2019 | active |
| [RUIM eeprescription](CodeSystem-terminologie-ruim-eeprescription.md) | Composite CodeSystem grouping Brand Name + Package Size (+ optional properties).NB: dans cette version bêta, le Brand Name est remplacé par le libellé de la spécialité. | 13/01/2026 | active |
| [RoleCode](CodeSystem-v3-RoleCode.md) | A set of codes further specifying the kind of Role; specific classification codes for further qualifying RoleClass codes. | 15/12/2019 | active |
| [SERAFIN_PH](CodeSystem-terminologie-SERAFINPH.md) | Les nomenclatures des besoins et des prestations ont été élaborées par un groupe de travail issu du projet SERAFIN-PH porté par la Caisse nationale de Solidarité pour l’Autonomie (CNSA) et la Direction Générale de la Cohésion Sociale (DGCS). Elles permettent de décrire, sur la base d’un langage commun, les besoins identifiés des personnes, et les prestations réalisées en réponse à ces besoins. Les usages locaux de ces nomenclatures montrent leur pertinence pour nouer autour des projets personnalisés d’accompagnement et de leurs déclinaisons opérationnelles un dialogue soutenu et permanent entre tous les acteurs concernés, de la personne accompagnée aux structures médico-sociales, acteurs de droit commun et jusqu’aux institutions de régulation (ARS, services déconcentrés et collectivités locales). | 31/12/2022 | active |
| [SNOMED_CT](CodeSystem-11000315107-20250621.md) | SNOMED CT is the most comprehensive and precise clinical health terminology product in the world, owned and distributed around the world by The International Health Terminology Standards Development Organisation (IHTSDO). | 21/06/2025 | active |
| [SNOMED_CT](CodeSystem-900000000000207008-20260601.md) | SNOMED CT is the most comprehensive and precise clinical health terminology product in the world, owned and distributed around the world by The International Health Terminology Standards Development Organisation (IHTSDO). | 31/05/2026 | active |
| [ServiceType](CodeSystem-service-type.md) | This value set defines an example set of codes of service-types. | 09/03/2024 | draft |
| [SpecimenCollectionMethod](CodeSystem-v2-0488.md) | HL7-defined code system of concepts specifying the specimen collection method. Used in HL7 Version 2.x messaging in the SPM segment. | 01/12/2019 | active |
| [SpecimenType](CodeSystem-v2-0487.md) | HL7-defined code system of concepts that describe the precise nature of an entity that may be used as the source material for an observation. This is one of two code systems that are used instead of table 0070 (code system 2.16.840.1.113883.18.28) which conflated specimen types and specimen collection methods. Used in HL7 Version 2.x messaging in the SPM segment. | 01/12/2019 | active |
| [SpecimenType](CodeSystem-v3-SpecimenType.md) | **** MISSING DESCRIPTION **** | 20/03/2019 | active |
| [Standard_terms_EDQM](CodeSystem-terminologie-standardterms.md) | Les standard terms (ou listes de termes normalisés) ont été établis en réponse à une demande de la Commission européenne. Ils contiennent les formes pharmaceutiques, les voies et/ou les méthodes d’administration, les unités de présentation, ainsi que les conditionnements, les systèmes de fermeture et les dispositifs d’administration des médicaments à usage humain et/ou vétérinaire. | 11/07/2025 | active |
| [SubstanceAdminSubstitution](CodeSystem-v3-substanceAdminSubstitution.md) | Identifies what sort of change is permitted or has occurred between the therapy that was ordered and the therapy that was/will be provided. | 20/03/2019 | active |
| [TRE_A00_ProducteurDocNonPS](CodeSystem-TRE-A00-ProducteurDocNonPS.md) | Producteur de document non PS | 29/03/2024 | active |
| [TRE_A01_CadreExercice](CodeSystem-TRE-A01-CadreExercice.md) | Cadre d'exercice | 27/09/2024 | active |
| [TRE_A02_ProfessionSavFaire_CISIS](CodeSystem-TRE-A02-ProfessionSavFaire-CISIS.md) | Profession et savoir-faire CI-SIS | 02/02/2026 | active |
| [TRE_A03_ClasseDocument](CodeSystem-TRE-A03-ClasseDocument.md) | Classe de document | 15/12/2023 | active |
| [TRE_A05_TypeDocComplementaire](CodeSystem-TRE-A05-TypeDocComplementaire.md) | Type de document en complément des nomenclatures internationales | 29/03/2024 | active |
| [TRE_A06_FormatCodeComplementaire](CodeSystem-TRE-A06-FormatCodeComplementaire.md) | formatCode en complément des nomenclatures internationales | 29/10/2025 | active |
| [TRE_A07_StatutVisibiliteDocument](CodeSystem-TRE-A07-StatutVisibiliteDocument.md) | Restriction d'audience applicable aux objets référencés | 15/12/2023 | active |
| [TRE_A08_HL7Confidentiality](CodeSystem-TRE-A08-HL7Confidentiality.md) | HL7 confidentiality | 15/12/2023 | active |
| [TRE_A09_DICOMuidRegistry](CodeSystem-TRE-A09-DICOMuidRegistry.md) | DICOM UID Registry | 15/12/2023 | active |
| [TRE_A10_NomenclatureURN](CodeSystem-TRE-A10-NomenclatureURN.md) | Nomenclature identifiée par URN | 15/12/2023 | active |
| [TRE_A11_IheFormatCode](CodeSystem-TRE-A11-IheFormatCode.md) | IHE formatCode | 26/04/2024 | active |
| [TRE_A12_NomenclatureASTM](CodeSystem-TRE-A12-NomenclatureASTM.md) | Nomenclature identifiée par ASTM | 15/12/2023 | active |
| [TRE_A13_HL7ParticipationType](CodeSystem-TRE-A13-HL7ParticipationType.md) | HL7 Type de participation | 15/12/2023 | active |
| [TRE_G00_Langue](CodeSystem-TRE-G00-Langue.md) | Langue | 27/09/2024 | active |
| [TRE_G01_CategorieProduit](CodeSystem-TRE-G01-CategorieProduit.md) | Catégorie de produit | 15/12/2023 | active |
| [TRE_G02_TypeProduit](CodeSystem-TRE-G02-TypeProduit.md) | Type de produit | 15/12/2023 | active |
| [TRE_G03_CiviliteCPx](CodeSystem-TRE-G03-CiviliteCPx.md) | Civilité (CPx) | 15/12/2023 | active |
| [TRE_G04_NiveauResponsabiliteCPx](CodeSystem-TRE-G04-NiveauResponsabiliteCPx.md) | Niveau de responsabilité (CPx) | 15/12/2023 | active |
| [TRE_G05_SousSectionTableauCNOP](CodeSystem-TRE-G05-SousSectionTableauCNOP.md) | Sous-Section du tableau de l'Ordre des Pharmaciens | 15/12/2023 | active |
| [TRE_G07_TypeIdentifiantStructure](CodeSystem-TRE-G07-TypeIdentifiantStructure.md) | Type d'identifiant de structure | 29/03/2024 | active |
| [TRE_G08_TypeIdentifiantPersonne](CodeSystem-TRE-G08-TypeIdentifiantPersonne.md) | Type d'identifiant de personne | 29/03/2024 | active |
| [TRE_G09_DepartementOM](CodeSystem-TRE-G09-DepartementOM.md) | Référentiel des codes départements et collectivités d’outre-mer provenant du COG INSEE + Monaco. Cette TRE possède des propriétés spécifiques : Autorite Epars, pour indiquer le/ les ARS du département (tre-r396-autorite) et region pour indiquer le code de la région du département (TRE-R30-RegionOM) | 05/05/2026 | active |
| [TRE_G100_Specialite_AM](CodeSystem-TRE-G100-Specialite-AM.md) | Spécialité Assurance Maladie | 25/10/2024 | active |
| [TRE_G11_NatureQualificationADELI](CodeSystem-TRE-G11-NatureQualificationADELI.md) | Nature de qualification ADELI | 16/10/2025 | active |
| [TRE_G12_SpecialiteADELI](CodeSystem-TRE-G12-SpecialiteADELI.md) | Spécialité ADELI | 31/05/2024 | active |
| [TRE_G13_OrientationParticuliere](CodeSystem-TRE-G13-OrientationParticuliere.md) | Orientation particulière | 15/12/2023 | active |
| [TRE_G15_ProfessionSante](CodeSystem-TRE-G15-ProfessionSante.md) | Professions de santé définies par le code de la santé publique : professions médicales (art. L4111-1 à L4163-10), de la pharmacie et de la physique médicale (art. 4211-1 à 4252-3) et d’auxiliaires médicaux (art. 4311-1 à 4394-3) | 28/03/2025 | active |
| [TRE_G16_ProfessionFormation](CodeSystem-TRE-G16-ProfessionFormation.md) | Professions en formation (carte CPF) | 15/12/2023 | active |
| [TRE_G17_ModeExerciceCPx](CodeSystem-TRE-G17-ModeExerciceCPx.md) | Mode d'exercice (CPx) | 15/12/2023 | active |
| [TRE_G18_AttributionParticuliereADELI](CodeSystem-TRE-G18-AttributionParticuliereADELI.md) | Attribution particulière ADELI | 15/12/2023 | active |
| [TRE_G19_SecteurActiviteADELI](CodeSystem-TRE-G19-SecteurActiviteADELI.md) | Secteur d'activité ADELI | 23/05/2025 | active |
| [TRE_G20_Specialisation](CodeSystem-TRE-G20-Specialisation.md) | Spécialisation | 15/12/2023 | active |
| [TRE_R01_EnsembleSavoirFaire_CISIS](CodeSystem-TRE-R01-EnsembleSavoirFaire-CISIS.md) | Ensemble Savoir-faire CI-SIS (TRE provisoire) | 02/02/2026 | active |
| [TRE_R02_SecteurActivite](CodeSystem-TRE-R02-SecteurActivite.md) | Le secteur d'activité de santé est une donnée RPPS et correspond au type de service fourni par une structure. Il sert principalement à déterminer les propriétés de facturation des professionnels de ces structures vis-à-vis de l'assurance maladie | 23/05/2025 | active |
| [TRE_R03_AttributionParticuliere](CodeSystem-TRE-R03-AttributionParticuliere.md) | Attribution particulière | 15/12/2023 | active |
| [TRE_R04_TypeSavoirFaire](CodeSystem-TRE-R04-TypeSavoirFaire.md) | Type de savoir-faire | 16/10/2025 | active |
| [TRE_R06_SectionTableauCNOP](CodeSystem-TRE-R06-SectionTableauCNOP.md) | Section du tableau de l'Ordre des Pharmaciens | 15/12/2023 | active |
| [TRE_R09_CategorieProfessionnelle](CodeSystem-TRE-R09-CategorieProfessionnelle.md) | Catégorie professionnelle | 23/02/2026 | active |
| [TRE_R10_SexeAdministratif](CodeSystem-TRE-R10-SexeAdministratif.md) | Sexe administratif | 15/12/2023 | active |
| [TRE_R11_CiviliteExercice](CodeSystem-TRE-R11-CiviliteExercice.md) | Civilité d'exercice | 15/12/2023 | active |
| [TRE_R13_CommuneOM](CodeSystem-TRE-R13-CommuneOM.md) |  | 05/05/2026 | active |
| [TRE_R14_TypeDiplome](CodeSystem-TRE-R14-TypeDiplome.md) | Type de diplôme | 29/03/2024 | active |
| [TRE_R16_LieuFormation](CodeSystem-TRE-R16-LieuFormation.md) | Lieu de formation | 22/12/2025 | active |
| [TRE_R17_TypeAutorisation](CodeSystem-TRE-R17-TypeAutorisation.md) | Type d'autorisation | 23/05/2025 | active |
| [TRE_R18_DisciplineAutorisation](CodeSystem-TRE-R18-DisciplineAutorisation.md) | Discipline d'autorisation | 15/12/2023 | active |
| [TRE_R200_CanalCommunication](CodeSystem-TRE-R200-CanalCommunication.md) | Canal de communication | 30/03/2026 | active |
| [TRE_R201_TypeDivisionTerritoriale](CodeSystem-TRE-R201-TypeDivisionTerritoriale.md) | Type de division territoriale | 15/12/2023 | active |
| [TRE_R202_AccessibiliteLieu](CodeSystem-TRE-R202-AccessibiliteLieu.md) | Niveaux d'accessibilité d'un établissement recevant du public (ERP) | 15/12/2023 | active |
| [TRE_R203_StatutLieu](CodeSystem-TRE-R203-StatutLieu.md) | Statut lieu | 15/12/2023 | active |
| [TRE_R204_DirectionLongitude](CodeSystem-TRE-R204-DirectionLongitude.md) | Direction longitude | 15/12/2023 | active |
| [TRE_R205_DirectionLatitude](CodeSystem-TRE-R205-DirectionLatitude.md) | Direction latitude | 15/12/2023 | active |
| [TRE_R206_TypeContact](CodeSystem-TRE-R206-TypeContact.md) | Type de contact | 15/12/2023 | active |
| [TRE_R207_TypeOrganisationInterne](CodeSystem-TRE-R207-TypeOrganisationInterne.md) | Type organisation interne | 15/12/2023 | active |
| [TRE_R208_ClasseAge](CodeSystem-TRE-R208-ClasseAge.md) | Classe d'âge | 15/12/2023 | active |
| [TRE_R209_TypeActivite](CodeSystem-TRE-R209-TypeActivite.md) | Type d'activité | 23/02/2024 | active |
| [TRE_R20_Pays](CodeSystem-TRE-R20-Pays.md) | Référentiel des codes pays provenant du COG INSEE | 28/03/2025 | active |
| [TRE_R210_ActeSpecifique](CodeSystem-TRE-R210-ActeSpecifique.md) | Action menée par un ou plusieurs acteur(s) de santé dans le cadre d'une activité. Cet acte peut correspondre à une technique spécialisée ou traduire une expertise discriminante dans le parcours de santé. | 01/06/2026 | active |
| [TRE_R211_ActiviteOperationnelle](CodeSystem-TRE-R211-ActiviteOperationnelle.md) | Activite Operationnelle | 01/06/2026 | active |
| [TRE_R212_Equipement](CodeSystem-TRE-R212-Equipement.md) | Equipement | 01/06/2026 | active |
| [TRE_R213_ModePriseEnCharge](CodeSystem-TRE-R213-ModePriseEnCharge.md) | Mode de la prise en charge | 30/03/2026 | active |
| [TRE_R216_HL7RoleCode](CodeSystem-TRE-R216-HL7RoleCode.md) | HL7 roleCode | 13/12/2024 | active |
| [TRE_R217_ProtectionJuridique](CodeSystem-TRE-R217-ProtectionJuridique.md) | Protection juridique | 15/12/2023 | active |
| [TRE_R218_ModeAuthentification](CodeSystem-TRE-R218-ModeAuthentification.md) | Mode d'authentification | 15/12/2023 | active |
| [TRE_R219_AutreResponsableConsent](CodeSystem-TRE-R219-AutreResponsableConsent.md) | Autre responsable consentement | 15/12/2023 | active |
| [TRE_R21_Fonction](CodeSystem-TRE-R21-Fonction.md) | Fonction | 23/02/2026 | active |
| [TRE_R220_ModeleDocumentCDAStructure](CodeSystem-TRE-R220-ModeleDocumentCDAStructure.md) | Identifiant des modèles de CDA structurés | 29/10/2025 | active |
| [TRE_R223_NatCycleForm](CodeSystem-TRE-R223-NatCycleForm.md) | Nature du cycle de formation des étudiants | 15/12/2023 | active |
| [TRE_R224_NiveauFormAcquis](CodeSystem-TRE-R224-NiveauFormAcquis.md) | Niveaux de formation acquis dans le cycle de formation des étudiants | 15/12/2023 | active |
| [TRE_R225_AnneeUniversitaire](CodeSystem-TRE-R225-AnneeUniversitaire.md) | Année universitaire | 09/10/2025 | active |
| [TRE_R226_Dip2iemeCycleNQ](CodeSystem-TRE-R226-Dip2iemeCycleNQ.md) | Diplôme de 2ième cycle non qualifiant | 15/12/2023 | active |
| [TRE_R227_ChampActivite](CodeSystem-TRE-R227-ChampActivite.md) | Champ d'activité | 30/03/2026 | active |
| [TRE_R228_UnitePrix](CodeSystem-TRE-R228-UnitePrix.md) | Unité de prix | 15/12/2023 | active |
| [TRE_R22_GenreActivite](CodeSystem-TRE-R22-GenreActivite.md) | Genre d'activité | 29/03/2024 | active |
| [TRE_R230_Devise](CodeSystem-TRE-R230-Devise.md) | Devise | 15/12/2023 | active |
| [TRE_R231_PalierAuthentification](CodeSystem-TRE-R231-PalierAuthentification.md) | Paliers des référentiels d'authentification de la PGSSI-S | 15/12/2023 | active |
| [TRE_R234_TypeNote](CodeSystem-TRE-R234-TypeNote.md) | Type de note | 15/12/2023 | active |
| [TRE_R236_ModeGestion](CodeSystem-TRE-R236-ModeGestion.md) | Mode gestion | 15/12/2023 | active |
| [TRE_R237_GroupeTarifaireDependance](CodeSystem-TRE-R237-GroupeTarifaireDependance.md) | Niveau de dépendance associé à un tarif | 15/12/2023 | active |
| [TRE_R238_OuvertureAnnuelle](CodeSystem-TRE-R238-OuvertureAnnuelle.md) | Ouverture annuelle | 15/12/2023 | active |
| [TRE_R239_PublicPrisEnCharge](CodeSystem-TRE-R239-PublicPrisEnCharge.md) | Public pris en charge | 30/03/2026 | active |
| [TRE_R23_ModeExercice](CodeSystem-TRE-R23-ModeExercice.md) | Mode d'exercice | 02/02/2026 | active |
| [TRE_R240_TemporaliteAccueil](CodeSystem-TRE-R240-TemporaliteAccueil.md) | Temporalité accueil | 15/12/2023 | active |
| [TRE_R241_AideFinanciere](CodeSystem-TRE-R241-AideFinanciere.md) | Habilit. de l'EG permettant aux pers. accueillies d'avoir des aides financières | 15/12/2023 | active |
| [TRE_R242_TypeHabitation](CodeSystem-TRE-R242-TypeHabitation.md) | Type habitation | 15/12/2023 | active |
| [TRE_R243_CompetenceSpecifique](CodeSystem-TRE-R243-CompetenceSpecifique.md) | Compétence spécifique | 30/03/2026 | active |
| [TRE_R244_CategorieOrganisation](CodeSystem-TRE-R244-CategorieOrganisation.md) | Catégorie d'organisation | 05/05/2026 | active |
| [TRE_R245_SpecialisationDePriseEnCharge](CodeSystem-TRE-R245-SpecialisationDePriseEnCharge.md) | Spécialisation de prise en charge | 25/04/2025 | active |
| [TRE_R246_TypeTarif](CodeSystem-TRE-R246-TypeTarif.md) | Type tarif | 15/12/2023 | active |
| [TRE_R248_ModeAcces](CodeSystem-TRE-R248-ModeAcces.md) | Mode d'accès pour accéder à un SI santé avec données patients | 31/01/2025 | active |
| [TRE_R249_Sexe](CodeSystem-TRE-R249-Sexe.md) | Sexe | 15/12/2023 | active |
| [TRE_R24_TypeActiviteLiberale](CodeSystem-TRE-R24-TypeActiviteLiberale.md) | Type d'activité libérale | 15/12/2023 | active |
| [TRE_R250_ConditionTarifaire](CodeSystem-TRE-R250-ConditionTarifaire.md) | Les conditions d'accès à un tarif modulé | 15/12/2023 | active |
| [TRE_R251_FonctionContact](CodeSystem-TRE-R251-FonctionContact.md) | Un titre, une position, une fonction de la personne contact dans l'organisation | 31/01/2025 | active |
| [TRE_R252_TypeHoraire](CodeSystem-TRE-R252-TypeHoraire.md) | Type horaire | 25/10/2024 | active |
| [TRE_R253_TypeMaternite](CodeSystem-TRE-R253-TypeMaternite.md) | Type de maternité | 15/12/2023 | active |
| [TRE_R254_TypeEvenement](CodeSystem-TRE-R254-TypeEvenement.md) | Liste de types d'évènement | 29/03/2024 | active |
| [TRE_R255_FluxStandardise](CodeSystem-TRE-R255-FluxStandardise.md) | Liste de flux standardisés | 15/12/2023 | active |
| [TRE_R256_TypeMessagerie](CodeSystem-TRE-R256-TypeMessagerie.md) | Type de messagerie électronique | 15/12/2023 | active |
| [TRE_R257_TypeBAL](CodeSystem-TRE-R257-TypeBAL.md) | Type de boîte aux lettres | 15/12/2023 | active |
| [TRE_R258_RelationPriseCharge](CodeSystem-TRE-R258-RelationPriseCharge.md) | Relation dans la prise en charge du patient | 23/05/2025 | active |
| [TRE_R259_HL7ParticipationFunction](CodeSystem-TRE-R259-HL7ParticipationFunction.md) | Rôles fonctionnels HL7 | 15/12/2023 | active |
| [TRE_R25_MotifFinActivite](CodeSystem-TRE-R25-MotifFinActivite.md) | Motif de fin d'activité | 15/12/2023 | active |
| [TRE_R260_HL7RoleClass](CodeSystem-TRE-R260-HL7RoleClass.md) | Rôle de la personne point de contact auprès d'une autre personne repris de la terminologie HL7 v3 RoleClass (https://www.hl7.org/fhir/v3/RoleClass/cs.html) | 26/04/2024 | active |
| [TRE_R261_AutreSalarieStructureSante](CodeSystem-TRE-R261-AutreSalarieStructureSante.md) | Autre salariés d'une structure de santé | 15/12/2023 | active |
| [TRE_R262_CategorieSocioProfessionnelle](CodeSystem-TRE-R262-CategorieSocioProfessionnelle.md) | Catégories socio-professionnelles | 15/12/2023 | active |
| [TRE_R263_TypeNumeroIdentification](CodeSystem-TRE-R263-TypeNumeroIdentification.md) | Type de numéro d'identification | 15/12/2023 | active |
| [TRE_R264_PrestationNonObligatoireIncluse](CodeSystem-TRE-R264-PrestationNonObligatoireIncluse.md) | Prestations non obligatoire incluses | 15/12/2023 | active |
| [TRE_R266_FamilleActiviteOperationnelleHorsSerafin](CodeSystem-TRE-R266-FamilleActiviteOperationnelleHorsSerafin.md) | Familles activités opérationnelles hors Serafin | 15/12/2023 | active |
| [TRE_R267_SexeProvenanceISO](CodeSystem-TRE-R267-SexeProvenanceISO.md) | Codes de représentation des sexes humains provenant de la norme ISO 5218 | 15/12/2023 | active |
| [TRE_R268_PaysProvenanceISO](CodeSystem-TRE-R268-PaysProvenanceISO.md) | Référentiel des pays provenant de la norme ISO 3166 | 26/01/2024 | active |
| [TRE_R269_AvailabilityStatusProvenanceOasis](CodeSystem-TRE-R269-AvailabilityStatusProvenanceOasis.md) | Statut de l'objet provenant de la norme Oasis | 15/12/2023 | active |
| [TRE_R270_AvailabilityStatus](CodeSystem-TRE-R270-AvailabilityStatus.md) | Statut de l'objet | 15/12/2023 | active |
| [TRE_R271_TypeRequete](CodeSystem-TRE-R271-TypeRequete.md) | Code de type requêtes | 15/12/2023 | active |
| [TRE_R272_EquipementMaterielLourd](CodeSystem-TRE-R272-EquipementMaterielLourd.md) | Equipements Matériels Lourds | 15/12/2023 | active |
| [TRE_R274_ActiviteSanitaireRegulee](CodeSystem-TRE-R274-ActiviteSanitaireRegulee.md) | Activités sanitaires soumises à une régulation de la part de l'ARS | 15/12/2023 | active |
| [TRE_R275_ModaliteActivite](CodeSystem-TRE-R275-ModaliteActivite.md) | Mode d'application ou type de soins encadrant une activité | 15/12/2023 | active |
| [TRE_R276_FormeActivite](CodeSystem-TRE-R276-FormeActivite.md) | Type d'organisation de prise en charge | 29/03/2024 | active |
| [TRE_R278_FinessConvention](CodeSystem-TRE-R278-FinessConvention.md) | Convention du domaine social FINESS | 31/01/2025 | active |
| [TRE_R279_Clientele](CodeSystem-TRE-R279-Clientele.md) | Clientèles | 27/09/2024 | active |
| [TRE_R280_DisciplineEquipementSocial](CodeSystem-TRE-R280-DisciplineEquipementSocial.md) | Disciplines d'équipement pour le social | 01/06/2026 | active |
| [TRE_R281_DisciplineEnseignement](CodeSystem-TRE-R281-DisciplineEnseignement.md) | Disciplines pour l'enseignement | 29/03/2024 | active |
| [TRE_R282_CNAMAmeliSecteurConventionnement](CodeSystem-TRE-R282-CNAMAmeliSecteurConventionnement.md) | Secteur de conventionnement du professionnel libéral par la CNAM extracts ameli | 15/12/2023 | active |
| [TRE_R283_NiveauConfidentialite](CodeSystem-TRE-R283-NiveauConfidentialite.md) | Niveau de restriction d'accès | 05/05/2026 | active |
| [TRE_R284_NiveauRecoursORSAN](CodeSystem-TRE-R284-NiveauRecoursORSAN.md) | Hiérarchisation fonctionnelle des Éts pour accueil patients après le SAMU | 15/12/2023 | active |
| [TRE_R285_TraitementDocument](CodeSystem-TRE-R285-TraitementDocument.md) | Traitement du document | 15/12/2023 | active |
| [TRE_R286_TypeFermeture](CodeSystem-TRE-R286-TypeFermeture.md) | Type de fermeture, codes provenant du FINESS pour les EJ et EG | 05/05/2026 | active |
| [TRE_R287_NatureContact](CodeSystem-TRE-R287-NatureContact.md) | Un service ou un guichet assurant le contact au sein de l'organisation | 13/12/2024 | active |
| [TRE_R288_TypeProfession](CodeSystem-TRE-R288-TypeProfession.md) | Type de profession | 15/12/2023 | active |
| [TRE_R289_TypeFonction](CodeSystem-TRE-R289-TypeFonction.md) | Type de fonction | 15/12/2023 | active |
| [TRE_R290_RoleAdmTechSanitaireSocial](CodeSystem-TRE-R290-RoleAdmTechSanitaireSocial.md) | Rôle administratif et-ou technique des domaines sanitaire et social | 15/12/2023 | active |
| [TRE_R291_AutreProfession](CodeSystem-TRE-R291-AutreProfession.md) | Liste de professionnels non membres d'une profession réglementée | 15/12/2023 | active |
| [TRE_R292_INSEECategorieSocioProfessionnelleAgrNiv1](CodeSystem-TRE-R292-INSEECategorieSocioProfessionnelleAgrNiv1.md) | Codes de niveau 1 des catégories socio-professionnelles de l'INSEE | 15/12/2023 | active |
| [TRE_R293_AgregatClienteleNiv2](CodeSystem-TRE-R293-AgregatClienteleNiv2.md) | Agrégats de clientèle niveau 2 | 15/12/2023 | active |
| [TRE_R294_AgregatClienteleNiv3](CodeSystem-TRE-R294-AgregatClienteleNiv3.md) | Agrégats de clientèle niveau 3 | 15/12/2023 | active |
| [TRE_R295_AgregatDisciplineEnseignNiv1](CodeSystem-TRE-R295-AgregatDisciplineEnseignNiv1.md) | Agrégats de disciplines pour l'enseignement niveau 1 | 15/12/2023 | active |
| [TRE_R296_AgregatDisciplineEnseignNiv2](CodeSystem-TRE-R296-AgregatDisciplineEnseignNiv2.md) | Agrégats de disciplines pour l'enseignement niveau 2 | 15/12/2023 | active |
| [TRE_R297_AgregatDisciplineEnseignNiv3](CodeSystem-TRE-R297-AgregatDisciplineEnseignNiv3.md) | Agrégats de disciplines pour l'enseignement niveau 3 | 15/12/2023 | active |
| [TRE_R298_AgregatDisciplineEquipSocNiv1](CodeSystem-TRE-R298-AgregatDisciplineEquipSocNiv1.md) | Agrégats de disciplines d'équipement pour le social niveau 1 | 15/12/2023 | active |
| [TRE_R299_AgregatDisciplineEquipSocNiv2](CodeSystem-TRE-R299-AgregatDisciplineEquipSocNiv2.md) | Agrégats de disciplines d'équipement pour le social niveau 2 | 15/12/2023 | active |
| [TRE_R300_AgregatDisciplineEquipSocNiv3](CodeSystem-TRE-R300-AgregatDisciplineEquipSocNiv3.md) | Agrégats de disciplines d'équipement pour le social niveau 3 | 15/12/2023 | active |
| [TRE_R302_ContexteCodeComplementaire](CodeSystem-TRE-R302-ContexteCodeComplementaire.md) | Liste des codes complémentaires utilisables dans un contexte particulier | 26/04/2024 | active |
| [TRE_R303_HL7v3AdministrativeGender](CodeSystem-TRE-R303-HL7v3AdministrativeGender.md) | Sexe d'une personne utilisée à des fins administratives (par opposition au sexe clinique) repris de la terminologie HL7 v3 AdministrativeGender (https://www.hl7.org/fhir/v3/AdministrativeGender/cs.html) | 15/12/2023 | active |
| [TRE_R304_HL7v3ActCode](CodeSystem-TRE-R304-HL7v3ActCode.md) | Type de prise en charge repris de la terminologie HL7 v3 ActCode (https://www.hl7.org/fhir/v3/ActCode/cs.html) | 15/12/2023 | active |
| [TRE_R305_TypeRencontre](CodeSystem-TRE-R305-TypeRencontre.md) | Type de rencontre | 15/12/2023 | active |
| [TRE_R30_RegionOM](CodeSystem-TRE-R30-RegionOM.md) | Référentiel des codes régions et collectivités d'outre-mer provenant du COG INSEE + Monaco | 28/06/2024 | active |
| [TRE_R314_TypeCreneau](CodeSystem-TRE-R314-TypeCreneau.md) | Type de créneaux de soins définis par un professionnel de santé ou son délégataire dans son logiciel de prise de RDV selon la visibilité associée | 26/07/2024 | active |
| [TRE_R316_AutreCategorieEtablissement](CodeSystem-TRE-R316-AutreCategorieEtablissement.md) | Cette table de référence permet d'identifier des catégories d'établissements qui ne sont pas présentes dans la TRE R66 qui est une table de référence ne listant que les catégories d'établissements présentes dans le FINESS | 29/03/2024 | active |
| [TRE_R317_SituationVieQuotidienne](CodeSystem-TRE-R317-SituationVieQuotidienne.md) | Caractérise la situation de vie de la personne : vit seule ou avec d'autres personnes | 29/03/2024 | active |
| [TRE_R318_BesoinAideMobilite](CodeSystem-TRE-R318-BesoinAideMobilite.md) | Caractérise les besoins d'aide de la personne en matière de mobilité | 29/03/2024 | active |
| [TRE_R319_BesoinAideVieSociale](CodeSystem-TRE-R319-BesoinAideVieSociale.md) | Caractérise les besoins d'aide de la personne en matière de vie sociale | 29/03/2024 | active |
| [TRE_R31_StatutEtatCivil](CodeSystem-TRE-R31-StatutEtatCivil.md) | Status de l'état civil | 31/01/2025 | active |
| [TRE_R320_BesoinCommunication](CodeSystem-TRE-R320-BesoinCommunication.md) | Caractérise les besoins d'aide de la personne en matière de scolarité, en lien avec la communication | 29/03/2024 | active |
| [TRE_R321_BesoinEntretienPersonnel](CodeSystem-TRE-R321-BesoinEntretienPersonnel.md) | Caractérise les besoins d'aide de la personne en matière de scolarité, en lien avec l'entretien personnel | 29/03/2024 | active |
| [TRE_R322_BesoinMobilite](CodeSystem-TRE-R322-BesoinMobilite.md) | Caractérise les besoins d'aide de la personne en matière de scolarité, en lien avec la mobilité | 29/03/2024 | active |
| [TRE_R323_BesoinScolarite](CodeSystem-TRE-R323-BesoinScolarite.md) | Caractérise les besoins d'aide de la personne en matière de scolarité, en lien avec les apprentissages | 29/03/2024 | active |
| [TRE_R324_BesoinSoutienProjetProfessionnel](CodeSystem-TRE-R324-BesoinSoutienProjetProfessionnel.md) | Cette nomenclature permet de préciser le besoin du demandeur quant à l'établissement de son ou ses projet(s) professionnel(s) | 29/03/2024 | active |
| [TRE_R325_SituationProfessionnelle](CodeSystem-TRE-R325-SituationProfessionnelle.md) | Caractérise la situation professionnelle de la personne | 29/03/2024 | active |
| [TRE_R326_SituationSansEmploi](CodeSystem-TRE-R326-SituationSansEmploi.md) | Caractérise la situation de la personne lorsqu'elle est sans emploi | 29/03/2024 | active |
| [TRE_R327_TypeDecision](CodeSystem-TRE-R327-TypeDecision.md) | Caractérise le type de décision prise par la CDAPH en réponse à une demande de compensation d'un usager (individu ou représentant légal), à une demande de révision par un tiers ou à un recours administratif préalable obligatoire (RAPO) d'un usager. | 29/03/2024 | active |
| [TRE_R328_TypeScolarisation](CodeSystem-TRE-R328-TypeScolarisation.md) | Caractérise la situation scolaire de la personne | 29/03/2024 | active |
| [TRE_R329_NatureCapacite](CodeSystem-TRE-R329-NatureCapacite.md) | Permet d'indiquer si la capacité est exprimée en lits ou en places | 05/05/2026 | active |
| [TRE_R32_StatutHospitalier](CodeSystem-TRE-R32-StatutHospitalier.md) | Statut hospitalier | 15/12/2023 | active |
| [TRE_R330_TypeStatutCapacite](CodeSystem-TRE-R330-TypeStatutCapacite.md) | Permet de préciser le statut des capacités concernées | 28/03/2025 | active |
| [TRE_R331_TemporaliteCapacite](CodeSystem-TRE-R331-TemporaliteCapacite.md) | Sert à indiquer le moment où une capacité sera effective. Il est ainsi possible de décrire la situation immédiate ou de fournir une information prospective de capacités, prenant notamment en compte les entrées et sorties déjà identifiés de patients | 15/12/2023 | active |
| [TRE_R332_GenreCapacite](CodeSystem-TRE-R332-GenreCapacite.md) | Permet d'indiquer le genre des patients qui peuvent être installés dans des lits disponibles | 28/08/2025 | active |
| [TRE_R333_TypeFermetureCapacite](CodeSystem-TRE-R333-TypeFermetureCapacite.md) | Permet d'indiquer le statut de lits fermés, afin d'identifier le nombre de lits fermés qui peuvent être réactivés en cas de besoin et le nombre de ceux qui ne peuvent pas l'être | 15/12/2023 | active |
| [TRE_R334_TypeLitSupplementaire](CodeSystem-TRE-R334-TypeLitSupplementaire.md) | Permet d'indiquer le statut de lits supplémentaires, pour identifier le nombre de lits supplémentaires déjà mobilisés et, par typologie de mobilisation possible, le nombre de lits qui ne le sont pas encore | 15/12/2023 | active |
| [TRE_R335_TypeSourceCapacite](CodeSystem-TRE-R335-TypeSourceCapacite.md) | Permet d'indiquer quel type de source est à l'origine de l'information de capacité | 15/12/2023 | active |
| [TRE_R336_TypeCrise](CodeSystem-TRE-R336-TypeCrise.md) | Permet d'indiquer le type de crise qui permet de mobiliser le nombre de lits supplémentaires décrits | 15/12/2023 | active |
| [TRE_R337_AffectationTemporaire](CodeSystem-TRE-R337-AffectationTemporaire.md) | Permet d'indiquer la réservation de tout ou partie des lits d'une zone d'hébergement pour des patients selon qu'ils soient -ou non- concernés par une pathologie (Covid+, Covid-, …) ou un évènement (catastrophe naturelle, attentat, …) | 15/12/2023 | active |
| [TRE_R338_ModaliteAccueil](CodeSystem-TRE-R338-ModaliteAccueil.md) | Modalités d'accueil | 30/03/2026 | active |
| [TRE_R33_StatutInscription](CodeSystem-TRE-R33-StatutInscription.md) | Statut de l'inscription | 15/12/2023 | active |
| [TRE_R340_TypeCaracteristiqueEquipement](CodeSystem-TRE-R340-TypeCaracteristiqueEquipement.md) | Type de caractéristique de l'équipement | 29/03/2024 | active |
| [TRE_R341_StatutCommunication](CodeSystem-TRE-R341-StatutCommunication.md) | Permet de donner une indication pour savoir une action doit être menée ou de son résultat lorsqu'elle a été menée | 15/12/2023 | active |
| [TRE_R342_XdsTypesIdentifiantsReferenceId](CodeSystem-TRE-R342-XdsTypesIdentifiantsReferenceId.md) | Types d'identifiants utilisés dans la métadonnée XDS referenceIdList de la fiche du document. Ces types d'identifiants sont spécifiés dans une terminologie incluse dans le profil XDS dans le Cadre Technique d'IHE IT Infrastructure. | 15/12/2023 | active |
| [TRE_R343_FonctionLieu](CodeSystem-TRE-R343-FonctionLieu.md) | Destination d'usage du lieu | 01/06/2026 | active |
| [TRE_R344_NiveauExpertise](CodeSystem-TRE-R344-NiveauExpertise.md) | Le niveau d'expertise atteste du niveau de ressources humaines et matérielles engagées dans la réalisation de l'offre et défini dans un cahier des charges officiel. | 22/12/2025 | active |
| [TRE_R345_TypeIdentifiantAutre](CodeSystem-TRE-R345-TypeIdentifiantAutre.md) | Autre Type d'identifiant | 29/03/2024 | active |
| [TRE_R348_FormationSpecialiseeTransversale](CodeSystem-TRE-R348-FormationSpecialiseeTransversale.md) | Formation Spécialisée Transversale (FST) | 22/12/2025 | active |
| [TRE_R349_ActionAnomalie](CodeSystem-TRE-R349-ActionAnomalie.md) | Action attendue dans le cadre de la gestion d'une anomalie | 15/12/2023 | active |
| [TRE_R34_StatutProfessionnelSSA](CodeSystem-TRE-R34-StatutProfessionnelSSA.md) | Statut du professionnel au SSA | 15/12/2023 | active |
| [TRE_R350_ThematiqueAnomalie](CodeSystem-TRE-R350-ThematiqueAnomalie.md) | Thématique caractérisant une anomalie | 15/12/2023 | active |
| [TRE_R352_StatutMetierAnomalie](CodeSystem-TRE-R352-StatutMetierAnomalie.md) | Statut métier des anomalies | 15/12/2023 | active |
| [TRE_R354_TypeIdentifiantRessourceOperationnelle](CodeSystem-TRE-R354-TypeIdentifiantRessourceOperationnelle.md) | Type d'identifiant des ressources opérationnelles | 29/03/2024 | active |
| [TRE_R355_TypeIdentifiantOffre](CodeSystem-TRE-R355-TypeIdentifiantOffre.md) | Type d'identifiant de l'offre | 29/03/2024 | active |
| [TRE_R356_ProfessionRessource](CodeSystem-TRE-R356-ProfessionRessource.md) | Profession Ressource | 18/09/2025 | active |
| [TRE_R357_StatutPersonnePriseCharge](CodeSystem-TRE-R357-StatutPersonnePriseCharge.md) | Statut de la personne prise en charge. | 15/12/2023 | active |
| [TRE_R358_MotifStatutPersonnePriseCharge](CodeSystem-TRE-R358-MotifStatutPersonnePriseCharge.md) | Motif du statut de la personne prise en charge | 15/12/2023 | active |
| [TRE_R359_SurspecialiteTransversale](CodeSystem-TRE-R359-SurspecialiteTransversale.md) | Surspécialité (compétence) acquise par l'interne à l'issue d'une Formation Spécialisée Transversale (FST) | 22/12/2025 | active |
| [TRE_R368_StatutRessource](CodeSystem-TRE-R368-StatutRessource.md) | Caractérise le statut d'une ressource du médico-social au cours de son cycle de vie | 05/05/2026 | active |
| [TRE_R369_ProfilUtilisateurReferentielNational](CodeSystem-TRE-R369-ProfilUtilisateurReferentielNational.md) | Profils utilisateur d'un référentiel national | 28/03/2025 | active |
| [TRE_R36_AutreDiplomeObtenu](CodeSystem-TRE-R36-AutreDiplomeObtenu.md) | Autre diplôme obtenu | 15/12/2023 | active |
| [TRE_R37_TypeProfessionFonction](CodeSystem-TRE-R37-TypeProfessionFonction.md) | Type des professions et des fonctions | 15/12/2023 | active |
| [TRE_R38_SpecialiteOrdinale](CodeSystem-TRE-R38-SpecialiteOrdinale.md) | Spécialité ordinale | 31/05/2024 | active |
| [TRE_R391_MotifRestrictionDiffusion](CodeSystem-TRE-R391-MotifRestrictionDiffusion.md) | Nomenclature contenant les motifs de restriction de diffusion | 25/04/2025 | active |
| [TRE_R39_Competence](CodeSystem-TRE-R39-Competence.md) | Compétence | 28/06/2024 | active |
| [TRE_R40_CompetenceExclusive](CodeSystem-TRE-R40-CompetenceExclusive.md) | Compétence exclusive | 15/12/2023 | active |
| [TRE_R42_DESCnonQualifiant](CodeSystem-TRE-R42-DESCnonQualifiant.md) | Savoir-faire liés aux DESC du groupe 1 non qualifiants | 28/06/2024 | active |
| [TRE_R43_CapaciteSavoirFaire](CodeSystem-TRE-R43-CapaciteSavoirFaire.md) | Capacité (savoir-faire) | 15/12/2023 | active |
| [TRE_R44_QualificationPAC](CodeSystem-TRE-R44-QualificationPAC.md) | Qualification de praticien adjoint contractuel | 15/12/2023 | active |
| [TRE_R45_FonctionQualifiee](CodeSystem-TRE-R45-FonctionQualifiee.md) | Fonction qualifiée | 15/12/2023 | active |
| [TRE_R48_DiplomeEtatFrancais](CodeSystem-TRE-R48-DiplomeEtatFrancais.md) | Diplôme de l'Etat français | 25/04/2025 | active |
| [TRE_R49_DiplomeEtudeSpecialisee](CodeSystem-TRE-R49-DiplomeEtudeSpecialisee.md) | Diplôme d'Etudes Spécialisées | 31/05/2024 | active |
| [TRE_R50_DESCGroupe1Diplome](CodeSystem-TRE-R50-DESCGroupe1Diplome.md) | DESC Groupe 1 (diplôme) | 15/12/2023 | active |
| [TRE_R51_DESCGroupe2Diplome](CodeSystem-TRE-R51-DESCGroupe2Diplome.md) | DESC Groupe 2 (diplôme) | 15/12/2023 | active |
| [TRE_R52_CapaciteDiplome](CodeSystem-TRE-R52-CapaciteDiplome.md) | Capacité (diplôme) | 15/12/2023 | active |
| [TRE_R53_DiplomePaysEEE](CodeSystem-TRE-R53-DiplomePaysEEE.md) | Diplôme d'un pays de l'EEE | 15/12/2023 | active |
| [TRE_R54_DiplomeUniversiteInterUniversitaire](CodeSystem-TRE-R54-DiplomeUniversiteInterUniversitaire.md) | Diplôme d'Université ou Inter-Universitaire | 26/07/2024 | active |
| [TRE_R55_CertificatEtudeSpeciale](CodeSystem-TRE-R55-CertificatEtudeSpeciale.md) | Certificat d'Etude Spéciale | 15/12/2023 | active |
| [TRE_R56_Attestation](CodeSystem-TRE-R56-Attestation.md) | Attestation | 29/03/2024 | active |
| [TRE_R57_DiplomeEuropeenEtudeSpecialisee](CodeSystem-TRE-R57-DiplomeEuropeenEtudeSpecialisee.md) | Diplôme Européen d'Etudes Spécialisées | 15/12/2023 | active |
| [TRE_R58_AutreTypeDiplome](CodeSystem-TRE-R58-AutreTypeDiplome.md) | Autre type de diplôme | 23/02/2026 | active |
| [TRE_R60_AutoriteEnregistrement](CodeSystem-TRE-R60-AutoriteEnregistrement.md) | Autorité d'enregistrement | 28/06/2024 | active |
| [TRE_R62_Domaine](CodeSystem-TRE-R62-Domaine.md) | Domaine | 15/12/2023 | active |
| [TRE_R63_AgregatCategorieEtablissementNiv1](CodeSystem-TRE-R63-AgregatCategorieEtablissementNiv1.md) | Agrégats de catégories d'établissements niveau 1 | 15/12/2023 | active |
| [TRE_R64_AgregatCategorieEtablissementNiv2](CodeSystem-TRE-R64-AgregatCategorieEtablissementNiv2.md) | Agrégats de catégories d'établissements niveau 2 | 01/06/2026 | active |
| [TRE_R65_AgregatCategorieEtablissement](CodeSystem-TRE-R65-AgregatCategorieEtablissement.md) | Agrégat de catégories d'établissements | 28/02/2025 | active |
| [TRE_R66_CategorieEtablissement](CodeSystem-TRE-R66-CategorieEtablissement.md) | Catégorie d'établissements | 05/05/2026 | active |
| [TRE_R67_TypeStructure_EJ_EG](CodeSystem-TRE-R67-TypeStructure-EJ-EG.md) | Type de structure | 15/12/2023 | active |
| [TRE_R68_FinessAgregatStatutJuridiqueNiv1](CodeSystem-TRE-R68-FinessAgregatStatutJuridiqueNiv1.md) | Agrégats de statuts juridiques FINESS niveau 1 | 15/12/2023 | active |
| [TRE_R69_FinessAgregatStatutJuridiqueNiv2](CodeSystem-TRE-R69-FinessAgregatStatutJuridiqueNiv2.md) | Agrégats de statuts juridiques FINESS niveau 2 | 15/12/2023 | active |
| [TRE_R70_FinessAgregatStatutJuridique](CodeSystem-TRE-R70-FinessAgregatStatutJuridique.md) | Agrégat de statuts juridiques FINESS | 15/12/2023 | active |
| [TRE_R72_FinessStatutJuridique](CodeSystem-TRE-R72-FinessStatutJuridique.md) | Statuts juridiques provenant de FINESS, excepté pour les codes 000 et 100 à 110 qui ont été ajoutés pour les besoins du RPPS en 2017. | 29/03/2024 | active |
| [TRE_R73_ESPIC](CodeSystem-TRE-R73-ESPIC.md) | Etablissement de santé privé d'intérêt collectif | 15/12/2023 | active |
| [TRE_R74_ModeFixationTarifaire](CodeSystem-TRE-R74-ModeFixationTarifaire.md) | Mode de fixation tarifaire | 22/12/2025 | active |
| [TRE_R78_ProfilAccesReferentiel](CodeSystem-TRE-R78-ProfilAccesReferentiel.md) | Profil d'accès aux référentiels | 23/05/2025 | active |
| [TRE_R81_Civilite](CodeSystem-TRE-R81-Civilite.md) | Civilité | 15/12/2023 | active |
| [TRE_R82_Ordre](CodeSystem-TRE-R82-Ordre.md) | Ordre | 15/12/2023 | active |
| [TRE_R84_ProfilAccesAnnuaire_MSSante](CodeSystem-TRE-R84-ProfilAccesAnnuaire-MSSante.md) | Profil d'accès à l'annuaire MSSante | 15/12/2023 | active |
| [TRE_R85_RolePriseCharge](CodeSystem-TRE-R85-RolePriseCharge.md) | Rôle dans la prise en charge des patients ou des usagers | 05/05/2026 | active |
| [TRE_R86_ProfilVIHF](CodeSystem-TRE-R86-ProfilVIHF.md) | Profil VIHF d'accès | 15/12/2023 | active |
| [TRE_R87_TypeCarte](CodeSystem-TRE-R87-TypeCarte.md) | Type de carte | 15/12/2023 | active |
| [TRE_R88_TerritoireSante](CodeSystem-TRE-R88-TerritoireSante.md) | Territoire de Santé (au sens ARS) en France | 15/12/2023 | active |
| [TRE_R89_RegroupementPays](CodeSystem-TRE-R89-RegroupementPays.md) | Regroupement de pays | 15/12/2023 | active |
| [TRE_R90_TypeAE](CodeSystem-TRE-R90-TypeAE.md) | Type Autorité d'enregistrement | 15/12/2023 | active |
| [TRE_R94_ProfessionSocial](CodeSystem-TRE-R94-ProfessionSocial.md) | Profession du social | 13/12/2024 | active |
| [TRE_R95_UsagerTitre](CodeSystem-TRE-R95-UsagerTitre.md) | Usager de titre professionnel | 13/12/2024 | active |
| [TRE_R96_AutreFonctionSanitaire](CodeSystem-TRE-R96-AutreFonctionSanitaire.md) | Autres fonctions du domaine sanitaire | 15/12/2023 | active |
| [TRE_R97_DroitExerciceCompl](CodeSystem-TRE-R97-DroitExerciceCompl.md) | Droit d'exercice complémentaire | 15/12/2023 | active |
| [TerminologieCISIS](CodeSystem-terminologie-cisis.md) | Terminologie multi-domaines créée et maintenue par l'ANS contenant les termes non trouvés dans les autres terminologies internationales ou nationales. | 20/04/2026 | active |
| [TimingEvent](CodeSystem-v3-TimingEvent.md) | **** MISSING DESCRIPTION **** | 20/03/2019 | active |
| [TreR347ActiviteSanitaireDiverseRegulee](CodeSystem-tre-r347-activite-sanitaire-diverse-regulee.md) | Nomenclature des activités sanitaires utilisée pour décrire les Activités Sanitaires Diverses Régulées (ASDR) | 01/06/2026 | active |
| [TreR360TypeRoleEntiteGroupe](CodeSystem-tre-r360-type-role-entite-groupe.md) | Nomenclature des types de rôles que peuvent exercer des entités participants à des groupements | 30/03/2026 | active |
| [TreR361FonctionPublique](CodeSystem-tre-r361-fonction-publique.md) | Nomenclature des versants de la fonction publique | 30/03/2026 | active |
| [TreR362TypeBudget](CodeSystem-tre-r362-type-budget.md) | Nomenclature des types de budget associés aux Entités Géographiques d'Exercice (EGE) dans FINESS+ | 30/03/2026 | active |
| [TreR370RoleRelationEge](CodeSystem-tre-r370-role-relation-ege.md) | Nomenclature des types de rôle existant entre les Entités Géographiques d'Exercice (EGE) au sein d'une PM-SMSSE | 05/05/2026 | active |
| [TreR371TypeGroupeGcc](CodeSystem-tre-r371-type-groupe-gcc.md) | Nomenclature des types de groupement Concernant les groupement de structure on a 2 catégories de regroupement : les Groupement de Coopération Conventionnelle, les Groupement de Coopération Organique | 30/03/2026 | active |
| [TreR372TypeGroupeGco](CodeSystem-tre-r372-type-groupe-gco.md) | Nomenclature des types de Groupement de Coopération Organique (GCO) | 30/03/2026 | active |
| [TreR373TypePersonneMorale](CodeSystem-tre-r373-type-personne-morale.md) | Nomenclature des types de PM-SMSSE (Personne Morale du champ Sanitaire, Médico-social, Social et Enseignement sur les professions de ces champs). Remarque : Cette TRE est juste initialisée à minima et a vocation à porter d'autres valurs. | 05/05/2026 | active |
| [TreR374NatureActiviteSmsseRegulee](CodeSystem-tre-r374-nature-activite-smsse-regulee.md) | Nomenclature des grandes natures d'activité SMSSE exercées par les entités FINESS+ | 05/05/2026 | active |
| [TreR375ModeFinancement](CodeSystem-tre-r375-mode-financement.md) | Nomenclature des modes de financement associés aux capacités de certaines activitées SMSSE | 30/03/2026 | active |
| [TreR381ActiviteAmm](CodeSystem-tre-r381-activite-amm.md) | Nomenclature des activités de soin AMM | 30/03/2026 | active |
| [TreR382ModaliteActDeSoinAmm](CodeSystem-tre-r382-modalite-act-de-soin-amm.md) | Nomenclature des modalités pour les activités de soin AMM | 30/03/2026 | active |
| [TreR383MentionActDeSoinAmm](CodeSystem-tre-r383-mention-act-de-soin-amm.md) | Nomenclature des mentions pour les activités de soin AMM | 30/03/2026 | active |
| [TreR384PratiqueTherapeutiqueSpecifiqueActDeSoinAmm](CodeSystem-tre-r384-pratique-therapeutique-specifique-act-de-soin-amm.md) | Nomenclature des pratiques thérapeutiques spécifiques pour les activités de soin AMM | 30/03/2026 | active |
| [TreR385DeclarationActDeSoinAmm](CodeSystem-tre-r385-declaration-act-de-soin-amm.md) | Nomenclature des déclarations pour les activités de soin AMM | 30/03/2026 | active |
| [TreR387TypeGroupement](CodeSystem-tre-r387-type-groupement.md) | Nomenclature des types de groupement utilisables dans FINESS. Groupement de coopération conventionnelle ou Groupement de coopération organique | 30/03/2026 | active |
| [TreR388TypeLogement](CodeSystem-tre-r388-type-logement.md) | Nomenclature des types de logement associées aux capacités Remarque : cette nomenclature est initialisée avec les besoins FINESS+ | 30/03/2026 | active |
| [TreR389StatutBilanProjetPersonnalise](CodeSystem-tre-r389-statut-bilan-projet-personnalise.md) | Statut du bilan du projet personnalisé. | 18/04/2025 | active |
| [TreR390TypeProjetPersonnalise](CodeSystem-tre-r390-type-projet-personnalise.md) | Cette nomenclature donne le type de projet personnalisé qui est un document co-construit par l'usager, son entourage familial et professionnel du médico-social. | 22/04/2025 | active |
| [TreR393TypeContratSejour](CodeSystem-tre-r393-type-contrat-sejour.md) | Type de contrat conclu entre l’établissement/service et la personne/son représentant légal lors de son entrée en établissement | 21/05/2025 | active |
| [TreR394CompetenceMetier](CodeSystem-tre-r394-competence-metier.md) | Type de savoir-faire opérationnel, transversal ou spécifique, acquis et exercé à titre non exclusif dans le cadre d’une activité professionnelle reconnue. | 25/06/2025 | active |
| [TreR396Autorite](CodeSystem-tre-r396-autorite.md) | liste des autorités structurée en plusieurs types d'autorités : Ordres, ARS, ... | 30/03/2026 | active |
| [TreR397CategorieEntiteGeographiqueExercice](CodeSystem-tre-r397-categorie-entite-geographique-exercice.md) | Cette TRE hierarchique remplace les TRE actuelles TRE_R66_CategorieEtablissement, TRE-R63-AgregatCategorieEtablissementNiv1, TRE-R64-AgregatCategorieEtablissementNiv2, TRE-R65-AgregatCategorieEtablissement et ASS-X10-AgregatCategorieEtablissement. Cette TRE possède des propriétésspécifiques : le niveau d'agrégat des EGE de 1 à 4 (du plus large au plus fin), le parent d'un agrégat d'EGE ou d'un EGE, la relation entre un code et le domaine ( TRE R62), un indicateur pour les EGE spécifiques au ROR ( non finess) et les relations nécessaires à la construction des JDV dynamiques associés | 01/06/2026 | active |
| [TreR400FinessStatutJuridique](CodeSystem-tre-r400-finess-statut-juridique.md) | Cette TRE hiérarchique remplace les TRE_R68-FinessAgregatStatutJuridiqueNiv1, TRE_R69-FinessAgregatStatutJuridiqueNiv2, TRE_R70-FinessAgregatStatutJuridique, TRE_R72-FinessStatutJuridique, et l'association ASS_X11_FinessAgregatStatutJuridique. Cette TRE possède des propriétés spécifiques : le niveau d'agrégat des statuts juridiques de 1 à 4 ( du plus large au plus fin), le parent d'un agrégat de statuts juridiques ou d'un statut juridique, un indicateur pour les statuts juridiques spécifiques à RPPS ( non finess) et les relations nécessaires à la construction des JDV dynamiques associés | 23/02/2026 | active |
| [TreR401ActiviteSocialeRegulee](CodeSystem-tre-r401-activite-sociale-regulee.md) | Cette TRE hiérarchique remplace les éléments suivants : TRE_R280-DisciplineEquipementSocial, TRE_R298-AgregatDisciplineEquipSocNiv1, TRE_R299-AgregatDisciplineEquipSocNiv2, TRE_R300-AgregatDisciplineEquipSocNiv3 et ASS_X14_AgregatDisciplineEquipementSocial.Cette TRE possède des propriétés spécifiques :1. Le niveau d'agrégat des ASOCR de 1 à 4 (du plus large au plus fin)
1. Le parent d'un agrégat d'ASOCR ou d'une ASOCR
1. Les relations nécessaires à la construction des JDV dynamiques associés
 | 01/06/2026 | active |
| [TreR402ActiviteEnseignementRegulee](CodeSystem-tre-r402-activite-enseignement-regulee.md) | Liste des activités d'enseignement régulées organisée en 3 niveaux d'agrégation. Annule et remplace les anciennes TRE xxxEnseignement | 23/02/2026 | active |
| [TreR403PublicActiviteSmsseRegulee](CodeSystem-tre-r403-public-activite-smsse-regulee.md) | Cette TRE hiérarchique remplace les TRE actuelles TRE_R279-Clientele, TRE_R293-AgregatClienteleNiv2, TRE_R294-AgregatClienteleNiv3 et l'association ASS_X13-AgregatClientele. Cette TRE possède de nouvelles propriétés : le niveau d'agrégat des publics de 1 à 3 (du plus large au plus fin), le parent d'un agrégat de publics ou d'un public ainsi que les relations nécessaires à la construction des JDV dynamiques associés | 23/02/2026 | active |
| [TreR404ModeFonctionnemetActiviteSmsseRegulee](CodeSystem-tre-r404-mode-fonctionnement-activite-smsse-regulee.md) | Mode de fonctinonemment des activités ssmsse régulées, remplace la TRE_R209-TypeActivite | 23/02/2026 | active |
| [TreR405ModaliteActiviteSmsseRegulee](CodeSystem-tre-r405-modalite-activite-smsse-regulee.md) | Modalités des activités SSMSE régulées, remplace la TRE_R275-ModaliteActivite | 23/02/2026 | active |
| [TreR406FormeActiviteSmsseRegulee](CodeSystem-tre-r406-forme-activite-smsse-regulee.md) | Formes des activites smsse régulées, remplace la TRE_R276-FormeActivite | 23/02/2026 | active |
| [TreR407CompositionFoyer](CodeSystem-tre-r407-composition-foyer.md) | Désigne avec qui vit l’usager dans son logement. | 02/02/2026 | active |
| [TreR408TypeEnseignementSpecialise](CodeSystem-tre-r408-type-enseignement-specialise.md) | Type d'enseignement spécialisé. | 02/02/2026 | active |
| [TreR412NiveauDiplome](CodeSystem-tre-r412-niveau-diplome.md) | Niveau de diplôme permettant d'indiquer le type de formation nécessaire pour occuper un poste dans le monde professionnel. | 01/06/2026 | draft |
| [TreR413CategoriePermisConduire](CodeSystem-tre-r413-categorie-permis-conduire.md) | Catégorie de permis de conduire. | 01/06/2026 | draft |
| [TreR414NiveauScolaire](CodeSystem-tre-r414-niveau-scolaire.md) | Niveau scolaire de l'usager en France. | 01/06/2026 | draft |
| [TreR415UtilisationCanalCommunication](CodeSystem-tre-r415-utilisation-canal-communication.md) | Précise l'utilisation du canal de communication. | 05/05/2026 | draft |
| [TreR416TypeCourrier](CodeSystem-tre-r416-type-courrier.md) | Type de courrier en France. | 05/05/2026 | draft |
| [TreR417TypeDemandeCompensation](CodeSystem-tre-r417-type-demande-compensation.md) | Type de la demande de compensation adressée à la CDAPH. | 05/05/2026 | draft |
| [TreR418NatureDemandeCompensation](CodeSystem-tre-r418-nature-demande-compensation.md) | Nature de la demande de compensation adressée à la CDAPH. | 05/05/2026 | draft |
| [TreR419Motivation](CodeSystem-tre-r419-motivation.md) | Considération(s) de droit ou de fait qui constituent le fondement de la proposition et de la décision de la CDAPH. | 01/06/2026 | draft |
| [TreR420DroitPrestation](CodeSystem-tre-r420-droit-prestation.md) | Catégorie et type de droit et prestation caractérisant la décision d'orientation. | 05/05/2026 | draft |
| [TreR421MotifFinPag](CodeSystem-tre-r421-motif-fin-pag.md) | Lorsque le plan d'accompagnement global (PAG) arrive à échéance ou si le coordonnateur de parcours l'estime nécessaire, un bilan est élaboré et la phase d'actualisation est lancée afin de déterminer s'il faut prolonger ce PAG, le modifier ou y mettre fin. La MDPH, les partenaires et l'usager peuvent définir ensemble que le PAG n'est plus nécessaire et donc y mettre fin. Le consentement de la personne ou de son représentant légal est recueilli et l'information sur la fin du PAG transmise à l'ensemble des parties-prenantes. | 05/05/2026 | draft |
| [TreR422QualificationOrientation](CodeSystem-tre-r422-qualification-orientation.md) | La qualification de l'orientation peut être cible ou alternative. | 05/05/2026 | draft |
| [TreR423TypePresenceAbsence](CodeSystem-tre-r423-type-presence-absence.md) | Déclaration du type de présence absence de l'usager lors d'un événement organisé par sa structure de rattachement. | 05/05/2026 | draft |
| [TreR424MotifAbsence](CodeSystem-tre-r424-motif-absence.md) | Motif pour lequel l'usager n'est pas présent lors d'un événement organisé par sa structure de rattachement. | 05/05/2026 | draft |
| [TreR425TypeRepas](CodeSystem-tre-r425-type-repas.md) | Type de repas. | 05/05/2026 | draft |
| [TreR426Orientation](CodeSystem-tre-r426-orientation.md) | Orientation vers un Service d'éducation spéciale et de soins à domicile (SESSAD) ou vers un Service d'accompagnement familial et d'éducation précoce (SAFEP) | 05/05/2026 | draft |
| [TreR427TypeAdresse](CodeSystem-tre-r427-type-adresse.md) | Type d'adresse postale. | 05/05/2026 | draft |

