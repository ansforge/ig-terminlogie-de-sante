# Nomenclature des besoins et des prestations - Terminologies de Santé v1.10.0

## CodeSystem: Nomenclature des besoins et des prestations 

 
Les nomenclatures des besoins et des prestations ont été élaborées par un groupe de travail issu du projet SERAFIN-PH porté par la Caisse nationale de Solidarité pour l’Autonomie (CNSA) et la Direction Générale de la Cohésion Sociale (DGCS). Elles permettent de décrire, sur la base d’un langage commun, les besoins identifiés des personnes, et les prestations réalisées en réponse à ces besoins. Les usages locaux de ces nomenclatures montrent leur pertinence pour nouer autour des projets personnalisés d’accompagnement et de leurs déclinaisons opérationnelles un dialogue soutenu et permanent entre tous les acteurs concernés, de la personne accompagnée aux structures médico-sociales, acteurs de droit commun et jusqu’aux institutions de régulation (ARS, services déconcentrés et collectivités locales). 

This Code system is referenced in the definition of the following value sets:

* [JDV_J282_TransportsLiesAuProjetIndividuel_SERAFIN](ValueSet-JDV-J282-TransportsLiesAuProjetIndividuel-SERAFIN.md)
* [JDV_J283_PrestationsIndirects_SERAFIN](ValueSet-JDV-J283-PrestationsIndirects-SERAFIN.md)
* [JDV_J284_PrestationsDirects_SERAFIN](ValueSet-JDV-J284-PrestationsDirects-SERAFIN.md)
* [JDV_J285_Besoins_SERAFIN](ValueSet-JDV-J285-Besoins-SERAFIN.md)

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "terminologie-SERAFINPH",
  "meta" : {
    "versionId" : "1.1746434824553",
    "lastUpdated" : "2025-05-05T08:47:04.553+00:00",
    "profile" : ["http://hl7.org/fhir/StructureDefinition/shareablecodesystem"]
  },
  "url" : "https://smt.esante.gouv.fr/terminologie-SERAFINPH",
  "identifier" : [{
    "system" : "https://smt.esante.gouv.fr/",
    "value" : "terminologie-SERAFINPH"
  }],
  "version" : "2023.1.0",
  "name" : "SERAFIN_PH",
  "title" : "Nomenclature des besoins et des prestations",
  "status" : "active",
  "experimental" : false,
  "date" : "2023-01-01T00:00:00+01:00",
  "publisher" : "Agence du numérique en santé",
  "description" : "Les nomenclatures des besoins et des prestations ont été élaborées par un groupe de travail issu du projet SERAFIN-PH porté par la Caisse nationale de Solidarité pour l’Autonomie (CNSA) et la Direction Générale de la Cohésion Sociale (DGCS).\nElles permettent de décrire, sur la base d’un langage commun, les besoins identifiés des personnes, et les prestations réalisées en réponse à ces besoins. Les usages locaux de ces nomenclatures montrent leur pertinence pour nouer autour des projets personnalisés d’accompagnement et de leurs déclinaisons opérationnelles un dialogue soutenu et permanent entre tous les acteurs concernés, de la personne accompagnée aux structures médico-sociales, acteurs de droit commun et jusqu’aux institutions de régulation (ARS, services déconcentrés et collectivités locales).",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "FR",
      "display" : "France (la)"
    }]
  }],
  "copyright" : "[LOv2](https://github.com/etalab/licence-ouverte/blob/master/LO.md)",
  "valueSet" : "https://smt.esante.gouv.fr/terminologie-SERAFINPH?vs",
  "content" : "complete",
  "count" : 107,
  "filter" : [{
    "code" : "root",
    "operator" : ["="],
    "value" : "True or false."
  },
  {
    "code" : "deprecated",
    "operator" : ["="],
    "value" : "True or false."
  },
  {
    "code" : "imported",
    "operator" : ["="],
    "value" : "True or false"
  }],
  "property" : [{
    "code" : "created",
    "uri" : "http://purl.org/dc/terms/created",
    "type" : "dateTime"
  },
  {
    "code" : "type",
    "uri" : "http://purl.org/dc/elements/1.1/type",
    "description" : "Type fonctionnel d'un concept",
    "type" : "string"
  },
  {
    "code" : "note",
    "uri" : "http://www.w3.org/2004/02/skos/core#note",
    "type" : "string"
  },
  {
    "code" : "versionInfo",
    "uri" : "http://www.w3.org/2002/07/owl#versionInfo",
    "type" : "string"
  },
  {
    "code" : "modified",
    "uri" : "http://purl.org/dc/terms/modified",
    "type" : "dateTime"
  },
  {
    "code" : "deprecated",
    "uri" : "http://www.w3.org/2002/07/owl#deprecated",
    "type" : "boolean"
  },
  {
    "code" : "parent",
    "uri" : "http://hl7.org/fhir/concept-properties#parent",
    "description" : "Codes des parents du concept courant",
    "type" : "code"
  },
  {
    "code" : "child",
    "uri" : "http://hl7.org/fhir/concept-properties#child",
    "description" : "Codes des enfants du concept courant",
    "type" : "code"
  },
  {
    "code" : "imported",
    "description" : "Indicates if the concept is imported from another code system.",
    "type" : "boolean"
  },
  {
    "code" : "root",
    "description" : "Indicates if this concept is a root concept (i.e. Thing is equivalent or a direct parent).",
    "type" : "boolean"
  }],
  "concept" : [{
    "code" : "2.3.2",
    "display" : "Accompagnements au logement",
    "property" : [{
      "code" : "parent",
      "valueCode" : "2.3"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 3"
    },
    {
      "code" : "note",
      "valueString" : "Cette prestation comprend les accompagnements visant à acquérir et à garder un logement. \nCes accompagnements sont notamment réalisés par des professionnels sociaux et éducatifs de l’accompagnement, en particulier :\n \tdes aides médico psychologiques ;\n \tdes éducateurs : éducateurs spécialisés, éducateurs de jeunes enfants ;\n \tdes assistants de service social et conseillers en économie sociale et familiale ; \n \tdes maitres et maitresses de maison.\nCes accompagnements sont réalisés quel que soit le lieu d’habitation : habitat autonome, habitat individuel ou regroupé en gestion sociale ou médico-sociale, habitat dans un établissement, etc.\nCette prestation comprend deux composantes de niveau 4 : \n-\taccompagnements pour vivre dans un logement \n-\taccompagnements pour accomplir les activités domestiques. \nEn outre ces prestations s’inscrivent dans une logique qui inclut toutes les nuances d’un accompagnement : « apprendre à faire », « faire avec », « faire pour (ou à la place de) »."
    },
    {
      "code" : "child",
      "valueCode" : "2.3.2.2"
    },
    {
      "code" : "child",
      "valueCode" : "2.3.2.1"
    }]
  },
  {
    "code" : "1.1",
    "display" : "Besoins en matière de santé somatique ou psychique",
    "property" : [{
      "code" : "parent",
      "valueCode" : "1"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 2"
    },
    {
      "code" : "note",
      "valueString" : "La nomenclature s’appuie sur les fonctions et structures du corps.\nPour cette partie de la nomenclature, la base conceptuelle est toujours celle de la CIF, mais elle prend appui sur les chapitres traitant des fonctions et structures du corps (versus activités et participation sociale pour le reste du bloc 1 et pour le bloc 2). Compte tenu de l’objectif de la nomenclature et pour une plus grande compréhension par les futurs utilisateurs, le choix a été fait de rapprocher les « fonctions » et les « structures » pour les composantes 1.1.1.1 à 1.1.1.9 (composantes de niveau 4).\n \tElle introduit également les besoins de santé dits « courants » ou encore les besoins liés à l’accès aux soins de premier recours.\nIl s’agit des besoins pour entretenir et prendre soin de sa santé, les mêmes que ceux qui s’expriment en population générale et qui renvoient à l’idée d’un égal accès aux soins. Ils correspondent à la sous-composante de niveau 3 : 1.1.10 – Besoins pour entretenir et prendre soin de sa santé."
    },
    {
      "code" : "child",
      "valueCode" : "1.1.8"
    },
    {
      "code" : "child",
      "valueCode" : "1.1.2"
    },
    {
      "code" : "child",
      "valueCode" : "1.1.7"
    },
    {
      "code" : "child",
      "valueCode" : "1.1.1"
    },
    {
      "code" : "child",
      "valueCode" : "1.1.6"
    },
    {
      "code" : "child",
      "valueCode" : "1.1.5"
    },
    {
      "code" : "child",
      "valueCode" : "1.1.10"
    },
    {
      "code" : "child",
      "valueCode" : "1.1.4"
    },
    {
      "code" : "child",
      "valueCode" : "1.1.9"
    },
    {
      "code" : "child",
      "valueCode" : "1.1.3"
    }]
  },
  {
    "code" : "3.1.1",
    "display" : "Gestion des ressources humaines",
    "property" : [{
      "code" : "parent",
      "valueCode" : "3.1"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 3"
    },
    {
      "code" : "note",
      "valueString" : "La gestion des ressources humaines comprend :\n\ttoutes les activités liées à la fonction employeur qui sont déléguées dans le cadre d’une délégation unique de pouvoirs (DUP) ou subdéléguées aux cadres de direction et autres cadres hiérarchiques ;\n\tla gestion de la paie, le pointage et les déclarations ainsi que la médecine du travail pour le personnel de la structure ;\n\tla gestion de la paie, le pointage et les déclarations ainsi que la médecine du travail pour les travailleurs des ESAT ;\n\tla Gestion Prévisionnelle des Emplois et des Compétences (GPEC), la Formation Professionnelle Continue (FPC), \n\tle dialogue social avec les Institutions Représentatives du Personnel (IRP).\nLes professionnels réalisant ces prestations sont notamment:\n-\tles cadres dits « hiérarchiques » (cadres de direction et autres cadres en situation d’encadrement) \n-\tles cadres dits « non hiérarchiques » et professionnels administratifs intervenant pour la paie, le pointage et les déclarations en lien avec les salaires, la médecine du travail, la formation professionnelle que ce soit pour les personnels ou pour les travailleurs d’ESAT. On y trouvera donc éventuellement des formateurs salariés, mais aussi des médecins du travail ou infirmiers et agents administratifs en lien avec la médecine du travail.\n-\tles cadres non hiérarchiques et professionnels administratifs intervenant en matière de GPEC et de dialogue social."
    },
    {
      "code" : "child",
      "valueCode" : "3.1.1.1"
    },
    {
      "code" : "child",
      "valueCode" : "3.1.1.2"
    }]
  },
  {
    "code" : "1.3.2",
    "display" : "Besoins pour vivre dans un logement et accomplir les activités domestiques",
    "property" : [{
      "code" : "parent",
      "valueCode" : "1.3"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 3"
    },
    {
      "code" : "note",
      "valueString" : "La composante de niveau 3 (1.3.2) Besoins pour vivre dans un logement et accomplir les activités domestiques se décline en 2 composantes de niveau 4 comme suit :\n-\t1.3.2.1 – Besoins pour vivre dans un logement\n-\t1.3.2.2 – Besoins pour accomplir les activités domestiques"
    },
    {
      "code" : "child",
      "valueCode" : "1.3.2.2"
    },
    {
      "code" : "child",
      "valueCode" : "1.3.2.1"
    }]
  },
  {
    "code" : "1.3.3.3",
    "display" : "Besoins transversaux en matière d'apprentissages",
    "property" : [{
      "code" : "parent",
      "valueCode" : "1.3.3"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 4"
    },
    {
      "code" : "note",
      "valueString" : "Cette composante de niveau 4 porte sur les apprentissages élémentaires et l’application des connaissances.\nComme tous les besoins, les besoins transversaux en matière d’apprentissage existent indépendamment de l’âge des personnes, et indépendamment de leurs autres besoins. Par conséquent, une personne ayant des besoins en lien avec la vie scolaire et étudiante ou des besoins en lien avec le travail et l’emploi peut également avoir des besoins transversaux en matière d’apprentissage. \nCes besoins peuvent s’exprimer dans toutes les situations et tous les environnements de vie.\nAussi, pour les enfants et jeunes en âge scolaire, faut-il être vigilant à distinguer les apprentissages élémentaires et application des connaissances dans la composante « 1.3.3.1 – Besoins en lien avec la vie scolaire et étudiante ». \nDESCRIPTION : \nBesoins pour les apprentissages élémentaires (apprendre à lire, à écrire, à calculer, acquérir un savoir-faire). \nBesoins pour appliquer des connaissances (pour fixer son attention, pour mémoriser, pour lire, pour écrire, pour calculer, pour résoudre des problèmes, respecter les règles sociales de base, s'installer dans la classe, utiliser les supports pédagogiques).\nCODES CIF CORRESPONDANTS (OMS, 2001) :\nLa composante de niveau 4 porte sur une partie du chapitre 1 (Apprentissages et application des connaissances) des activités et participation de la CIF, les suivantes : \n◦\td130-159 – Apprentissages élémentaires\no\tCopier : imiter en tant que composante élémentaire de l'apprentissage, comme imiter un geste, un son ou le tracé des lettres de l'alphabet.\no\tRépéter : reproduire une suite d'événements ou de symboles en tant que composante élémentaire de l'apprentissage, comme compter par dix ou réciter un poème. \no\tApprendre à lire : développer les compétences requises pour lire couramment et avec précision un texte écrit (y compris en braille), comme reconnaître des caractères et des alphabets, reconnaître les mots, lire à haute voix sans hésitation, sans sauter de mots et en prononçant correctement, et en comprenant les mots et les phrases.\no\tApprendre à écrire : développer les compétences requises pour produire des symboles sous forme de texte représentant des sons, des mots ou des phrases pour transmettre un signifié (y compris en braille), comme écrire des caractères lisibles, écrire sans faute, et respecter la grammaire.\no\tApprendre à calculer : développer les compétences requises pour manipuler les nombres et effectuer des opérations mathématiques simples ou complexes, comme utiliser des signes mathématiques pour effectuer des additions et des soustractions, appliquer des opérations mathématiques correctes pour résoudre des problèmes.\no\tApprendre un savoir-faire (de base ou complexe) : acquérir les compétences élémentaires ou complexes nécessaires pour exécuter un ensemble intégré d'actions ou de tâches, commencer cet apprentissage et le mener à bien, comme manipuler des outils ou jouer aux échecs.\n◦\td160-179 – Appliquer des connaissances\no\tFixer son attention : fixer son attention intentionnellement sur des stimuli spécifiques, par exemple ne pas se laisser distraire par le bruit.\no\tPenser : formuler et manipuler des idées, des notions et des images sur différents sujets, en poursuivant un but défini ou non, seul ou en compagnie d'autres, comme inventer des histoires, démontrer un théorème, manipuler des idées, réfléchir, méditer, penser, spéculer et envisager.\no\tLire : effectuer les activités nécessaires pour comprendre et interpréter des textes écrits (par ex. des livres, un mode d'emploi ou des journaux, sous forme de texte ou en braille), dans l'intention d'acquérir des connaissances générales ou d'obtenir des informations spécifiques.\no\tEcrire : utiliser ou composer des symboles pour transmettre des informations, comme relater des événements ou écrire une lettre.\no\tCalculer : effectuer des calculs selon les règles des mathématiques pour résoudre l'énoncé d'un problème formulé par des mots et produire ou donner des résultats, comme additionner trois nombres, ou diviser un nombre par un autre.\no\tRésoudre des problèmes (simples ou complexes) : trouver la réponse à des questions ou la solution à des situations en cernant et en analysant les questions qui se posent, en mettant au point des options ou des solutions, et en évaluant les effets potentiels de ces solutions, par exemple en résolvant une dispute entre deux personnes\nCE QUE CE N’EST PAS :\nCette composante ne traite pas des besoins liés à la vie scolaire et la vie étudiante ou les besoins en lien avec l’emploi et le travail.  \nCes autres besoins tels que participer à la vie scolaire sont couverts par la composante « 1.3.3.1 – Besoins en lien avec la vie scolaire et étudiante » ou obtenir ou garder un emploi sont couverts par la composante « 1.3.3.2 – Besoins en lien avec le travail et l’emploi ».\nDans la même logique que pour le reste de la nomenclature, les besoins correspondent à un écart (principe d’évaluation de la situation), il ne s’agit donc pas des réponses à mettre en œuvre pour les compenser (principe d’accompagnement)."
    }]
  },
  {
    "code" : "3.1.3.2",
    "display" : "Gestion des données des personnes accueillies, système d’information, informatique, TIC, archivage informatique des données, GED",
    "property" : [{
      "code" : "parent",
      "valueCode" : "3.1.3"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 4"
    },
    {
      "code" : "note",
      "valueString" : "Cette prestation correspond à la gestion des technologies d’information et de communication (TIC) : systèmes d’information, réseaux et équipements informatiques, audiovisuels, télématiques et téléphonie.\nCette prestation correspond à :\n\tLa gestion des données des personnes accueillies en format papier (dossiers des personnes accompagnées) ;\n\tLa gestion des droits d’accès notamment lorsque tout ou partie de ces dossiers en format papier est accessible aux personnes, familles ou professionnels ;\n\tLa gestion des registres des présences / absences (hors travailleurs d’ESAT qui sont concernés par la prestation 3.1.1.2). \n\tConception et développement des systèmes d’information selon les besoins de la structure,\n\tConnexion aux réseaux et développement de l’intranet,\n\tArchivage des données informatisées et gestion électronique des documents,\n\tGestion des droits d’accès lorsque tout ou partie des dossiers informatisés est accessible aux personnes, familles ou professionnels via intranet/internet,\n\tPréconisations et négociation de tous les équipements et coûts de fonctionnement en reprographie, informatique, télématique et téléphonie,  \n\tMaintenance en lien avec la gestion des informations et la communication,\n\tMise en œuvre de solutions permettant de répondre aux enjeux de sécurité des données,\n\tRèglement général sur la protection des données personnelles.\nLes professionnels réalisant ces missions sont notamment:\n-\tles professionnels cadres fonctionnels non hiérarchiques et professionnels non cadres dédiés, comme les ingénieurs et techniciens en technologies d’information et de communication, les agents de maintenance dédiés aux TIC …)"
    }]
  },
  {
    "code" : "2.3.3.3",
    "display" : "Accompagnements pour mener sa vie professionnelle",
    "property" : [{
      "code" : "parent",
      "valueCode" : "2.3.3"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 4"
    },
    {
      "code" : "note",
      "valueString" : "Cette prestation rassemble tous les accompagnements effectués auprès d’une personne pour :\n\tla soutenir dans l’exercice de son activité professionnelle\n\tsusciter, préparer, accompagner son évolution professionnelle \nCes accompagnements répondent aux besoins qu’elle rencontre dans le cadre de son travail / emploi.\nCes prestations sont réalisées, à titre principal, par des professionnels sociaux et éducatifs de l’accompagnement et en particulier des éducateurs et moniteurs : éducateurs spécialisés, éducateurs techniques, moniteurs d’atelier. \nEn outre ces prestations s’inscrivent dans une logique de compensation qui inclut toutes les nuances d’un accompagnement : « apprendre à faire », « faire avec », « faire pour (ou à la place de) ».. Elles ont pour objectif le développement, l’acquisition et le maintien du maximum d’autonomie de la personne dans son exercice professionnel.\nBESOINS AUXQUELS LA PRESTATION REPOND :\nBesoins en lien avec le travail et l’emploi dont :\n \tBesoins pour obtenir, garder et quitter une activité professionnelle ou à caractère professionnel\n \tBesoins transversaux en lien avec le travail et l'emploi\nCE QUE CE N’EST PAS : \nD’autres accompagnements peuvent se dérouler pendant une situation de travail. Ils sont alors rattachés aux prestations afférentes, en matière d’autonomie, de soins ou de participation sociale. Exemples : \n- Les démarches effectuées par l’assistant de service social dont la finalité est l’accès aux droits sociaux pour un travailleur d’un ESAT constituent un accompagnement pour l’ouverture des droits identifiés en 2.3.5.1. \n- Les accompagnements liés aux soins, de maintien ou développement des capacités fonctionnelles sont rattachés - y compris s’ils se déroulent sur le lieu ou sur le temps d’exercice professionnel de la personne - aux prestations afférentes."
    }]
  },
  {
    "code" : "1.1.8",
    "display" : "Besoins en matière de fonctions locomotrices",
    "property" : [{
      "code" : "parent",
      "valueCode" : "1.1"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 4"
    },
    {
      "code" : "note",
      "valueString" : "Cette composante de niveau 3 traite des fonctions locomotrices.\nDESCRIPTION \nBesoins en lien avec les fonctions motrices et de la mobilité, y compris les fonctions des articulations, des os, des réflexes et des muscles\nBesoins quant aux structures liées au mouvement\nCODES CIF CORRESPONDANTS (OMS, 2001)\nCette composante de niveau 4 porte sur l’ensemble des deux chapitres :\n◦ b7 – Fonctions de l’appareil locomoteur et liées au mouvement\no\tFonctions des articulations et des os (b710 – 729)\no\tFonctions des muscles (b730 – 749)\no\tFonctions liés aux mouvements (b750 – b789) :\n\tFonctions relatives aux réflexes moteurs\n\tFonctions relatives aux réactions motrices involontaires\n\tFonctions relatives au contrôle des mouvements volontaires\n\tFonctions relatives aux mouvements involontaires\n\tSensations relatives aux fonctions des muscles et aux fonctions motrices : Sensations relatives aux muscles ou à des groupes de muscles et leurs mouvements. \nInclusions: sensations de raideur et de crispation musculaires, de spasme et de contracture ou de pesanteur musculaire\n◦ s7 – Structures liées au mouvement\nIl s’agit des os, muscles, ligaments et autres structures permettant le mouvement et des différentes régions du corps. \nCE QUE CE N’EST PAS\nIl ne s’agit pas des besoins d’accès aux soins courants couverts par la composante « 1.1.1.10 – Besoins pour entretenir et prendre soin de sa santé ».\nDans la même logique que pour le reste de la nomenclature, les besoins correspondent à un écart (principe d’évaluation de la situation), il ne s’agit donc pas des réponses à mettre en œuvre pour les compenser (principe d’accompagnement)."
    }]
  },
  {
    "code" : "1.3.1.1",
    "display" : "Besoins pour accéder aux droits et à la citoyenneté",
    "property" : [{
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "versionInfo",
      "valueString" : "Raison de l'inactivation : concept dupliqué"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2023-01-01T00:00:00+01:00"
    },
    {
      "code" : "note",
      "valueString" : "Cette composante traite de l’accès aux droits dans ses différentes dimensions, citoyenneté, pratique religieuse, engagement dans la vie civique, bénévolat. Cette composante ne traite pas de la récréation et des loisirs.\nDESCRIPTION : \nBesoins pour accéder aux droits \nBesoins pour accéder à la vie politique et à la citoyenneté\nBesoins pour la pratique religieuse\nBesoins pour faire du bénévolat\nCODES CIF CORRESPONDANTS (OMS, 2001) :\nLa composante de niveau 4 porte sur les activités/participation sociale d’une partie du chapitre 9 (Vie communautaire, sociale et civique) : \n◦\td910 Vie communautaire : s'investir dans tous les aspects de la vie sociale communautaire, comme participer à des œuvres de bienfaisance, des clubs de services ou des organismes socio-professionnels. Inclusions : associations formelles et informelles\n◦\td930 Vie spirituelle : pratiquer une religion ou avoir des activités spirituelles, s'engager dans des organisations et des pratiques religieuses et spirituelles, afin de se réaliser, de trouver un sens à la vie, de découvrir des valeurs religieuses et spirituelles et d'établir le contact avec une puissance divine, comme aller à l'église, au temple, à la mosquée ou à la synagogue, prier et chanter à des fins religieuses, ou pratiquer la contemplation.\n◦\td940 Droits humains : jouir de tous les droits reconnus aux niveaux tant national qu'international à la personne humaine en vertu de sa seule existence en tant qu'être humain, tels que les droits humains reconnus par la Déclaration universelle des droits de l'homme des Nations Unies (1948) et les Règles pour l'égalisation des chances des handicapés des Nations Unies (1993); le droit à l'autodétermination ou à l'autonomie; le droit de décider de son propre destin.\n◦\td950 Vie politique et citoyenneté : participer à la vie sociale, politique et à la vie de la cité en tant que citoyen, avoir le statut légal de citoyen et jouir des droits, de la protection, des privilèges et avoir les devoirs associés à cette qualité, comme avoir le droit de voter, de se porter candidat à une élection, de former un mouvement politique; jouir des droits et des libertés qui découlent de la citoyenneté (par exemple,  liberté d'expression, d'association, de religion, protection contre la détention arbitraire, droit d'avoir un avocat, d'être jugé et de jouir des droits et d'une protection contre la discrimination); avoir un statut légal en tant que citoyen.\nCE QUE CE N’EST PAS :\n\tDans la même logique que pour le reste de la nomenclature, les besoins correspondent à un écart (principe d’évaluation de la situation), il ne s’agit donc pas des réponses à mettre en œuvre pour les compenser (principe d’accompagnement).Les besoins en lien avec la récréation et les loisirs sont couverts par la composante de niveau 4 « 1.3.4.1 – besoins pour participer à la vie sociale »."
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "2.3.1.1",
    "display" : "Accompagnements à l’expression du projet personnalisé",
    "property" : [{
      "code" : "parent",
      "valueCode" : "2.3.1"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 4"
    },
    {
      "code" : "note",
      "valueString" : "Cette prestation comprend les accompagnements mis en œuvre par les professionnels pour favoriser la participation de la personne à la construction de son projet personnalisé, de son élaboration conjointe et de son évolution. \nCe travail peut nécessiter des temps de préparation (conception d’outils adaptés), des rencontres avec la personne accompagnée,  des temps de synthèse. \nCet accompagnement est effectué dans le respect des droits fondamentaux et libertés individuelles, contextualisés dans l’article L311-3 du CASF et rappelés dans la fiche du domaine de prestation 2.3.1.  \nIl est notamment porté par des professionnels sociaux et éducatifs de l’accompagnement, en particulier des éducateurs et assistants de service social.\nEn outre ces prestations s’inscrivent dans une logique qui inclut toutes les nuances d’un accompagnement : de « apprendre à la personne à faire », à « faire avec », jusqu’à « faire pour (ou à la place de) ».\nBESOINS AUXQUELS LA PRESTATION REPOND : \nCes prestations répondent à des besoins pour accéder aux droits. \nCE QUE CE N’EST PAS : \n\tIl ne s’agit pas d’identifier le travail réalisé à propos des projets de l’organisme gestionnaire. \n\tIl ne s’agit pas d’identifier l’existence dans la structure médico-sociale d’une prestation de coordination, ou d’une fonction de coordinateur de projet personnalisé. La coordination usuelle entre professionnels est intégrée dans la prestation réalisée. \n\tIl ne s’agit pas d’identifier la mise en place dans la structure de projets personnalisés d’accompagnement"
    }]
  },
  {
    "code" : "3.2.5",
    "display" : "Transports des biens et matériels liés à la restauration et à l’entretien du linge",
    "property" : [{
      "code" : "parent",
      "valueCode" : "3.2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 3"
    },
    {
      "code" : "note",
      "valueString" : "La réalisation de prestations de fourniture de repas et d’entretien du linge par la structure médico-sociale peut nécessiter la mise en œuvre d’une prestation de transport spécifique correspondant au transport des biens et matériels liés à la restauration et à l’entretien du linge. \n\tCes transports d’ordre logistique peuvent être : Du transport de linge : récolte du linge sale et livraison des linges propres,\n\tDu transport des matières premières pour l’alimentation,\n\tDu transport et livraisons des repas avec équipements professionnels et véhicules spécialisés…"
    }]
  },
  {
    "code" : "2.3.1",
    "display" : "Accompagnements pour exercer ses droits",
    "property" : [{
      "code" : "parent",
      "valueCode" : "2.3"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 3"
    },
    {
      "code" : "note",
      "valueString" : "Cette prestation comprend les accompagnements qui ont pour objectif de permettre aux personnes d’exercer librement leurs droits \nIl s’agit à la fois d’accompagner la connaissance, la compréhension et le plein exercice des droits fondamentaux et libertés individuels : liberté de convictions politiques, de conscience et de religion, droit de vote, etc.\nCes droits sont d’ailleurs énumérés et contextualisés au cadre de l’accompagnement de personnes en situation de handicap dans l’article L311-3 du code de l’action sociale et des familles (CASF) : \n \trespect de la dignité, intégrité, vie privée, intimité, sécurité, d’aller et venir librement. \n \tlibre choix entre les prestations. \n \tprise en charge et accompagnement individualisé et de qualité, respectant le consentement éclairé de la personne ou à défaut de son représentant légal. \n \tconfidentialité des informations concernant l’usager. \n \taccès par la personne accompagnée à l’information relative à sa prise en charge.\n \tinformation sur les droits fondamentaux, protections particulières légales et contractuelles, et voies de recours. \n \tla participation de la personne accompagnée à la conception et à la mise en œuvre de son projet d’accompagnement. \nCes accompagnements sont notamment réalisés par des professionnels sociaux et éducatifs de l’accompagnement, en particulier des éducateurs et assistants de service social. \nEn outre ces prestations s’inscrivent dans une logique de compensation qui inclut toutes les nuances d’un accompagnement : de « apprendre à la personne à faire », à « faire avec », jusqu’à « faire pour (ou à la place de) ». \nCette prestation comprend deux composantes de niveau 4 : \n-\taccompagnement à l’expression du projet personnalisé\n-\taccompagnement à l’exercice des droits et libertés énoncées précédemment ainsi que la participation aux conseils de la vie sociale et aux autres instances de participation prévues dans l’article 311-6 du CASF. \nCE QUE CE N’EST PAS : \n\tLe groupe technique national a choisi de distinguer au sein des droits de tout citoyen, le droit d’être élu. Les accompagnements pour l’exercice d’un mandat électoral et pour  la représentation de ses pairs (dans des instances autres que celles de la structure médico-sociale) seront identifiés au sein de la prestation d’accompagnement 2.3.3.6 – Accompagnements pour l’exercice des mandats électoraux, la représentation des pairs et la pair-aidance parmi les prestations d’accompagnement pour exercer ses rôles sociaux. \nBESOINS AUXQUELS LA PRESTATION REPOND : \nCes prestations répondent à des besoins pour accéder aux droits et à la citoyenneté."
    },
    {
      "code" : "child",
      "valueCode" : "2.3.1.2"
    },
    {
      "code" : "child",
      "valueCode" : "2.3.1.1"
    }]
  },
  {
    "code" : "1.2.1.1",
    "display" : "Besoins en lien avec l’entretien personnel",
    "property" : [{
      "code" : "parent",
      "valueCode" : "1.2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 3"
    },
    {
      "code" : "note",
      "valueString" : "Point de vigilance : l’entretien personnel dans la CIF comprend les activités de toilette, l’habillage, l’élimination et l’alimentation ainsi que les activités « entretenir et prendre soin de sa santé » qui sont des sous-composantes de l’activité « entretien personnel » du chapitre activités et participation sociale. \nPour des raisons d’appropriation et de vigilance quant à la prise en compte des soins et de l’accès aux soins courants ou primaires, ou de premier niveau, tels que définis par l’IRDES, l’OMS et le code de la santé publique (article L1411-11), l’équipe SERAFIN-PH et les membres du groupe technique national (GTN) ont fait un autre choix. En effet, en suivant la logique d’élaboration générale des nomenclatures, les activités du chapitre dédié de la CIF se trouvent dans les grands domaines de l’autonomie ou la participation sociale. La logique aurait donc voulu que « entretenir et prendre soin de sa santé » se retrouve dans les composantes 1.2 ou 1.3. (Autonomie ou participation sociale).\nL’équipe SERAFIN-PH et le groupe technique national ont décidé de répertorier ce besoin dans la composante « santé somatique ou psychique », contrairement donc à la CIF, dans un objectif de faciliter l’appréhension de ce besoin et d’assurer une lisibilité d’ensemble de la nomenclature. Aussi, pour la nomenclature des besoins du projet SERAFIN-PH, les activités « entretenir et prendre soin de sa santé » font partie de la composante de niveau 4 suivante : 1.1.1.10 – Besoins pour entretenir et prendre soin de sa santé. Cette composante fait partie du domaine santé et non du domaine autonomie de la nomenclature des besoins.\nDESCRIPTION : \nBesoins pour la toilette\nBesoins pour prendre soin des parties de son corps\nBesoins pour l'élimination\nBesoins pour s'habiller/se déshabiller\nBesoins pour s'alimenter\nCODES CIF CORRESPONDANTS (OMS, 2001) :\nLa composante de niveau 4 porte sur l’ensemble du chapitre 5 (entretien personnel) des activités et participation sociale de la CIF à l’exception de  l’activité d570 – Prendre soin de sa santé, c’est-à-dire :\n◦\td510 – se laver : laver et sécher son corps tout entier, ou des parties du corps, en utilisant de l'eau et les produits ou les méthodes appropriées, comme prendre son bain, prendre une douche, se laver les mains et les pieds, se laver le visage et les cheveux, et se sécher avec une serviette.\n◦\td520 – Prendre soin de son corps : prendre soin de parties de son corps, comme la peau, le visage, les dents, le cuir chevelu, les ongles et les parties génitales, qui exigent plus qu'un lavage et un séchage.\n◦\td530 – Aller aux toilettes : prévoir et réaliser l'élimination des déchets humains (menstruations, urine et selles) et se nettoyer par la suite.\n◦\td540 – S’habiller : effectuer les gestes coordonnés nécessaires pour mettre et ôter des vêtements et des chaussures dans l'ordre et en fonction du contexte social et du temps qu'il fait, par exemple en mettant, en ajustant et en enlevant une chemise, une jupe, une blouse, un pantalon, des sous-vêtements, un sari, un kimono, des collants, un chapeau, des gants, un manteau, des souliers, des bottes, des sandales et des pantoufles.\n◦\td550 – Manger : coordonner les gestes nécessaires pour préparer des aliments qui ont été servis, les porter à la bouche, les consommer de façon culturellement acceptable, comme couper ou rompre la nourriture en petits morceaux, ouvrir les bouteilles et les canettes, utiliser les couverts, prendre des repas, festoyer, dîner.\n◦\td560 – Boire : coordonner les gestes nécessaires pour prendre une boisson, la porter à la bouche et la consommer selon les usages, mélanger, agiter et verser des liquides à boire, ouvrir les bouteilles et les canettes, boire à la paille ou boire à un robinet ou à une fontaine, téter.\nCE QUE CE N’EST PAS :\nDans la même logique que pour le reste de la nomenclature, les besoins correspondent à un écart (principe d’évaluation de la situation), il ne s’agit donc pas des réponses à mettre en œuvre pour les compenser (principe d’accompagnement).\nPar ailleurs, comme mentionné ci-dessus, les besoins pour entretenir et prendre soin de sa santé sont couverts par la composante de niveau 4  « 1.1.1.10 - besoins pour entretenir et prendre soin de sa santé » du domaine santé."
    }]
  },
  {
    "code" : "3.2.1.1",
    "display" : "Locaux et autres ressources pour héberger",
    "property" : [{
      "code" : "parent",
      "valueCode" : "3.2.1"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 4"
    },
    {
      "code" : "note",
      "valueString" : "Cette prestation consiste pour une structure médico-sociale à fournir un hébergement aux personnes, cet hébergement permettant notamment la réalisation de prestations directes qui répondent aux besoins des personnes tels que recensés de manières synthétique dans la nomenclature des besoins. \nCette prestation peut être mise en œuvre sous différentes formes (dans un établissement, dans une unité de vie externalisée, dans un hébergement extérieur géré par la structure en propriété ou en location) et selon des temporalités différentes (hébergement permanent, hébergement de semaine, hébergement temporaire, hébergement d’urgence). \nBESOINS AUXQUELS LA PRESTATION REPOND : \nCette prestation indirecte a la particularité de répondre à un élément des besoins pour vivre dans un logement à savoir les besoins pour avoir un lieu d’hébergement. \nCE QUE CE N’EST PAS : \n-\tIl ne s’agit pas d’identifier l’existence dans la structure d’un « internat ». \nPar principe, un internat fonctionne de manière diurne et nocturne et la structure propose par conséquent, en termes de prestations indirectes des locaux d’hébergement et des locaux pour accueillir le jour permettant la réalisation de prestations directes de manière diurne et nocturne."
    }]
  },
  {
    "code" : "1.3.3",
    "display" : "Besoins pour l'insertion sociale et professionnelle et pour exercer ses rôles sociaux",
    "property" : [{
      "code" : "parent",
      "valueCode" : "1.3"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 3"
    },
    {
      "code" : "note",
      "valueString" : "Cette composante traite de l’insertion aussi bien scolaire que professionnelle, et des d’apprentissages, de la vie familiale, la parentalité, la vie affective et sexuelle et la pair-aidance.\nAinsi, cette composante de niveau 3 (1.3.3) Besoins pour l’insertion sociale et pour exercer ses droits sociaux est constituée de cinq composantes de niveau 4 comme suit :\n-\t1.3.3.1 – Besoins en lien avec la vie scolaire et étudiante\n-\t1.3.3.2 – Besoins en lien avec le travail et l’emploi\n-\t1.3.3.3 – Besoins transversaux en matière d'apprentissages  \n-\t1.3.3.4 – Besoins pour la vie familiale, la parentalité, la vie affective et sexuelle\n-\t1.3.3.5 - Besoins pour apprendre à être pair-aidant"
    },
    {
      "code" : "child",
      "valueCode" : "1.3.3.2"
    },
    {
      "code" : "child",
      "valueCode" : "1.3.3.1"
    },
    {
      "code" : "child",
      "valueCode" : "1.3.3.5"
    },
    {
      "code" : "child",
      "valueCode" : "1.3.3.4"
    },
    {
      "code" : "child",
      "valueCode" : "1.3.3.3"
    }]
  },
  {
    "code" : "1.3.3.4",
    "display" : "Besoins pour la vie familiale, la parentalité, la vie affective et sexuelle",
    "property" : [{
      "code" : "parent",
      "valueCode" : "1.3.3"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 4"
    },
    {
      "code" : "note",
      "valueString" : "Cette composante de niveau 4 porte sur la vie familiale, affective et sexuelle, et la parentalité.\nDESCRIPTION : \nBesoins pour s'occuper de sa famille \nBesoins pour la parentalité\nBesoins pour la vie affective et sexuelle\nCODES CIF CORRESPONDANTS (OMS, 2001) :\nLa composante de niveau 4 porte sur une partie du chapitre 7 (Relations particulières avec autrui) des activités et participation de la CIF, les suivantes : \n◦\td760 Relations familiales \nInstaurer et entretenir des relations familiales, comme avec les membres de la famille nucléaire, de la famille élargie, de la famille d'accueil ou d'adoption et la belle-famille, des relations plus distantes avec les cousins ou les tuteurs.\n◦\td770 Relations intimes\nCréer et entretenir des relations étroites ou tendres avec d'autres personnes, [notamment entre] partenaires sexuels\nCE QUE CE N’EST PAS :\nLes relations amicales sont couvertes par la composante de niveau 4 « 1.3.4.1 – Besoins pour participer à la vie sociale »\nDans la même logique que pour le reste de la nomenclature, les besoins correspondent à un écart (principe d’évaluation de la situation), il ne s’agit donc pas des réponses à mettre en œuvre pour les compenser (principe d’accompagnement)."
    }]
  },
  {
    "code" : "1.1.1",
    "display" : "Besoins en matière de fonctions mentales, psychiques, cognitives et du système nerveux",
    "property" : [{
      "code" : "parent",
      "valueCode" : "1.1"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 4"
    },
    {
      "code" : "note",
      "valueString" : "Cette composante de niveau 3 traite des structures et des fonctions du cerveau c’est-à-dire les fonctions mentales, psychiques, cognitives et le système nerveux. Pour faciliter la compréhension de ce que recouvre cette entité de besoins, le groupe technique national et l’équipe SERAFIN-PH ont fait le choix de compléter l’intitulé de la CIF (fonctions mentales) par les notions de fonctions mentales, psychiques, cognitives (plutôt que des fonctions supérieures) et du système nerveux.\nCet intitulé permet une meilleure lisibilité de certaines fonctions à l’origine ou faisant partie d’un grand nombre de situations de handicap.\nDESCRIPTION \nBesoins en lien avec les fonctions du cerveau (fonctions mentales dont cognitives et psychiques).\nBesoins quant aux structures du cerveau, de la moelle épinière et des nerfs\nCODES CIF CORRESPONDANTS (OMS, 2001)\nCette composante de niveau 4 porte sur l’ensemble des deux chapitres :\n◦\tb1 - fonctions mentales\no\tdont b110 Fonctions de la conscience : Fonctions mentales générales de l'état de conscience de soi et de vigilance, y compris la clarté et la continuité de l'état de veille.\no\tdont b122 Fonctions psychosociales globales : Fonctions mentales générales qui se développent au cours de la vie, nécessaires pour comprendre et pour intégrer de manière constructive les fonctions mentales qui président à la formation des aptitudes aux relations sociales réciproques permettant les interactions en société, tant en termes de signification que de finalité.\no\tdont b130 Fonctions de l'énergie et des pulsions : Fonctions mentales générales des mécanismes physiologiques et psychologiques qui poussent l'individu à aller de l'avant avec persistance pour répondre à des besoins spécifiques et atteindre des buts généraux.\no\tdont b134 Fonctions du sommeil : Fonctions mentales générales du désengagement périodique, réversible et sélectif, physique et mental, par rapport à son environnement immédiat, accompagné de changements physiologiques caractéristiques.\n◦\ts1 - structures du système nerveux\no\tstructure du cerveau\no\tstructure de la moelle épinière\no\tstructure des méninges\no\tstructure du système nerveux végétatif\no\tstructure du système nerveux parasympathique\nCE QUE CE N’EST PAS\nIl ne s’agit pas des besoins d’accès aux soins courants, qui sont couverts par la composante « 1.1.1.10 – Besoins pour entretenir et prendre soin de sa santé ».\nDans la même logique que pour le reste de la nomenclature, les besoins correspondent à un écart (principe d’évaluation de la situation), il ne s’agit donc pas des réponses à mettre en œuvre pour les compenser (principe d’accompagnement)."
    }]
  },
  {
    "code" : "3.1.3.1",
    "display" : "Communication (interne et externe), statistiques, rapport annuel et documents collectifs 2002-2",
    "property" : [{
      "code" : "parent",
      "valueCode" : "3.1.3"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 4"
    },
    {
      "code" : "note",
      "valueString" : "Cette prestation correspond à la :\n \tCommunication interne et externe (conception, édition et diffusion de journaux, revues, plaquettes, conception et maintenance d’un intranet ou d’un site web…), conception de supports multimédia, relation avec les médias, notamment sur le territoire d’intervention,\n \tGestion des statistiques, conception, édition et diffusion des rapports annuels,\n \tConception, édition et diffusion des documents collectifs de la loi 2002-2 (projet d’établissement ou de service, règlement de fonctionnement, livret d’accueil etc.) \nLes professionnels réalisant ces prestations sont notamment:\n-\tles professionnels cadres fonctionnels non hiérarchiques et professionnels non cadres dédiés, comme les journalistes, chargés de communication, secrétaires dédiés, graphistes, gestionnaires de sites WEB et intranet…\n-\téventuellement des professionnels extérieurs."
    }]
  },
  {
    "code" : "2.4.1",
    "display" : "Prestation de coordination renforcée pour la cohérence du parcours",
    "property" : [{
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "versionInfo",
      "valueString" : "Raison de l'inactivation : concept dupliqué"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2023-01-01T00:00:00+01:00"
    },
    {
      "code" : "note",
      "valueString" : "La prestation de coordination renforcée pour la cohérence du parcours s’impose ou prend le relai de la coordination usuelle mise en œuvre par les professionnels accompagnant des personnes en situation de handicap, lorsque cette dernière ne constitue plus une réponse suffisante.  \nLes accompagnements sont souvent pluridisciplinaires et s’inscrivent dans un cadre partenarial. C’est pourquoi la coordination est indissociable de la mise en œuvre de chaque prestation. \nEn effet chaque prestation directe présente trois caractéristiques parmi lesquelles deux sont directement liées à la notion de coordination : \n\tLa notion de prestation inclut des éléments qui font partie intégrante de son processus de réalisation. Ces éléments de processus sont des manières de faire et des étapes de réalisation. Il s’agit par exemple de l’entrée/l’admission dans une structure médico-sociale, la sortie de cette structure, l’évaluation, la définition et la coordination du projet personnalisé, la mise en œuvre de la prestation en face à face avec la personne, l’évaluation régulière de la situation, des objectifs, des actions mises en œuvre et des résultats, etc.\nCes différentes actions ne sont pas forcément chronologiques ou successives dans le temps mais peuvent être concomitantes. Dans cet ensemble de ces activités qui font processus, la coordination fait donc partie intégrante de l’accompagnement et de la manière de réaliser chaque prestation. Ce niveau de coordination est parfois dit « usuel » ou « ordinaire ». \n\tLes prestations directes comprennent toutes les interventions répondant aux besoins de la personne y compris en son absence (hors face à face)  sous réserve que cette modalité permette de répondre aux besoins de la personne. \nCompte tenu de ces principes, la nomenclature des prestations n’identifie pas spécifiquement la coordination ordinaire ou usuelle entre professionnels (y compris entre professionnels évoluant dans des structures ou secteurs différents) pour la réalisation d’un projet personnalisé. Cette coordination est intrinsèque à la conduite d’un accompagnement de qualité, elle fait partie du processus de réalisation de chaque prestation et n’a pas à être décrite de manière distincte de la prestation. \nExemples : \n-\tTravailler avec l’enseignant peut constituer une démarche de coordination attendue pour la mise en œuvre de la prestation d’accompagnements pour mener sa vie d’élève, d’étudiant ou d’apprenti. \n-\tL’organisation du travail : les réunions d’équipes, les réunions pluridisciplinaires font également partie du processus de réalisation des prestations pour mener sa vie professionnelle.\nLa nomenclature des prestations distingue : \n\tla coopération avec les acteurs du territoire (conventionner, former des partenaires, échanger des pratiques, participer à des instances administratives) visant à améliorer l’accompagnement global des personnes et l’identifie parmi les prestations indirectes (3.1.5 relations avec le territoire). \n\tune prestation de coordination dite renforcée qui présente un niveau de complexité supérieur à la coordination dite usuelle ou ordinaire mise en œuvre par les professionnels.\nLa distinction entre la coordination usuelle et coordination renforcée pour la cohérence du parcours est en partie dépendante des organisations et de leurs évolutions : une structure identifiera la nécessité d’une coordination renforcée là où une autre structure placerait à un niveau supérieur de complexité la frontière entre les deux niveaux d’intensité de la coordination.   \nLe groupe technique national SERAFIN-PH a identifié deux caractéristiques constitutives de la coordination renforcée pour la cohérence du parcours. Ces caractéristiques se réfèrent à la complexité de la situation d’une part, et de l’accompagnement d’autre part. Elles sont cumulatives. \n1ere caractéristique : la complexité de la situation\n \tLa coordination renforcée peut consister à construire un plan d’accompagnement global (PAG) pour répondre à des situations complexes, du fait du projet de la personne et de l’offre territoriale à mobiliser pour répondre aux besoins de la personne.  \nCe PAG ainsi élaboré peut être temporaire, alternatif ou pérenne. \nLes situations de rupture, les personnes n’ayant pas de solution d’accompagnement, les périodes de transition à venir ou en cours constituent autant de repères de complexité (cf.  Recommandation « Pratiques de coopération et de coordination du parcours de la personne handicapée  » de la Haute Autorité de Santé)\n2eme caractéristique : un accompagnement complexe portant sur plusieurs domaines de prestations et relevant de partenaires nombreux et appartenant à des secteurs différents. \n \tLa coordination renforcée répond à un niveau de complexité supérieur du fait de partenaires concourant à la mise en œuvre du projet plus nombreux et relevant de secteurs différents (social, sanitaire, ’éducation nationale et enseignement supérieur,  formation professionnelletravail, etc.). Le caractère multisectoriel est un critère de complexité dans la mesure où il constitue également un risque de morcellement de l’accompagnement et nécessite donc une concertation rapprochée.\n \tL’accompagnement est en outre caractérisé par un recours à des prestations relevant de différents domaines des prestations (soins, autonomie, participation sociale). \nLa coordination renforcée présente d’autres caractéristiques : \n \tElle vise à mobiliser les ressources du territoire et à permettre la mise en œuvre d’actions parfois innovantes, en réunissant en particulier les directions des structures concernées et les autorités de contrôle et de tarification  pour apporter une réponse à la personne assurant  la cohérence globale de son parcours d’accompagnement. \n \tDans le cadre d’une prestation de coordination renforcée, les acteurs parties prenantes de l’accompagnement (professionnels, aidants, etc.) sont garants :  \no\tde la réalisation d’une analyse croisée et partagée de la situation.. \no\tde la coresponsabilité des différents acteurs dans l’accompagnement de la personne. \n \tUne évaluation multidimensionnelle peut être pilotée par une structure médico-sociale ou tout autre acteur qualifié identifié au moment de la concertation. Une personne référente (coordonnateur de parcours) est ainsi nommée pour être garante de la mise en œuvre des accompagnements décidés dans ce temps de coordination, et qui peut donner lieu à un plan d’accompagnement global (PAG). La personne référente est amenée à retracer les engagements réciproques de chaque acteur. \nDu fait de la complexité à laquelle elle répond, la mise en œuvre d’une prestation de coordination renforcée est nécessairement structurée autour de différentes étapes et s’appuie sur différents outils : \n \tdétermination des objectifs,  formalisation d’un projet personnalisé ou d’un PAG fondé sur une évaluation multidimensionnelle,  \n \tidentification des acteurs ressources des différents champs pour répondre au projet de la personne, \n \tcoordination des interventions effectuées pour assurerla continuité du parcours d’accompagnement de la personne, \n \tévaluation et traçabilité du suivi du parcours  (recensement des actions conduites et desobjectifs à atteindre,  à poursuivre,…). \nCes éléments font partie du processus de la prestation. \nLa coordination renforcée ne constitue pas l’apanage d’un type de dispositif de coordination ou de plateforme, elle est cependant proche de notions préexistantes telles que la « gestion de cas », et de missions réalisées par les dispositifs d’appui à la coordination (convergence des plateformes territoriales d’appui, des « MAIA » et des réseaux de santé territoriaux), pôles de compétences et de prestations externalisées (PCPE) ou des équipes-relais handicap rare. \nElle peut être réalisée par tous les professionnels.  \nBESOINS AUXQUELS LA PRESTATION REPOND : \nCette prestation constitue une exception au principe selon lequel toutes les prestations de soins et d’accompagnement constituent une réponse à un ou plusieurs besoins identifiés dans la nomenclature des besoins. \nElle ne remplace aucune des prestations de la nomenclature des prestations. Elle est de même nature que la coordination usuelle qui relève du processus de réalisation de toute prestation et ne s’en distingue que par son niveau d’intensité, qui garantit la meilleure réponse possible à plusieurs besoins de la personne dans une situation complexe."
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "1.1.9",
    "display" : "Besoins relatifs à la peau et aux structures associées",
    "property" : [{
      "code" : "parent",
      "valueCode" : "1.1"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 4"
    },
    {
      "code" : "note",
      "valueString" : "Cette composante de niveau 3 traite de la peau et des structures associées. Elle sera notamment mobilisée dans le cas de la présence d’escarres ou dans leur prévention. \nDESCRIPTION \nBesoins en lien avec les fonctions de la peau, des ongles, des cheveux et des poils\nBesoins quant aux structures de la peau\nCODES CIF CORRESPONDANTS (OMS, 2001)\nCette composante de niveau 4 porte sur l’ensemble des deux chapitres :\n◦ b8 – Fonctions de la peau et des structures associées\no\tFonctions de la peau\no\tFonctions relatives aux cheveux, aux poils et aux ongles\n◦ s8 – Peau et structures annexes\no\tStructures des aires de la peau\no\tStructures des glandes cutanées\no\tStructures des ongles\no\tStructures des cheveux et des poils\nCE QUE CE N’EST PAS\nIl ne s’agit pas des besoins d’accès aux soins courants couverts par la composante « 1.1.1.10 – Besoins pour entretenir et prendre soin de sa santé ».\nDans la même logique que pour le reste de la nomenclature, les besoins correspondent à un écart (principe d’évaluation de la situation), il ne s’agit donc pas des réponses à mettre en œuvre pour les compenser (principe d’accompagnement)."
    }]
  },
  {
    "code" : "2.3.3.2",
    "display" : "Accompagnements pour préparer sa vie professionnelle",
    "property" : [{
      "code" : "parent",
      "valueCode" : "2.3.3"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 4"
    },
    {
      "code" : "note",
      "valueString" : "Cette prestation rassemble tous les accompagnements effectués auprès d’une personne en situation d’exercice professionnel pour répondre aux besoins transversaux qu’elle rencontre pour intégrer un travail / emploi, et à ses besoins transversaux en matière d’apprentissage.\nEn outre ces prestations s’inscrivent dans une logique de compensation qui inclut toutes les nuances d’un accompagnement : « apprendre à faire », « faire avec », « faire pour (ou à la place de) ». Elles ont pour objectif le développement, l’acquisition et le maintien du maximum d’autonomie de la personne.\nBESOINS AUXQUELS LA PRESTATION REPOND : \n\tBesoins transversaux en matière d’apprentissages : \n \tBesoins pour les apprentissages élémentaires (apprendre à lire, à écrire, à calculer, acquérir un savoir-faire)\n \tBesoins pour appliquer des connaissances (pour fixer son attention, pour mémoriser, pour lire, pour écrire, pour calculer, pour résoudre des problèmes, respecter les règles sociales de base, s'installer dans la classe, utiliser les supports pédagogiques)\n\tBesoins en lien avec le travail et l’emploi :\n \tBesoins pour obtenir une activité professionnelle ou à caractère professionnel\n \tBesoins transversaux en lien avec le travail et l'emploi\nCes besoins transversaux ont été précisés, à la demande des membres du groupe technique national par le recours au volet 6 du GEVA. Il s’agit donc des besoins pour être ponctuel, organiser son travail, accepter des consignes, suivre des consignes, être en contact avec le public, assurer l’encadrement, travailler en équipe, exercer des tâches physiques, autres besoins. \nCE QUE CE N’EST PAS : \n\tD’autres accompagnements peuvent se dérouler pendant le temps de formation. Ils sont alors rattachés aux prestations afférentes, en matière d’autonomie, de soins ou de participation sociale. \nCes accompagnements sont notamment : \n◦\tdes temps d’accompagnement visant à soutenir la personne en emploi dans le cadre d’une formation continue\n◦\tdes temps de bilan et d’accompagnement, notamment par l’intermédiaire des dispositifs de droit commun, pour l’orientation professionnelle, la réorientation professionnelle (dont la recherche de stage) et la recherche d’un emploi. \nCes accompagnements se déroulent en particulier dans tous les lieux de formation de l’usager quel qu’en soit la forme administrative.  \nCes prestations sont réalisées, à titre principal, par : \n\tdes enseignants  qu’ils soient salariés ou mis à disposition de l’établissement ou du service médico-social par l’éducation nationale\n\tdes professionnels sociaux et éducatifs de l’accompagnement et en particulier des éducateurs et moniteurs : éducateurs spécialisés, éducateurs techniques, moniteurs d’atelier, etc."
    }]
  },
  {
    "code" : "1.3.4.1",
    "display" : "Besoins pour participer à la vie sociale",
    "property" : [{
      "code" : "parent",
      "valueCode" : "1.3.4"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 4"
    },
    {
      "code" : "note",
      "valueString" : "Cette composante de niveau 4 porte sur la participation à la vie sociale en particulier lors des récréations et loisirs, les congés, l’accueil de la petite enfance et les relations amicales.\nDESCRIPTION : \nBesoins en lien avec la récréation et les loisirs\nBesoins pour partir en congés\nBesoins pour l'accueil périscolaire\nBesoins pour l'accueil de la petite enfance\nBesoins pour entretenir des relations amicales ou professionnelles\nCODES CIF CORRESPONDANTS (OMS, 2001) :\nLa composante de niveau 4 porte sur une partie des chapitres 7 (Relations et interactions avec autrui) et 9 (vie communautaire, sociale et civique) des activités et participation de la CIF : \n◦\td750 Relations sociales informelles \nEngager des relations avec autrui, comme des relations informelles avec des personnes du voisinage ou de la même résidence, ou avec des collègues de travail, des étudiants, des compagnons de jeux, des personnes ayant les mêmes affinités ou la même profession. \n◦\td920 Récréation et loisirs \nS'investir dans toute forme de jeu, d'activité récréative ou de loisirs, comme des jeux ou des activités sportives informelles ou organisées, des programmes d'exercice physique, de détente, d'amusement ou de divertissement, visiter des galeries d'art, des musées, aller au cinéma ou au théâtre; faire de l'artisanat ou s'adonner à un hobby, lire pour le plaisir, jouer de la musique, faire du tourisme et voyager pour le plaisir.\nd720 Interactions complexes avec autrui\nNouer des relations amicales ou professionnelles, mettre fin à des relations, dans le respect des convenances.\nCE QUE CE N’EST PAS :\nDans la même logique que pour le reste de la nomenclature, les besoins correspondent à un écart (principe d’évaluation de la situation), il ne s’agit donc pas des réponses à mettre en œuvre pour les compenser (principe d’accompagnement)."
    }]
  },
  {
    "code" : "2.1.1.1",
    "display" : "Soins médicaux à visée préventive, curative et palliative",
    "property" : [{
      "code" : "parent",
      "valueCode" : "2.1.1"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 4"
    },
    {
      "code" : "note",
      "valueString" : "Cette prestation est réalisée à titre principal par les professionnels médicaux (médecins toutes spécialités, chirurgiens-dentistes et sages-femmes / maïeuticiens).\nBESOINS AUXQUELS CES PRESTATIONS REPONDENT :\nElles répondent aux besoins des personnes en matière de santé somatique ou psychique pour lesquels les réponses attendues relèvent de l’intervention des professionnels médicaux. Les soins bucco-dentaires sont couverts par cette composante.\nCes besoins sont identifiés au niveau des différentes structures et fonctions du corps ainsi que pour entretenir et prendre soin de sa santé."
    }]
  },
  {
    "code" : "2.2.3",
    "display" : "Accompagnements pour prendre des décisions adaptées et pour la sécurité",
    "property" : [{
      "code" : "parent",
      "valueCode" : "2.2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 4"
    },
    {
      "code" : "note",
      "valueString" : "Cette composante de niveau 4 recouvre un ensemble d’actions réalisées pour permettre à la personne de prendre des décisions visant à garantir sa sécurité et/ou celle des autres. \nL’accompagnement pour la prise de décisions adaptées à la situation passe par exemple par l’accompagnement de la personne dans la mise en place d’outils de repérage et d’organisation du temps et de l’espace (exemple : mise en place de routines quotidiennes, de pratiques permettant la gestion de son stress). Ces accompagnements ont donc pour objectif de prévenir la survenue d’un risque de mise en danger.. Par ailleurs, cette prestation peut aussi être réalisée pour gérer un risque identifié de sécurité ou de mise en danger.\nCette prestation peut notamment être réalisée par les professionnels suivants : \n\tdes aides médico psychologiques\n\tdes éducateurs et moniteurs : éducateurs spécialisés, éducateurs de jeunes enfants. \nPar ailleurs, comme l’ensemble des prestations en matière d’autonomie, elle s’inscrit dans une logique de compensation qui recouvre toutes les nuances de l’accompagnement qui a pour objectif l’acquisition et le maintien du maximum d’autonomie de la personne : de « apprendre à la personne à faire », à « faire avec », jusqu’à « faire pour (ou à la place de) ».\nBESOINS AUXQUELS LA PRESTATION REPOND : \nBesoins pour prendre des décisions adaptées et pour la sécurité\n\tBesoins pour s'orienter dans le temps et dans l'espace\n\tBesoins pour prendre des décisions et initiatives\n\tBesoins pour gérer le stress et les autres exigences psychologiques (dont ne pas se mettre en danger et ne pas mettre les autres en danger) \nExemple : \nAccompagner un adulte présentant des besoins en lien avec les fonctions cognitives, des besoins en lien avec les fonctions auditive et visuelle (comme une très grande sensibilité auditive et visuelle) et des besoins pour gérer le stress et les exigences psychologiques peut signifier : \n \t « Faire pour » : comprendre, repérer puis limiter les situations pouvant générer des manifestations de stress mettant en danger la sécurité de la personne ou des autres, limiter les conséquences sur la sécurité des crises lorsque celles-ci ont lieu. \n \t « Apprendre à » et « faire avec » : identifier, mettre en œuvre puis susciter l’utilisation autonome de techniques de retrait par la personne (ex : port d’un casque) permettant à celle-ci de gérer ou d’anticiper un comportement à risque, une crise.\nCE QUE CE N’EST PAS : \n\tIl ne s’agit pas d’une prestation de réponse-type aux situations « critiques » ou « complexes » ces dernières mobilisant des modalités diverses d’accompagnement"
    }]
  },
  {
    "code" : "3.1.1.1",
    "display" : "Pilotage et direction",
    "property" : [{
      "code" : "parent",
      "valueCode" : "3.1.1"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 4"
    },
    {
      "code" : "note",
      "valueString" : "La prestation pilotage et direction correspond aux activités exercées par des personnels cadres qui bénéficient d’une délégation de pouvoirs de l’employeur (DUP), d’une subdélégation ou sont responsables de l’entretien annuel d’évaluation d’une équipe.\nIl s’agit donc des cadres « hiérarchiques » :\n-\tdirecteurs, directeurs adjoints, médecins cadres hiérarchiques (médecins directeurs, directeurs médicaux, conseillers médicaux, etc.),\n-\tchefs de service éducatif, chefs de service pédagogique, chefs de service paramédical, chefs de service administratif et financier, chef d’ateliers, cadres infirmiers, etc."
    }]
  },
  {
    "code" : "1.2.1.2",
    "display" : "Besoins en lien avec les relations et les interactions avec autrui",
    "property" : [{
      "code" : "parent",
      "valueCode" : "1.2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 3"
    },
    {
      "code" : "note",
      "valueString" : "Cette composante de niveau 3 traite des relations et interactions avec autrui et de la communication. Les relations familiales et intimes ne sont pas couvertes par cette composante (voir fiche 1.3.3.4 – besoins pour la vie familiale, la parentalité, la vie affective et sexuelle).\nDESCRIPTION : \nBesoins pour communiquer, mener une conversation ou une discussion\nBesoins pour les interactions avec autrui\nBesoins pour les relations particulières avec autrui\nBesoins pour utiliser des appareils et techniques de communication\nCODES CIF CORRESPONDANTS (OMS, 2001) :\nLa composante de niveau 4 porte sur l’ensemble des chapitres 3 et 7 des activités et participation sociale de la CIF :\n◦\td3 – Communication\nCe chapitre porte sur les aspects généraux et particuliers de la communication par le langage, les signes et les symboles, et notamment la production et la réception de messages, la conduite d'une conversation, et l'utilisation d'appareils et de techniques de communication.\nAttention : ce code CIF est également utilisé pour les besoins transversaux en matière d’apprentissage. Il est à distinguer l’apprentissage d’un moyen de communication et l’accompagnement dans la perception ou la réception de messages par l’intermédiaire de ce moyen de communication acquis par ailleurs.\n◦\td7 – Relations et interactions avec autrui\nCe chapitre traite des activités et tâches nécessaires pour avoir une vie de relation avec d'autres personnes (étrangers, amis,…) en fonction de diverses situations et dans le respect des convenances.\no\td710 à d729 - Interactions générales avec autrui\n\tInteractions de base avec autrui : avoir des relations avec d'autres personnes en fonction de diverses situations et dans le respect des convenances, comme faire preuve de respect ou d'estime quand il le faut, ou avoir des égards pour autrui.\n\tInteractions complexes avec autrui : entretenir et maîtriser les relations avec autrui selon les circonstances et dans le respect des convenances, comme maîtriser ses émotions et ses pulsions, maîtriser son agressivité verbale et physique, agir de manière indépendante dans les relations sociales, et agir selon les règles et conventions sociales.\no\td730 à d779 - Relations particulières avec autrui\n\tRelations avec les étrangers\n\tRelations formelles\n\tRelations sociales informelles\nCE QUE CE N’EST PAS :\nDans la même logique que pour le reste de la nomenclature, les besoins correspondent à un écart (principe d’évaluation de la situation), il ne s’agit donc pas des réponses à mettre en œuvre pour les compenser (principe d’accompagnement).\nPar ailleurs, il ne s’agit pas des besoins pour s’occuper de sa famille, pour la parentalité, ainsi que pour la vie affective et sexuelle. Ces besoins sont couverts par la composante de niveau 4 « 1.3.3.4 – Besoins pour la vie familiale, la parentalité, la vie affective et sexuelle ».\nIl ne s’agit pas non plus des besoins transversaux en matière d’apprentissage, qui incluent l’apprentissage de techniques ou pratiques de communication comme le braille ou la langue des signes française."
    }]
  },
  {
    "code" : "3.1.3",
    "display" : "Information et communication",
    "property" : [{
      "code" : "parent",
      "valueCode" : "3.1"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 3"
    },
    {
      "code" : "note",
      "valueString" : "La composante de niveau 3 « information et communication » comprend toutes les prestations de la structure médico-sociale liées aux trois composantes de niveau 4 suivantes :\n\tCommunication interne et externe\n\tGestion des données des personnes accueillies\n\tGestion des systèmes d’information, télécommunications, (technologies d’information et de communication – TIC), archivage informatique des données et gestion électronique des documents (GED)."
    },
    {
      "code" : "child",
      "valueCode" : "3.1.3.1"
    },
    {
      "code" : "child",
      "valueCode" : "3.1.3.2"
    }]
  },
  {
    "code" : "1.3.3.1",
    "display" : "Besoins en lien avec la vie scolaire et étudiante",
    "property" : [{
      "code" : "parent",
      "valueCode" : "1.3.3"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 4"
    },
    {
      "code" : "note",
      "valueString" : "Cette composante de niveau 4 traite des besoins en lien avec la vie scolaire et la vie étudiante quel que soit le contenu du programme suivi (enseignement général, professionnel). \nLes apprentissages transversaux comme apprendre à lire, à écrire, à calculer, à résoudre des problèmes, etc… ne sont pas couverts par cette composante. Les adultes, hors parcours scolaire initial notamment, peuvent aussi avoir des besoins en lien avec ces apprentissages. Pour cette raison, les apprentissages transversaux bénéficient d’une composante dédiée (voir Fiche 1.3.3.3 – Besoins transversaux en matière d’apprentissages).\nDESCRIPTION : \nBesoins pour l'éducation préscolaire\nBesoins pour l'éducation scolaire\nBesoins pour l'éducation supérieure\nCODES CIF CORRESPONDANTS (OMS, 2001) :\nLa composante de niveau 4 porte sur les activités/participation sociale du chapitre 8 (Grands domaines de la vie) de la CIF : \n◦\td810 - d839 – Education \no\tPréscolaire : apprendre à un premier niveau d'instruction organisée, conçu avant tout pour donner à l'enfant un avant-goût de l'environnement scolaire et le préparer à l'instruction obligatoire\nLa CIF précise cette définition par l’exemple suivant : « par exemple en fréquentant une garderie ou un cadre similaire en vue de se préparer à aller à l'école ».\nCet exemple ne correspond pas à l’organisation de la scolarisation en France qui distingue : une éducation préscolaire (maternelle) une éducation scolaire correspondant à une scolarisation obligatoire (de 6 à 16 ans). La CIF étant élaborée sur la base d’un consensus international elle ne tient pas compte des politiques publiques nationales. \nPar conséquent, dans le cadre de la nomenclature des besoins SERAFIN-PH, le besoin pour l’éducation préscolaire correspond aux besoins lié à la scolarisation en maternelle. Le besoin pour l’accueil de la petite enfance (crèche, garderie, assistants familiaux) est couvert par la composante 1.3.4.1 - besoins pour participer à la vie sociale.  \no\tScolaire : entrer à l'école, participer à toutes les activités scolaires, avec leurs responsabilités et leurs privilèges, apprendre les leçons, les matières et satisfaire aux exigences du programme dans un programme d'éducation primaire et secondaire, notamment en fréquentant l'école régulièrement, en collaborant avec les autres élèves, en suivant les instructions du professeur, en organisant, en étudiant et en effectuant ses devoirs et autres projets, et en progressant vers d'autres niveaux d'éducation.\no\tProfessionnelle : suivre les activités d'un programme de formation professionnelle et apprendre les cours qui préparent à un emploi dans le commerce, un métier ou une autre profession.\no\tSupérieure : suivre les activités proposées dans le cadre de programmes d'études universitaires, écoles supérieures et écoles professionnelles et étudier les différents aspects d'un programme en vue de l'obtention d'un diplôme, d'un certificat ou toute autre reconnaissance de compétences, comme terminer une licence ou une maîtrise, suivre le programme d'une école de médecine ou d'une autre école professionnelle.\nCE QUE CE N’EST PAS :\nLes besoins en lien avec les exigences propres à une activité professionnelle, par exemple sur son lieu de stage  pour un lycéen en formation en alternance, relèvent du « 1.3.3.2 – besoins en lien avec le travail et l’emploi ».\nLes apprentissages élémentaires (apprendre à lire, à écrire, à compter,…) et l’application des connaissances ne font pas partie de cette composante, car ils bénéficient d’une composante de niveau 4 spécifique : « 1.3.3.3 – besoins transversaux en matière d’apprentissages ».\nDans la même logique que pour le reste de la nomenclature, les besoins correspondent à un écart (principe d’évaluation de la situation), il ne s’agit donc pas des réponses à mettre en œuvre pour les compenser (principe d’accompagnement)."
    }]
  },
  {
    "code" : "1.1.6",
    "display" : "Besoins en matière de fonctions digestive, métabolique et endocrinienne",
    "property" : [{
      "code" : "parent",
      "valueCode" : "1.1"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 4"
    },
    {
      "code" : "note",
      "valueString" : "Cette composante de niveau 3 traite des fonctions des systèmes digestif, métabolique et endocrinien.\nDESCRIPTION \nBesoins en lien avec les fonctions de digestion et d'élimination, de même que les fonctions du métabolisme et des glandes endocrines.\nBesoins quant aux structures liées aux systèmes digestif, métabolique et endocrinien.\nCODES CIF CORRESPONDANTS (OMS, 2001)\nCette composante de niveau 4 porte sur l’ensemble des deux chapitres :\n◦ b5 – Fonctions des systèmes digestif, métabolique et endocrinien\n◦ s5 – Structures liées aux systèmes digestif, métabolique et endocrinien\nCE QUE CE N’EST PAS \nIl ne s’agit pas des besoins d’accès aux soins courants couverts par la composante «  1.1.1.10 – Besoins pour entretenir et prendre soin de sa santé ».\nDans la même logique que pour le reste de la nomenclature, les besoins correspondent à un écart (principe d’évaluation de la situation), il ne s’agit donc pas des réponses à mettre en œuvre pour les compenser (principe d’accompagnement)."
    }]
  },
  {
    "code" : "3.1.4.1",
    "display" : "Démarche d’amélioration continue de la qualité",
    "property" : [{
      "code" : "parent",
      "valueCode" : "3.1.4"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 4"
    },
    {
      "code" : "note",
      "valueString" : "Cette prestation correspond :\n\tAu pilotage de la démarche d’amélioration continue de la qualité des prestations réalisées par la structure.\n\tA la veille sur les recommandations de bonnes pratiques professionnelles, recommandations et propositions (rapports, guides et outils de la HAS, de l’ANAP, etc.), à leur diffusion et appropriation au sein de la structure. \n\tÀ la préparation et à la mise en œuvre des évaluations internes et externes.\n\tÀ la promotion de la bientraitance (conception de la politique, diffusion et appropriation, amélioration des procédures de gestion des incidents et évènements indésirables).\n\tÀ la gestion des risques, y compris infectieux (la conception et l’actualisation du plan de continuité de l’activité de l’organisme en cas de crise) ) et la gestion des crises (conséquences organisationnelles des mouvements sociaux, des incidents, de crises épidémiques, terroristes, environnementales, etc.). \n\tÀ la sécurité des biens des personnes accompagnées, des visiteurs et des collaborateurs (évaluation des risques de vols ou de destructions des biens), et la sécurité des personnes.\n\tAux préconisations en toute matière sur ces sujets.\nCette prestation concerne la qualité des interventions réalisées par la structure en direction des personnes elles-mêmes.\nCE QUE CE N’EST PAS :\n\tL’amélioration et le contrôle de la gestion sont identifiés parmi les prestations de la « gestion administrative, budgétaire, financière et comptable » 3.1.2.\n\tLes prestations en lien avec la sécurité et l’hygiène des locaux (quel que soit leur usage) et l’entretien des espaces extérieurs est identifié en 3.2.1.5)"
    }]
  },
  {
    "code" : "2.3.3.5",
    "display" : "Accompagnements de la vie familiale, de la parentalité, de la vie affective et sexuelle",
    "property" : [{
      "code" : "parent",
      "valueCode" : "2.3.3"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 4"
    },
    {
      "code" : "note",
      "valueString" : "Cette prestation rassemble les accompagnements réalisés dans le contexte de la vie familiale, dans le cadre d’un désir ou d’une situation de parentalité, et dans les situations de vie affective et sexuelle. \nEn outre ces prestations s’inscrivent dans une logique de compensation qui inclut toutes les nuances d’un accompagnement : « apprendre à faire », « faire avec », « faire pour (ou à la place de) ».. Elles ont pour objectif le développement, l’acquisition et le maintien du maximum d’autonomie de la personne. \nExemples : \n◦\tAccompagnement réalisé par un professionnel social et éducatif de l’accompagnement, au domicile de jeunes parents présentant des des besoins dans leur relation avec leur enfant afin de mettre en pratique les recommandations apportées par les professionnels de droit commun pour assurer son développement (nutrition, suivi médical, etc.), son suivi scolaire et plus largement toutes dimensions relatives à son éducation.  \n◦\tAteliers sur les conditions à réunir pour entretenir des relations sexuelles (droits et libertés d’orientation été de pratique sexuelle, respect du consentement, respect des règles relatives à l’attentat à la pudeur, contraception, etc.)  \n◦\tInterventions de plannings familiaux au sein des ESMS relayées et accompagnées par les professionnels de la structure.\nBESOINS AUXQUELS LA PRESTATION REPOND : \n\tBesoins pour la vie familiale, la parentalité, la vie affective et sexuelle :\n \tBesoins pour s’occuper de sa famille\n \tBesoins pour la parentalité\n \tBesoins pour la vie affective et sexuelle \n\tBesoins transversaux en matière d’apprentissages : \n \tRespecter les normes sociales de base"
    }]
  },
  {
    "code" : "2.3.4.2",
    "display" : "Accompagnements pour la participation aux activités sociales et de loisirs",
    "property" : [{
      "code" : "parent",
      "valueCode" : "2.3.4"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 4"
    },
    {
      "code" : "note",
      "valueString" : "Cette prestation regroupe les accompagnements effectués pour permettre la participation des personnes accompagnées aux activités sociales qui correspondent à leur projet de vie.\nIl s’agit par exemple : \n\tDe l’accompagnement éducatif effectué pour la mise en œuvre d’activités sportives, culturelles, de loisirs, en dehors de la structure médico-sociale. \n\tDe l’accompagnement éducatif effectué dans les structures de droit commun auprès des personnes pour favoriser par exemple la fréquentation des centres de loisirs et de l’ensemble des dispositifs d’accueil de la petite enfance par les enfants accompagnés par le service ou l’établissement.\n\tDe l’accompagnement éducatif réalisé dans une structure médico-sociale avec un partenaire extérieur non issu du secteur médico-social. Par exemple, l’organisation de l’intervention d’un professionnel issu du milieu sportif ou culturel au sein d’un ESMS participe des accompagnements pour la participation aux activités sociales et de loisirs.\nEn outre ces prestations s’inscrivent dans une logique de compensation qui inclut toutes les nuances d’un accompagnement : « apprendre à faire », « faire avec », « faire pour (ou à la place de) ». Elles ont pour objectif le développement, l’acquisition et le maintien du maximum d’autonomie de la personne.\nBESOINS AUXQUELS LA PRESTATION REPOND : \n\tBesoins pour participer à la vie sociale : \n◦\tBesoins en lien avec la récréation et les loisirs, \n◦\tBesoins pour partir en congés\n◦\tBesoins pour l'accueil périscolaire\n◦\tBesoins pour l'accueil de la petite enfance\nCE QUE CE N’EST PAS : \n\tLa mise en place d’un accueil de jour par une structure médico-sociale constitue une prestation d’accompagnement pour réaliser des « activités de jour spécialisées »."
    }]
  },
  {
    "code" : "3.2.3.1",
    "display" : "Entretenir le linge",
    "property" : [{
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "versionInfo",
      "valueString" : "Raison de l'inactivation : concept dupliqué"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2023-01-01T00:00:00+01:00"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "2.2.2",
    "display" : "Accompagnements pour la communication et les relations avec autrui",
    "property" : [{
      "code" : "parent",
      "valueCode" : "2.2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 4"
    },
    {
      "code" : "note",
      "valueString" : "L’accompagnement pour la communication et les relations avec autrui comprend les actions visant à encourager, favoriser ou permettre les moyens de communication et les interactions de la personne avec d’autres personnes. \nCes prestations sont réalisées par plusieurs professionnels et en particulier :\n\tdes aides médico psychologiques,\n\tdes éducateurs et moniteurs : éducateurs spécialisés, éducateurs de jeunes enfants,  \n\tdes interprètes, codeurs, interfaces de communication et interprètes\nPar ailleurs, comme l’ensemble des prestations en matière d’autonomie, elles s’inscrivent dans une logique de compensation qui recouvre toutes les nuances de l’accompagnement qui a pour objectif l’acquisition et le maintien du maximum d’autonomie de la personne : de « apprendre à la personne à faire », à « faire avec », jusqu’à « faire pour (ou à la place de) ».\nLES BESOINS AUXQUELS LA PRESTATION REPOND :\nCette prestation répond principalement \no\tA des besoins en lien avec les relations et interactions avec autrui\n\tBesoins pour communiquer, mener une conversation ou une discussion (recevoir, produire des messages, y compris des messages non verbaux, en langue des signes, et des messages écrits).\n\tBesoins pour mener une conversation ou une discussion (engager, soutenir, mettre fin)  avec une ou plusieurs autres personnes."
    }]
  },
  {
    "code" : "3.1.1.2",
    "display" : "Gestion des ressources humaines, de la Gestion previsionnelle des emplois et des competences et du dialogue socIal",
    "property" : [{
      "code" : "parent",
      "valueCode" : "3.1.1"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 4"
    },
    {
      "code" : "note",
      "valueString" : "Cette prestation correspond à la réalisation des activités suivantes :\n-\tLa gestion des ressources humaines pour les personnels de l’ESMS et pour les travailleurs d’ESAT,\n-\tLa production et le suivi des contrats de travail du personnel, \n-\tLe suivi des dossiers du personnel, et le suivi administratif des entretiens annuels d’appréciation, \n-\tLes activités liées au pointage, aux congés, qu’il s’agisse des professionnels de l’ESMS ou des travailleurs d’ESAT\n-\tLa gestion des absences et des maladies et accidents de travail,\n-\tL’élaboration des paies et des déclarations sociales et fiscales, \n-\tLe suivi du service de santé au travail, pour les professionnels de l’ESMS et pour les travailleurs d’ESAT,\n-\tLa gestion des contentieux et la veille juridique relative au droit du travail (loi, règlement, conventions collectives, accords…).\n-\tla gestion prévisionnelle des emplois et compétences (GPEC),\n-\tla gestion de la formation professionnelle continue du personnel de l’ESMS et des travailleurs d’ESAT (FPC),\n-\tla prévention et l’amélioration des conditions de travail (articles L4121-1 à L4121-5 du code du travail) en lien avec le CHSCT ou les CE (risques professionnels, pénibilité, risques psychosociaux),\n-\tle dialogue social et les relations avec les institutions représentatives du personnel (IRP), les délégués du personnel, le comité central d’entreprise, le comité d’entreprise ou le comité d’établissement, les syndicats.\nCE QUE CE N’EST PAS : \n\tLes prestations de soutien aux personnels après un évènement grave (suite à des évènements indésirables, décès, accidents…) sont liés à la prestation « 3.1.4 Qualité et sécurité »."
    }]
  },
  {
    "code" : "3.1.2",
    "display" : "Gestion administrative, budgétaire, financière et comptable",
    "property" : [{
      "code" : "parent",
      "valueCode" : "3.1"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 3"
    },
    {
      "code" : "note",
      "valueString" : "Il s’agit de la réalisation de l’ensemble des missions correspondant :\n\tà la gestion du bâti,\n\tà la gestion budgétaire,\n\tà la gestion financière et comptable (facturation, paiement des charges y compris des salaires, gestion des comptes des résidents),\n\tau contrôle de gestion et au commissariat aux comptes,\n\tà la fonction achats / économat,\n\tà la gestion administrative, \nLes professionnels qui réalisent ces missions sont notamment :\n-\tles professionnels cadres fonctionnels non hiérarchiques,\n-\tles professionnels administratifs"
    },
    {
      "code" : "child",
      "valueCode" : "3.1.2.1"
    },
    {
      "code" : "child",
      "valueCode" : "3.1.2.2"
    }]
  },
  {
    "code" : "1.2.1.3",
    "display" : "Besoins pour la mobilité",
    "property" : [{
      "code" : "parent",
      "valueCode" : "1.2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 3"
    },
    {
      "code" : "note",
      "valueString" : "Cette composante de niveau 3 traite de la mobilité, mais ne couvre pas les déplacements avec un moyen de transport.\nDESCRIPTION : \nBesoins pour changer et maintenir la position du corps.\nBesoins pour porter, déplacer, et manipuler des objets.\nBesoins pour marcher, pour se déplacer.\nCODES CIF CORRESPONDANTS (OMS, 2001) :\nLa composante de niveau 4 porte sur une partie du chapitre 4 des activités et participation sociale de la CIF :\no\td410 à d429 - Changer et maintenir la position du corps  \no\td430 à d449 -  Porter, déplacer, et manipuler des objets \no\td450 à d469 -Marcher et se déplacer\nCes activités portent sur le mouvement en changeant la position du corps ou en allant d'un endroit à l'autre, en portant, en transportant ou en manipulant des objets, en marchant, courant ou grimpant.\nCE QUE CE N’EST PAS :\nDans la même logique que pour le reste de la nomenclature, les besoins correspondent à un écart (principe d’évaluation de la situation), il ne s’agit donc pas des réponses à mettre en œuvre pour les compenser (principe d’accompagnement).\nCette composante de niveau 4 ne porte pas sur les activités pour se déplacer avec un moyen de transport. Elles en sont exclues car couvertes, dans le domaine Participation sociale, par la composante de niveau 4 « 1.3.4.2 – Besoins pour se déplacer avec un moyen de transport »."
    }]
  },
  {
    "code" : "1.2",
    "display" : "Besoins en matière d’autonomie",
    "property" : [{
      "code" : "parent",
      "valueCode" : "1"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 2"
    },
    {
      "code" : "note",
      "valueString" : "Le domaine autonomie recouvre principalement les activités de la vie quotidienne (AVQ) ou activités élémentaires, qui correspondent à l’entretien personnel pour la CIF (se laver, s'habiller, se nourrir, aller aux toilettes) ainsi qu’une partie des activités instrumentales de la vie quotidienne (AIVQ) que sont les relations avec autrui, la mobilité, et prendre des décisions adaptées et pour la sécurité. \nLes AVQ et AIVQ permettent de décrire l’autonomie de la personne dans toutes ses dimensions : l’autonomie fonctionnelle, la capacité fonctionnelle à faire et le comportement autonome (indépendance), la capacité à prendre des décisions selon ses valeurs et à en assumer les conséquences.\nPour décrire les besoins en matière d’autonomie la nomenclature s’appuie sur le chapitre activités et participation sociale de la CIF, ce qui est au cœur de la description du fonctionnement humain dans la CIF.\nLes composantes de niveau 2 et 3 (1.2 et 1.2.1) Besoins en matière d’autonomie se déclinent en 4 composantes de niveau 4 comme suit :\n \t1.2.1.1 – Besoins en lien avec l’entretien personnel ;\n \t1.2.1.2 – Besoins en lien avec les relations et les interactions avec autrui ;\n \t1.2.1.3 – Besoins pour la mobilité ;\n \t1.2.1.4 – Besoins pour prendre des décisions adaptées et pour la sécurité.\nCes activités, qui permettent de mettre en lumière ces besoins, sont présentes, pour la majorité, dans le volet 6 du GEVA.\nCE QUE CE N’EST PAS :\nDans la même logique que pour le reste de la nomenclature, les besoins correspondent à un écart (principe d’évaluation de la situation), il ne s’agit donc pas des réponses à mettre en œuvre pour les compenser (principe d’accompagnement)."
    },
    {
      "code" : "child",
      "valueCode" : "1.2.1.2"
    },
    {
      "code" : "child",
      "valueCode" : "1.2.1.1"
    },
    {
      "code" : "child",
      "valueCode" : "1.2.1.4"
    },
    {
      "code" : "child",
      "valueCode" : "1.2.1.3"
    }]
  },
  {
    "code" : "2.3.1.2",
    "display" : "Accompagnements à l’exercice des droits et libertés",
    "property" : [{
      "code" : "parent",
      "valueCode" : "2.3.1"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 4"
    },
    {
      "code" : "note",
      "valueString" : "Cette prestation comprend les accompagnements mis en œuvre par les professionnels pour permettre l’exercice des droits et libertés des personnes en situation de handicap. \nIl s’agit d’accompagner la connaissance, la compréhension et le plein exercice des droits fondamentaux et libertés individuelles, contextualisés dans l’article L311-3 du CASF et rappelés dans la fiche du domaine de prestation 2.3.1, et d’accompagner la personne accompagnée par un établissement ou service médico-social dans sa participation au conseil de la vie sociale ou toute autre forme de participation visant à associer la personne au fonctionnement de la structure (article L311-6 du CASF). Cette prestation d’accompagnement est notamment réalisée par des professionnels sociaux et éducatifs de l’accompagnement, en particulier des éducateurs et assistants de service social.\nEn outre ces prestations s’inscrivent dans une logique qui inclut toutes les nuances d’un accompagnement ( « apprendre à faire », «  faire avec », « faire pour ou à la place de »). Elles ont pour objectif le développement, l’acquisition et le maintien du maximum d’autonomie de la personne. \nBESOINS AUXQUELS LA PRESTATION REPOND : \nCette prestation répond à des besoins pour accéder aux droits :\n\tBesoins pour accéder à la vie politique et à la citoyenneté \n\tBesoins pour la vie spirituelle et religieuse \nCE QUE CE N’EST PAS : \n\tCette prestation ne répond pas aux besoins d’accompagnement pour l’exercice des mandats électoraux, pour la participation aux instances de la démocratie sanitaire HPST, ni aux formations et actions pour apprendre à représenter et aider ses pairs, qui concernent la prestation 2.3.3.6."
    }]
  },
  {
    "code" : "1.3.3.2",
    "display" : "Besoins en lien avec le travail et l’emploi",
    "property" : [{
      "code" : "parent",
      "valueCode" : "1.3.3"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 4"
    },
    {
      "code" : "note",
      "valueString" : "Cette composante de niveau 4 traite du travail et de l’emploi.\nDESCRIPTION : \nBesoins pour la formation professionnelle (initiale et continue)\nBesoins pour obtenir, garder et quitter une activité professionnelle ou à caractère professionnel\nBesoins transversaux en lien avec le travail et l'emploi\nCes besoins transversaux ont été davantage précisés, à la demande des membres du groupe technique national par le recours au volet 6 du GEVA (celui traitant des activités et participation sociale). Ce sont donc les activités du volet 6 du GEVA qui viennent détailler les activités liées au travail et à l’emploi. Il s’agit des besoins pour être ponctuel, organiser son travail, accepter des consignes, suivre des consignes, être en contact avec le public, assurer l’encadrement, travailler en équipe, exercer des tâches physiques et autres besoins en lien avec le travail et l’emploi. \nCODES CIF CORRESPONDANTS (OMS, 2001) :\nLa composante de niveau 4 porte sur les activités/participation sociale du chapitre 8 (Grands domaines de la vie) de la CIF : \n◦\td840-859 – Travail et emploi\no\tApprentissage : suivre des programmes de préparation à l'emploi, comme apprendre à faire le travail d'un apprenti, d'un stagiaire, aller en apprentissage ou suivre une formation sur le tas.\no\tObtenir, garder ou quitter un emploi : chercher, trouver et obtenir un emploi, louer ses services et accepter un emploi, conserver son emploi et progresser dans un poste, un métier, un travail ou une profession et quitter son emploi de manière appropriée.\nCE QUE CE N’EST PAS :\nPour certaines personnes, les apprentissages transversaux (apprendre à lire, à écrire, à calculer, à résoudre des problèmes) peuvent être un préalable et une condition à l’accès au travail et à l’emploi. Ces apprentissages et application de connaissances ne font pas partie de la composante « 1.3.3.2 - Besoins en lien avec le travail et l’emploi »,  ils sont couverts par la composante de niveau 4 « 1.3.3.3 – Besoins transversaux en matière d’apprentissages ».\nDans la même logique que pour le reste de la nomenclature, les besoins correspondent à un écart (principe d’évaluation de la situation), il ne s’agit donc pas des réponses à mettre en œuvre pour les compenser (principe d’accompagnement)."
    }]
  },
  {
    "code" : "1.3",
    "display" : "Besoins pour la participation sociale",
    "property" : [{
      "code" : "parent",
      "valueCode" : "1"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 2"
    },
    {
      "code" : "note",
      "valueString" : "Cette composante de niveau 2 (1.3) couvre le grand domaine de la participation sociale pour la nomenclature des besoins.\nLa participation au sens de la CIF et de la loi du 11 février 2005 désigne l’implication d’une personne dans la vie réelle : son appartenance à une société, l’exercice de ses droits, de ses rôles sociaux, le fait d’y exercer sa citoyenneté. \nPour décrire les besoins en matière de participation sociale, la nomenclature s’appuie sur le chapitre activités et participation sociale de la CIF, ce qui est au cœur du fonctionnement humain au sens de la CIF.\nPour rappel, les besoins en matière d’activités essentielles sont couverts par le grand domaine autonomie et les composantes afférentes.\nLa composante de niveau 2 (1.3) Besoins pour la participation sociale se décline en 5 composantes de niveau 3 :\n-\t1.3.1 – Besoins pour accéder aux droits et à la citoyenneté ;\n-\t1.3.2 – Besoins pour vivre dans un logement et accomplir les activités domestiques ;\n-\t1.3.3 – Besoins pour l'insertion sociale et professionnelle et pour exercer ses rôles sociaux ;\n-\t1.3.4 – Besoins pour participer à la vie sociale et se déplacer avec un moyen de transport ;\n-\t1.3.5 – Besoins en matière de ressources et d'autosuffisance économique.\nCes activités, qui permettent de mettre en lumière ces besoins, sont présentes, pour la plupart, dans le volet 6 du GEVA."
    },
    {
      "code" : "child",
      "valueCode" : "1.3.4"
    },
    {
      "code" : "child",
      "valueCode" : "1.3.2"
    },
    {
      "code" : "child",
      "valueCode" : "1.3.3"
    },
    {
      "code" : "child",
      "valueCode" : "1.3.1"
    },
    {
      "code" : "child",
      "valueCode" : "1.3.5"
    }]
  },
  {
    "code" : "1.1.7",
    "display" : "Besoins en matière de fonctions génito-urinaire et reproductive",
    "property" : [{
      "code" : "parent",
      "valueCode" : "1.1"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 4"
    },
    {
      "code" : "note",
      "valueString" : "Cette composante de niveau 3 traite des fonctions génito-urinaires et reproductives.\nDESCRIPTION \nBesoins en lien avec les fonctions urinaires et reproductives, y compris les fonctions sexuelles et reproductives\nBesoins quant aux structures liées à l'appareil génito-urinaire\nCODES CIF CORRESPONDANTS (OMS, 2001)\nCette composante de niveau 4 porte sur l’ensemble des deux chapitres :\n◦ b6 – Fonctions génito-urinaires et reproductives\n◦ s6 – Structures liées à l’appareil génito-urinaire\nCE QUE CE N’EST PAS\nIl ne s’agit pas des besoins d’accès aux soins courants couverts par la composante « 1.1.1.10 – Besoins pour entretenir et prendre soin de sa santé ».\nIl ne s’agit pas non plus des besoins pour la vie affective et sexuelle. En effet cette partie de la nomenclature, et cette composante de niveau 4 en particulier traite de la fonction et non des activités permises par l’intégrité (ou non) des fonctions.\nLes besoins en lien avec les comportements inappropriés type désinhibition notamment ne sont pas inclus dans cette composante. Ils relèvent de la composante « 1.1.1.1 – Besoins en matière de fonctions mentales, psychiques, cognitives et du système nerveux », voir b130 dans la CIF.\nDans la même logique que pour le reste de la nomenclature, les besoins correspondent à un écart (principe d’évaluation de la situation), il ne s’agit donc pas des réponses à mettre en œuvre pour les compenser (principe d’accompagnement)."
    }]
  },
  {
    "code" : "1.3.1",
    "display" : "Besoins pour accéder aux droits et à la citoyenneté",
    "property" : [{
      "code" : "parent",
      "valueCode" : "1.3"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 3"
    },
    {
      "code" : "note",
      "valueString" : "Cette composante traite de l’accès aux droits dans ses différentes dimensions, citoyenneté, pratique religieuse, engagement dans la vie civique, bénévolat. Cette composante ne traite pas de la récréation et des loisirs.\nDESCRIPTION : \nBesoins pour accéder aux droits \nBesoins pour accéder à la vie politique et à la citoyenneté\nBesoins pour la pratique religieuse\nBesoins pour faire du bénévolat\nCODES CIF CORRESPONDANTS (OMS, 2001) :\nLa composante de niveau 4 porte sur les activités/participation sociale d’une partie du chapitre 9 (Vie communautaire, sociale et civique) : \n◦\td910 Vie communautaire : s'investir dans tous les aspects de la vie sociale communautaire, comme participer à des œuvres de bienfaisance, des clubs de services ou des organismes socio-professionnels. Inclusions : associations formelles et informelles\n◦\td930 Vie spirituelle : pratiquer une religion ou avoir des activités spirituelles, s'engager dans des organisations et des pratiques religieuses et spirituelles, afin de se réaliser, de trouver un sens à la vie, de découvrir des valeurs religieuses et spirituelles et d'établir le contact avec une puissance divine, comme aller à l'église, au temple, à la mosquée ou à la synagogue, prier et chanter à des fins religieuses, ou pratiquer la contemplation.\n◦\td940 Droits humains : jouir de tous les droits reconnus aux niveaux tant national qu'international à la personne humaine en vertu de sa seule existence en tant qu'être humain, tels que les droits humains reconnus par la Déclaration universelle des droits de l'homme des Nations Unies (1948) et les Règles pour l'égalisation des chances des handicapés des Nations Unies (1993); le droit à l'autodétermination ou à l'autonomie; le droit de décider de son propre destin.\n◦\td950 Vie politique et citoyenneté : participer à la vie sociale, politique et à la vie de la cité en tant que citoyen, avoir le statut légal de citoyen et jouir des droits, de la protection, des privilèges et avoir les devoirs associés à cette qualité, comme avoir le droit de voter, de se porter candidat à une élection, de former un mouvement politique; jouir des droits et des libertés qui découlent de la citoyenneté (par exemple,  liberté d'expression, d'association, de religion, protection contre la détention arbitraire, droit d'avoir un avocat, d'être jugé et de jouir des droits et d'une protection contre la discrimination); avoir un statut légal en tant que citoyen.\nCE QUE CE N’EST PAS :\n\tDans la même logique que pour le reste de la nomenclature, les besoins correspondent à un écart (principe d’évaluation de la situation), il ne s’agit donc pas des réponses à mettre en œuvre pour les compenser (principe d’accompagnement).Les besoins en lien avec la récréation et les loisirs sont couverts par la composante de niveau 4 « 1.3.4.1 – besoins pour participer à la vie sociale »."
    }]
  },
  {
    "code" : "2.3.3.4",
    "display" : "Accompagnements pour réaliser des activités de jour spécialisées",
    "property" : [{
      "code" : "parent",
      "valueCode" : "2.3.3"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 4"
    },
    {
      "code" : "note",
      "valueString" : "Cette prestation regroupe tous les accompagnements effectués par un service ou un établissement médico-social, dans la structure, auprès d’une personne pour qu’elle réalise des activités de jour adaptées à ses différents besoins parmi ceux rappelés ci-après et non rattachables aux autres prestations appartenant au domaine 2.3.3 accompagnements pour exercer ses rôles sociaux. \nCes activités sont qualifiées et spécialisées car elles se déroulent dans la structure médico-sociale (établissement ou service). \nIl peut s’agir par conséquent : \n\tdes activités de jour réalisées dans le cadre d’un accueil de la petite enfance spécialisé ou d’un accueil périscolaire spécialisé, \n\tdes activités réalisées par une structure médico-sociale, en ses murs, en complément ou en lieu et place des accompagnements effectués pour mener sa vie d’élève d’étudiant ou d’apprenti, pour préparer sa vie professionnelle, ou pour mener sa vie professionnelle..\nCes prestations sont réalisées, à titre principal, par des enseignants et des professionnels sociaux et éducatifs de l’accompagnement et en particulier des éducateurs et moniteurs : éducateurs spécialisés, éducateurs techniques, moniteurs d’atelier. \nEn outre ces prestations s’inscrivent dans une logique de compensation qui inclut toutes les nuances d’un accompagnement : « apprendre à faire », « faire avec », « faire pour (ou à la place de) ».. Elles ont pour objectif le développement, l’acquisition et le maintien du maximum d’autonomie de la personne dans la conduite de ses activités au sein de la structure. \nBESOINS AUXQUELS LA PRESTATION REPOND : \nCette prestation répond aux besoins pour participer à la vie sociale dont :\n \tBesoins en lien avec la récréation et les loisirs, \n \tBesoins pour l'accueil périscolaire,\n \tBesoins pour l'accueil de la petite enfance,\n \tBesoins pour les relations amicales.\nCE QUE CE N’EST PAS : \n\tQuand les activités visent à répondre à un besoin d’apprentissage élémentaire, elles s’inscrivent dans la composante « 2.3.3.1 - mener sa vie d’élèves, d’étudiant ou d’apprenti » pour les personnes qui ne sont pas en situation de préparation à la vie professionnelle ou en situation d’exercice professionnel d’emploi.\n\tL’accompagnement par des professionnels sociaux et éducatifs de personnes lors de leurs activités de loisirs menés en dehors de la structure constitue une prestation d’accompagnement pour la participation aux activités sociales.\n\tL’accompagnement dans la structure d’intervenants extérieurs et n’exerçant pas dans le secteur médico-social dépend de l’objectif poursuivi. Sous cette condition, il peut notamment s’agir d’une prestation 2.3.4.2 « accompagnement pour la participation aux activités sociales et de loisir »."
    }]
  },
  {
    "code" : "2.3.4.1",
    "display" : "Accompagnements du lien avec les proches et le voisinage",
    "property" : [{
      "code" : "parent",
      "valueCode" : "2.3.4"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 4"
    },
    {
      "code" : "note",
      "valueString" : "Cette prestation recouvre les accompagnements réalisés pour permettre à la personne de créer, maintenir,, intensifier ou mettre fin au lien avec ses proches (hors vie familiale, affective et sexuelle) et le voisinage.\nCes accompagnements sont notamment réalisés par des professionnels sociaux et éducatifs, en particulier : \n \tdes aides médico psychologiques, \n \tdes éducateurs (éducateurs spécialisés, éducateurs de jeunes enfants), \n \tdes assistants de service social et conseillers en économie sociale et familiale,\n \tdes maîtres et maîtresses de maison, \n \tdes animateurs.\nEn outre ces prestations s’inscrivent dans une logique qui inclut toutes les nuances d’un accompagnement : « apprendre à faire », « faire avec », « faire pour (ou à la place de) ». \nExemple : \n \tEn établissement médico-social, il peut s’agir de l’accompagnement dans la mise en relation, la médiation des premiers échanges et le soutien aux relations amicales dans l’établissement. \nBESOINS AUXQUELS LA PRESTATION REPOND :\n\tBesoins pour participer à la vie sociale (1.3.4.1), et en particulier : \n \tBesoins en lien avec la récréation et les loisirs, \n \tBesoins pour les relations amicales\n\tBesoins en lien avec les relations et interactions avec autrui (1.2.1.2) et en particulier : \n \tBesoins pour les interactions avec autrui\n \tBesoins pour les relations particulières avec autrui\nCE QUE CE N’EST PAS : \n\tLe travail sur l’expression du projet de l’usager, y compris son projet de vie sociale avec les proches et le voisinage sera identifié en 2.3.1.1 - Accompagnements à l’expression du projet personnalisé."
    }]
  },
  {
    "code" : "3.2.1.4",
    "display" : "Locaux et autres ressources pour gérer, manager, coopérer",
    "property" : [{
      "code" : "parent",
      "valueCode" : "3.2.1"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 4"
    },
    {
      "code" : "note",
      "valueString" : "Cette prestation consiste pour une structure médico-sociale à disposer de locaux et de matériels permettant la réalisation des prestations indirectes liées à gérer-manager-coopérer. Toutes les structures médico-sociales disposent au minimum de ces locaux et de matériels et charges  afférents à cette gestion."
    }]
  },
  {
    "code" : "2.2.1",
    "display" : "Accompagnements pour les actes de la vie quotidienne",
    "property" : [{
      "code" : "parent",
      "valueCode" : "2.2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 4"
    },
    {
      "code" : "note",
      "valueString" : "L’accompagnement pour les actes de la vie quotidienne comprend l’ensemble des actions suivantes : \n-\tsoins de nursing, liés à l’entretien personnel ;\n-\taccompagnements pour prendre soin de sa santé notamment l’observance thérapeutique; \n-\talimentation de la personne (porter les aliments à sa bouche, etc. ) ;\n-\tmise en œuvre de ses transferts.\nPar ailleurs, comme l’ensemble des prestations en matière d’autonomie, elles s’inscrivent dans une logique de compensation qui recouvre toutes les nuances de l’accompagnement qui a pour objectif l’acquisition et le maintien du maximum d’autonomie de la personne : de « apprendre à la personne à faire », à « faire avec », jusqu’à « faire pour (ou à la place de) ».\nLa prestation peut par exemple recouvrir, pour ce qui concerne l’entretien de la santé de la personne, des accompagnements allant de la prise de rendez-vous médicaux, à l’élaboration d’un planning de suivi dont elle gère la mise en œuvre au simple rappel d’une échéance médicale à anticiper, ou d’un médicament à prendre. \nLES BESOINS AUXQUELS ELLES REPONDENT :\nElles répondent aux besoins en matière d’autonomie des personnes parmi lesquels :\n\tBesoins en lien avec l’entretien personnel : pour la toilette, pour prendre soin des parties de son corps, pour l'élimination, pour s'habiller, se déshabiller, pour s’alimenter \n\tBesoins pour la mobilité : pour changer et maintenir la position de son corps, pour porter, déplacer et manipuler des objets, pour marcher, pour se déplacer. \nCE QUE CE N’EST PAS : \n\tUne prestation de préparation du repas (préparer la liste, réaliser les achats, cuisiner les aliments, etc.) constitue une prestation identifiée en 2.3.2.2 Accompagnements pour accomplir les activités domestiques"
    }]
  },
  {
    "code" : "3.2.2.1",
    "display" : "Fournir des repas",
    "property" : [{
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "versionInfo",
      "valueString" : "Raison de l'inactivation : concept dupliqué"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2023-01-01T00:00:00+01:00"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "2.1.1.3",
    "display" : "Prestations des psychologues",
    "property" : [{
      "code" : "parent",
      "valueCode" : "2.1.1"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 4"
    },
    {
      "code" : "note",
      "valueString" : "Ces prestations sont réalisées par des psychologues.\nElles peuvent être à visée préventive, curative et palliative. \nLes prestations de psychologues sont des prestations de soutien et d’accompagnement, pour répondre à des besoins en lien avec les fonctions du cerveau (fonctions mentales dont cognitives et psychiques). \nBESOINS AUXQUELS LA PRESTATION REPOND : \nLes prestations de psychologue répondent aux besoins en matière de fonction mentales, psychiques, cognitives et du système nerveux\nCE QUE CE N’EST PAS : \n\tLes prestations de supervision sont identifiées en 3.1.4.3 - Prestation de supervision\n\tIl ne peut s’agir de prestations d’analyse des pratiques, de soutien aux personnels et de mise en place d’espaces ressources qui sont identifiées parmi les prestations indirectes en 3.1.4.2 - Analyse des pratiques, espaces ressource et soutien aux personnels"
    }]
  },
  {
    "code" : "3.2.4.3",
    "display" : "Transports liés à l’autonomie et la participation sociale",
    "property" : [{
      "code" : "parent",
      "valueCode" : "3.2.4"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 4"
    },
    {
      "code" : "note",
      "valueString" : "Les structures médico-sociales peuvent être amenées à mettre en place des prestations de transports des personnes. Ces prestations sont organisées de manière individuelle ou collective, assurées par la structure ou par le recours à des prestataires financés par la structure. \nLes transports liés au projet individuels ne constituent pas directement une réponse aux besoins d’une personne tels que synthétisés par la nomenclature des besoins : il n’existe pas de « besoin d’être transporté». Ces transports constituent par contre une condition sine qua non de la réalisation des prestations directes. \nLes transports liés à l’’autonomie et la participation sociale peuvent constituer une prestation sine qua non de la réalisation de prestation directe relevant soit du domaine de l’autonomie soit du domaine de la participation sociale. \nPar exemple un élève, en internat séquentiel dans une structure, scolarisé à temps plein en milieu scolaire ordinaire avec l’appui de l’équipe médico-sociale ne peut de facto bénéficier de cet accompagnement à la vie d’élève que s’il peut se rendre dans l’école lorsqu’il est hébergé dans la structure. L’accompagnement à la vie d’élève étant une prestation directe relevant du domaine de la participation sociale, lorsque l’ESMS met en place une prestation de transport pour cet élève afin qu’il se rende à l’école, il s’agit d’une prestation de transport liée à la participation sociale.\nCE QUE CE N’EST PAS :\n\tDans la nomenclature des prestations, toutes les prestations directes sont délivrées par principe sur tous les lieux de vie. Le fait qu’un professionnel se déplace pour effectuer une prestation hors les murs de la structure ne constitue pas une prestation mais le mode de réalisation de la prestation. Par conséquent, lorsque le professionnel se déplace pour effectuer une prestation de soins ou d’accompagnement, il ne s’agit pas d’une prestation de transport lié au projet individuel mais d’une prestation directe précise."
    }]
  },
  {
    "code" : "1.2.1.4",
    "display" : "Besoins pour prendre des décisions adaptées et pour la sécurité",
    "property" : [{
      "code" : "parent",
      "valueCode" : "1.2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 3"
    },
    {
      "code" : "note",
      "valueString" : "Cette composante de niveau 3 traite de la prise de décisions adaptées et de la sécurité selon  deux dimensions : \n \tUn besoin de sécurité, dans les situations les plus extrêmes ; il s’agit de ne pas se mettre en danger ou mettre en danger les autres,\n \tDans un certain nombre de situations non extrêmes, un besoin de soutien pour pouvoir faire le bon choix dans une situation donnée.\nDESCRIPTION : \nBesoins pour s'orienter dans le temps et dans l'espace\nBesoins pour prendre des décisions et initiatives\nBesoins pour gérer le stress et les autres exigences psychologiques (dont ne pas se mettre en danger et ne pas mettre les autres en danger) \nCODES CIF CORRESPONDANTS (OMS, 2001) :\nLe groupe technique national SERAFIN-PH  a estimé, compte tenu des échanges rappelés ci-après, que les composantes de la CIF, qui permettent de faire état d’un besoin en termes de prise de décision adaptée les plus à même de refléter le besoin tel qu’il l’entendait, sont les suivantes :\nLa composante de niveau 4 porte sur des activités du chapitre 1 « apprentissages et applications des connaissances », du chapitre 2« taches et exigences générales » des activités et de la participation sociale de la CIF et des fonctions d’orientation du chapitre 1 « des fonctions organiques de la CIF » : \n◦\td177 – Prendre des décisions \nFaire un choix entre diverses options, mettre en œuvre l'option choisie et évaluer les conséquences de ce choix, comme choisir et acheter un article particulier, décider d'entreprendre une tâche parmi toutes celles qu'il était possible d'entreprendre.\n◦\td240 – Gérer le stress et autres exigences psychologiques\nEffectuer les actions simples ou complexes et coordonnées qu'une personne doit accomplir pour gérer et maîtriser les exigences psychologiques nécessaires à la réalisation de tâches impliquant un niveau important de responsabilité et entraînant stress, distraction et crises, comme conduire un véhicule dans un trafic dense ou prendre soin de plusieurs enfants. Inclusions: assumer ses responsabilités; faire face au stress et aux crises\n◦\tb114 - Fonctions d'orientation\nCe chapitre traite des fonctions mentales générales de connaissance et d'établissement de sa relation avec soi-même, les autres, le temps et son environnement. Inclusions : fonctions d'orientation par rapport au temps, au lieu et à la personne; orientation par rapport à soi et aux autres.\nCE QUE CE N’EST PAS :\nDans la même logique que pour le reste de la nomenclature, les besoins correspondent à un écart (principe d’évaluation de la situation), il ne s’agit donc pas des réponses à mettre en œuvre pour les compenser (principe d’accompagnement).\nIl ne s’agit pas du besoin d’une personne d’être protégée contre d’autres. \nIl ne s’agit pas des besoins pour mener et entretenir des relations et interactions avec autrui dans le respect des convenances, comme faire preuve de respect ou maîtriser ses émotions et ses pulsions, maîtriser son agressivité verbale et physique (cf. « 1.2.1.2 – Besoins en lien avec les relations et les interactions avec autrui »)\nECHANGES AU GTN SERAFIN-PH EN 2015\nLors des travaux du groupe technique national (GTN) cette sous-composante a fait l’objet de nombreux échanges. \nEn effet, plusieurs types de besoins demandaient à être identifiés :\n \tles besoins en lien avec la sécurité des personnes elles-mêmes : il s’agissait d’identifier les situations parfois complexes où il y a nécessité de protéger la personne, y compris dans les situations les plus extrêmes, où des renforts de personnel sont parfois nécessaires.\n \tLes besoins en lien avec la sécurité des personnes mais aussi la sécurité des tiers : plusieurs membres du groupe technique national ont souhaité identifier des situations nécessitant de protéger les personnes accueillies, en situation de très grande vulnérabilité, contre la violence d’autres personnes accueillies.\nEn tout état de cause, le groupe technique a voulu mettre en avant les situations pour lesquelles les établissements sont régulièrement en difficulté.\nFace à ces demandes, qui méritaient d’être entendues, plusieurs remarques ont été formulées :\nSi des situations extrêmes existent et reflètent des besoins importants en matière de sécurité, il était important d’être vigilant à deux écueils :\no\tLe fait d’identifier d’emblée les situations extrêmes où un besoin de sécurité existe ne doit pas faire oublier les situations intermédiaires dans lesquelles la mise en danger ne met pas en péril la survie de la personne mais impacte son bien-être, par exemple par des manifestations anxieuses.\no\tLe fait d’identifier au titre d’un besoin une situation où la sécurité de la personne est en cause ne doit pas faire oublier, particulièrement dans les situations de « comportements-problèmes », les étapes qui doivent permettre d’anticiper, d’analyser et d’éviter ces comportements.\nLa composante « besoins pour prendre des décisions adaptées et pour la sécurité » ne doit pas être utilisée pour décrire une situation où la personne est perçue comme « vulnérable » ou comme devant être protégée d’autres résidents. \nEnfin, il est vraisemblable que les participants, par pragmatisme, et envisageant d’emblée les usages possibles des nomenclatures, anticipaient sur les réponses aux besoins de sécurité et, peut-être, leur financement. Il était donc nécessaire de rappeler que les besoins permettent de mettre en évidence un écart à la norme de réalisation, mais non de définir les réponses qui vont permettre de le diminuer ou le combler."
    }]
  },
  {
    "code" : "3.1.5",
    "display" : "Relations avec le territoire",
    "property" : [{
      "code" : "parent",
      "valueCode" : "3.1"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 3"
    },
    {
      "code" : "note",
      "valueString" : "La composante « relations avec le territoire » rend compte des démarches entreprises vers les acteurs du territoire, qu’ils soient spécialisés ou de droit commun, pour développer des partenariats, des coopérations et  pour conventionner avec eux.\nElle s’inscrit notamment dans le cadre de l’article L311-1 du code de l’action sociale et des familles qui mentionne que « les établissements et services médico-sociaux établissent […] des coopérations avec d’autres établissements et services pour organiser une réponse coordonnée et de proximité aux besoins de la population dans les différents territoires, dans un objectif de continuité et de décloisonnement des interventions sociales et médico-sociales réalisées au bénéfice des personnes accueillies ou accompagnées ».\nIl s’agit également de reconnaitre qu’au-delà des partenariats avec les autres acteurs sociaux et médico-sociaux, les relations nouées par les structures médico-sociales avec l’ensemble des acteurs qui interagissent dans l’environnement de la personne permettent d’assurer des parcours d’accompagnement plus fluides. \nTous les professionnels peuvent être amenés à réaliser ces prestations. \nLa composante relations avec le territoire se découpe en deux composantes de niveau 4 : \n-\t3.1.5.1 : Coopération, conventions avec les acteurs spécialisés et du droit commun\n-\t3.1.5.2 : Appui-ressource et partenariats institutionnels\nLa distinction entre les deux composantes des relations avec le territoire s’appuie sur l’objectif dans lequel se réalise la prestation.\nLa composante « 3.1.5.1 - Coopération, conventions avec les acteurs spécialisés et du droit commun » concerne des démarches de l’ESMS vers les acteurs spécialisés et de droit commun de son environnement pour rendre plus efficientes ses propres prestations : celles qu’il délivre à ses bénéficiaires. Il y a alors une plus-value directe pour l’ESMS et ses usagers (ex : la signature d’une convention constitutive d’unité d’enseignement externalisée, permet la scolarisation dans cette unité d’enseignement dans les murs d’une école ordinaire d’élèves de la structure). \nLa notion d’appui-ressource sur le territoire ne vise pas à améliorer les propres prestations de l’ESMS ; il agit en tant que ressource pour les autres structures spécialisées ou de droit commun. Ex : la participation d’une structure médico-sociale à la formation des enseignants."
    },
    {
      "code" : "child",
      "valueCode" : "3.1.5.2"
    },
    {
      "code" : "child",
      "valueCode" : "3.1.5.1"
    }]
  },
  {
    "code" : "3.2.2",
    "display" : "Fournir des repas",
    "property" : [{
      "code" : "parent",
      "valueCode" : "3.2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 3"
    },
    {
      "code" : "note",
      "valueString" : "Parmi les prestations indirectes qu’elle met en œuvre, la structure médico-sociale peut être amenée à réaliser des repas pour les personnes accompagnées. \nElle comprend également les activités liées au service des plats à table ou au self-service, la gestion de la vaisselle (disposition, nettoyage des effets des repas, vaisselle…). \nLa prestation peut être effectuée : \n-\tPar la structure directement ou par le recours à un prestataire, \n-\tDans ses murs ou sous la forme d’une prise en charge des repas des personnes accompagnées hors les murs (livraison dans un local extérieur, couverture des frais de restauration scolaire dans certaines unités enseignement externalisées)\nCette prestation ne constitue pas une réponse à un besoin tel qu’identifié dans le cadre de la nomenclature des besoins, elle est cependant une condition sine qua non de la réalisation de certaines prestations directes et souvent lié à un mode de fonctionnement de la structure. \nCE QUE CE N’EST PAS :\n-\tLe fait d’accompagner une personne pour la réalisation de ses repas (effectuer les achats, préparer les aliments) constitue une réponse à des besoins en matière d’accompagnement au logement, il s’agit d’une prestation d’Accompagnements pour accomplir les activités domestiques. \n-\tLe fait d’aider la personne à s’alimenter (porter les aliments à sa bouche, les couper) constitue une réponse à un besoin en matière d’autonomie et correspond à la prestation 2.2.1.1 Accompagnements pour les actes de la vie quotidienne."
    }]
  },
  {
    "code" : "1.3.2.2",
    "display" : "Besoins pour accomplir les activités domestiques",
    "property" : [{
      "code" : "parent",
      "valueCode" : "1.3.2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 4"
    },
    {
      "code" : "note",
      "valueString" : "Cette composante de niveau 4 traite des activités domestiques, c’est-à-dire faire les courses nécessaires à la vie quotidienne et réaliser les tâches ménagères.\nLe logement ou l’hébergement peut être individuel ou collectif, cette composante couvre tout type/forme de logement ou d’hébergement.\nDESCRIPTION : \nBesoins pour acquérir des produits et services\nBesoins pour les tâches ménagères\nCODES CIF CORRESPONDANTS (OMS, 2001) :\nLa composante de niveau 4 porte sur les activités du chapitre 6 de la CIF : \n◦\td620 Acquérir des produits et services\nChoisir, se procurer, transporter tous produits et services nécessaires à la vie quotidienne : choisir, se procurer, transporter et ranger de la nourriture, des boissons, des vêtements, des produits de nettoyage, du combustible, des articles ménagers, des ustensiles, des batteries de cuisine, des assiettes, des appareils électroménagers et des outils ; se procurer des services publics et d'autres services ménagers\n◦\td630 – 649 Tâches ménagères\no\tPréparer le repas : planifier, organiser, préparer et servir des repas simples ou compliqués et les boissons pour soi et les autres, en établissant un menu, en choisissant des aliments et des boissons, en réunissant les ingrédients pour préparer les repas, en cuisant et en préparant les aliments et les boissons froides, en servant les repas.\no\tFaire le ménage : gérer le ménage, en nettoyant la maison, en lavant les vêtements, en utilisant les produits d'entretien, en entreposant la nourriture, en éliminant les ordures, en balayant, en passant le torchon, en lavant les armoires, les murs et autres surfaces, en rassemblant et en éliminant les ordures ménagères; en rangeant les pièces, les armoires et les tiroirs, en rassemblant, lavant, séchant, pliant et repassant le linge, en frottant les chaussures, en utilisant des balais, des brosses et des aspirateurs, en utilisant des lave-linge, des sèche-linge et des fers à repasser.\nCE QUE CE N’EST PAS :\nCette composante ne couvre pas les besoins pour avoir un lieu d’hébergement ou vivre dans un logement qui relève de la composante 1.3.2.1 « Besoins pour vivre dans un logement ».\nElle ne couvre pas non plus les besoins pour s’alimenter qui relèvent de la composante 1.2.1.1 « Besoins en lien avec l’entretien personnel ».  \nDans la même logique que pour le reste de la nomenclature, les besoins correspondent à un écart (principe d’évaluation de la situation), il ne s’agit donc pas des réponses à mettre en œuvre pour les compenser (principe d’accompagnement)."
    }]
  },
  {
    "code" : "1.1.4",
    "display" : "Besoins relatifs à la voix, à la parole et à l’appareil bucco-dentaire",
    "property" : [{
      "code" : "parent",
      "valueCode" : "1.1"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 4"
    },
    {
      "code" : "note",
      "valueString" : "Cette composante de niveau 3 traite des fonctions de la voix, de production de sons et la parole, ainsi que des structures qui y sont associées. Cette composante traite des structures de la bouche, et notamment des dents.\nDESCRIPTION \nBesoins en lien avec les fonctions liées à la production des sons et de la parole\nBesoins quant aux structures liées à la voix et à la parole\nBesoins en lien avec les dents\nCODES CIF CORRESPONDANTS (OMS, 2001)\nCette composante de niveau 4 porte sur l’ensemble des deux chapitres :\n◦\tb3 – Fonctions de la voix et de la parole\n◦\ts3 – structures liées à la voix et à la parole\n \tStructure de la bouche\no\tDents\no\tGencives\no\tStructure du palais\no\tLangue\no\tLèvres\n \tStructure du pharynx\n \tStructure du larynx \nCE QUE CE N’EST PAS \nIl ne s’agit pas des besoins d’accès aux soins courants couverts par la composante « 1.1.1.10 – Besoins pour entretenir et prendre soin de sa santé ». Il ne s’agit pas non plus des réponses à ces besoins.\nDans la même logique que pour le reste de la nomenclature, les besoins correspondent à un écart (principe d’évaluation de la situation), il ne s’agit donc pas des réponses à mettre en œuvre pour les compenser (principe d’accompagnement)."
    }]
  },
  {
    "code" : "2.3",
    "display" : "Prestations pour la participation sociale",
    "property" : [{
      "code" : "parent",
      "valueCode" : "2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 2"
    },
    {
      "code" : "note",
      "valueString" : "Au sens de la classification internationale du fonctionnement, du handicap et de la santé (CIF) et de la loi du 11 février 2005 pour l’égalité des droits et des chances, la participation et la citoyenneté des personnes en situation de handicap désigne son implication dans une situation de vie réelle, et correspond aux interactions en société, à l’exercice de ses droits, de ses rôles sociaux, et en définitive de sa citoyenneté.\nEn outre, ces prestations s’inscrivent, comme les prestations en matière d’autonomie, dans une logique de compensation qui recouvre toutes les nuances de l’accompagnement qui a pour objectif l’acquisition et le maintien du maximum d’autonomie de la personne : de « apprendre à la personne à faire », à « faire avec », jusqu’à « faire pour (ou à la place de) ».\nElles sont réalisées notamment les professionnels suivants : \n-\tdes enseignants \n-\tdes professionnels sociaux et éducatifs de l’accompagnement, cette terminologie regroupant un vaste ensemble de professionnels notamment : \no\tdes aides médico-psychologiques\no\tdes éducateurs et moniteurs : éducateurs spécialisés, éducateurs de jeunes enfants, éducateurs techniques, moniteurs d’atelier, éducateurs scolaires…\no\tdes assistants de service social et conseillers en économie sociale et familiale\no\tdes maîtres et maîtresses de maison\no\tdes interprètes, codeurs, interfaces de communication et interprètes\nCes prestations sont organisées en 5 composantes de niveau 3 : \n \taccompagnements pour exercer ses droits \n \taccompagnements au logement \n \taccompagnements pour exercer ses rôles sociaux \n \taccompagnements pour participer à la vie sociale \n \taccompagnements en matière de ressources et d’autogestion\nBESOINS AUXQUELS LA PRESTATION REPOND : \nCes prestations répondent aux : \n\tbesoins pour accéder aux droits et à la citoyenneté\n\tbesoins pour vivre dans un logement\n\tbesoin pour l’insertion sociale et professionnelle et pour exercer ses rôles sociaux\n\tbesoins pour participer à la vie sociale et se déplacer avec un moyen de transport\n\tbesoins en matière de ressources et d’autosuffisance économique"
    },
    {
      "code" : "child",
      "valueCode" : "2.3.3"
    },
    {
      "code" : "child",
      "valueCode" : "2.3.2"
    },
    {
      "code" : "child",
      "valueCode" : "2.3.5"
    },
    {
      "code" : "child",
      "valueCode" : "2.3.4"
    },
    {
      "code" : "child",
      "valueCode" : "2.3.1"
    }]
  },
  {
    "code" : "3",
    "display" : "Prestations indirectes - Pilotage et fonctions supports",
    "property" : [{
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "BLOC"
    },
    {
      "code" : "child",
      "valueCode" : "3.2"
    },
    {
      "code" : "child",
      "valueCode" : "3.1"
    }]
  },
  {
    "code" : "3.1.4.3",
    "display" : "Prestations de supervision",
    "property" : [{
      "code" : "parent",
      "valueCode" : "3.1.4"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 4"
    },
    {
      "code" : "note",
      "valueString" : "Cette prestation correspond à la prestation de supervision réalisée par un professionnel extérieur à la structure médico-sociale et formé aux spécificités de l’accompagnement des personnes. \nLa supervision des pratiques est mise en place par la structure médico-sociale pour ses professionnels et vise à les accompagner dans la mise en œuvre des contenus abordés en formation théorique. \nPour rappel la supervision des pratiques implique notamment le fait de :\n \tFormer les professionnels aux outils d’évaluation et accompagner leur mise en œuvre\n \tAppuyer l’équipe dans la rédaction et l’actualisation du programme personnalisé qui est la déclinaison pratique des objectifs prévus par le projet personnalisé d’accompagnement ou projet individualisé d’accompagnement de la personne \n \t Proposer des protocoles d’actions écrits de gestion des comportements problèmes à l’équipe et analyser la situation en contexte ; \n \t Définir et mettre en place le recueil des données utiles à l’équipe (items, fréquence) et les analyser ;\n \tParticiper à des temps de concertation réguliers avec l’équipe pour échanger sur des points techniques ou de difficultés \n \tAider à la planification des actions de formation des professionnels de l’équipe et des parents ; \n \t Montrer les gestes relatifs aux techniques adéquates et réguler les pratiques de l’équipe : observation de chacun des membres dans la mise en œuvre des techniques pour un retour immédiat et tracé permettant au professionnel de progresser ;\n \tObserver de façon régulière chaque personne accompagnée et soumettre au coordonnateur de l’équipe un ensemble de préconisations écrites. \nLa supervision des pratiques recommandée dans le cadre de l’accompagnement de personnes présentant des TSA n’est pas réservée à ce champ et est reprise dans la nomenclature des prestations afin de décrire une prestation susceptible d’être mise en œuvre par toutes les structures dans le cadre d’une démarche de qualité de l’accompagnement. \nLes définitions les plus complètes des contours de cette prestation ont cependant été effectuées dans le cadre de travaux sur l’accompagnement de personnes présentant des troubles du spectre de l’autisme auxquels il est fait référence ci-dessous.  \nEn référence aux recommandations de bonnes pratiques professionnelles de la HAS sur l’accompagnement des personnes présentant un trouble du spectre de l’autisme , la supervision fait partie intégrante de la bonne mise en œuvre des interventions personnalisées, globales et coordonnées auprès des personnes et permet la prévention d’un certain nombre de comportements problèmes. \nL’instruction interministérielle du 10 juin 2016 relative à la modification du cahier des charges national des unités d’enseignement en maternelle prévues par le 3ème plan autisme (2013-2017)  apporte des  précisions sur la supervision des pratiques : ses objectifs et sa fréquence.  \nBESOINS AUXQUELS LA PRESTATION REPOND : \n\tLa prestation de supervision ne répond pas à un besoin identifié d’une personne. \nCE QUE CE N’EST PAS : \n\tElle se distingue dans sa méthode et ses objectifs des prestations d’analyse des pratiques, de soutien aux personnels et de mise en place d’espaces ressources identifiées en 3.1.4.2 –Analyse des pratiques, espaces ressource et soutien au personnel."
    }]
  },
  {
    "code" : "1.2.1",
    "display" : "Besoins en matière d’autonomie",
    "property" : [{
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "versionInfo",
      "valueString" : "Raison de l'inactivation : concept dupliqué"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2023-01-01T00:00:00+01:00"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "1.3.5.1",
    "display" : "Besoins en matière de ressources et d'autosuffisance économique",
    "property" : [{
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "versionInfo",
      "valueString" : "Raison de l'inactivation : concept dupliqué"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2023-01-01T00:00:00+01:00"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "2.3.5.1",
    "display" : "Accompagnements pour l’ouverture des droits",
    "property" : [{
      "code" : "parent",
      "valueCode" : "2.3.5"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 4"
    },
    {
      "code" : "note",
      "valueString" : "Cette prestation rassemble l’ensemble des accompagnements effectués auprès de la personne afin de s’assurer que celle-ci bénéficie de l’ensemble des droits, allocations et aides auxquels sa situation lui permet de prétendre. \nIl s’agit \n\tde la délivrance d’informations sur : \n \tLa santé somatique et psychique (prise en charge totale ou partielle de frais liés à la maladie, à l'invalidité, aux accidents du travail et aux maladies professionnelles).\n \tLa maternité-famille (prestations familiales : prestations liées à la maternité, allocations familiales, aides pour la garde d'enfants).\n \tLa vieillesse (pensions de retraite, pensions de réversion, prise en charge de la dépendance liée au grand âge)\n \tLa perte d'emploi (indemnisation du chômage) et les difficultés d'insertion ou de réinsertion professionnelle.\n \tLes difficultés d’accès au logement (aides au logement).\n \tLa pauvreté et l'exclusion sociale (minima sociaux).\n\tde l’accompagnement pour l’accès aux droits sociaux et l’exercice des possibilités de recours (usagers, parents, représentant légal)\nCes accompagnements sont réalisés notamment par des professionnels sociaux et éducatifs de l’accompagnement parmi lesquels des assistants de service social et conseillers en économie sociale et familiale.\nEn outre cette prestation s’inscrit dans une logique de compensation qui inclut toutes les nuances d’un accompagnement : « apprendre à faire », « faire avec », « faire pour (ou à la place de) ».\nBESOINS AUXQUELS LA PRESTATION REPOND : \n\tBesoins en matière de ressources et d’autosuffisance économique"
    }]
  },
  {
    "code" : "2.3.2.2",
    "display" : "Accompagnements pour accomplir les activités domestiques",
    "property" : [{
      "code" : "parent",
      "valueCode" : "2.3.2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 4"
    },
    {
      "code" : "note",
      "valueString" : "Cette prestation comprend les accompagnements visant à permettre à la personne d’accomplir des activités domestiques ou y participer, que le logement soit autonome, en gestion médico-sociale, en établissement, etc. \nLes activités domestiques correspondent à l’entretien de la maison et à l’alimentation de ses occupants (faire les courses, le ménage, préparer les repas, gérer les poubelles). \nAu sein d’une structure disposant d’un hébergement, ces prestations peuvent être menées par exemple durant des temps dits « familiaux » (matin et soir) par les professionnels qui sont amenés à préparer des repas avec les personnes ou de manière générale à accompagner ces dernières à la réalisation ou à la participation aux tâches liées à la vie domestique (faire son lit, ranger son linge, dresser la table, etc.).  \nCes accompagnements sont réalisés notamment par des professionnels sociaux et éducatifs de l’accompagnement en particulier : \n \tdes aides médico psychologiques, \n \tdes éducateurs (éducateurs spécialisés, éducateurs de jeunes enfants) \n \tdes maîtres et maîtresses de maison. \nEn outre ces prestations s’inscrivent dans une logique qui inclut toutes les nuances de l’accompagnement : « apprendre à faire », « faire avec », « faire pour (ou à la place de) ». \nBESOINS AUXQUELS LA PRESTATION REPOND A TITRE PRINCIPAL : \nBesoins pour accomplir les activités domestiques \nCE QUE CE N’EST PAS : \n\tL’accompagnement pour la gestion administrative et la gestion des ressources constitue une prestation qui sera identifiée en 2.3.5 – Accompagnements en matière de ressources et d’autogestion\n\tL’accompagnement de la personne pour se nourrir (ingérer le repas, porter les aliments à sa bouche, découper la nourriture…) constitue une prestation identifiée en 2.2.2.1 Accompagnements pour les actes de la vie quotidienne."
    }]
  },
  {
    "code" : "3.2.1.5",
    "display" : "Hygiène, entretien, sécurité des locaux, espaces extérieurs",
    "property" : [{
      "code" : "parent",
      "valueCode" : "3.2.1"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 4"
    },
    {
      "code" : "note",
      "valueString" : "Cette prestation consiste pour une structure médico-sociale à garantir pour tous les locaux de l’ESMS l’hygiène, la sécurité des immeubles et équipements (sécurité incendie et maintenance), y compris dans les espaces extérieurs, et donc elle concerne : \n\tl’hygiène des locaux, \n\tl’entretien général (électricité – peinture - petites réparations…),\n\tles maintenances des équipements et contrôles obligatoires des installations,\n\tl’entretien des espaces verts et de tous les espaces extérieurs (y compris les voieries)."
    }]
  },
  {
    "code" : "3.1.2.1",
    "display" : "Gestion budgétaire, financière et comptable",
    "property" : [{
      "code" : "parent",
      "valueCode" : "3.1.2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 4"
    },
    {
      "code" : "note",
      "valueString" : "Cette prestation correspond à :\n\tLa gestion du bâti, y compris des locations,\n\tLa gestion budgétaire (budget prévisionnel, comptes administratifs, dialogue de gestion),\n\tLa gestion financière et comptable (facturation et enregistrement des produits, enregistrement et paiements des charges y compris des salaires, gestion des comptes des résidents),\n\tAu contrôle de gestion et au commissariat aux comptes,\n\tLa fonction achats / économat"
    }]
  },
  {
    "code" : "2.1.1.2",
    "display" : "Soins techniques et de surveillance infirmiers ou délégués",
    "property" : [{
      "code" : "parent",
      "valueCode" : "2.1.1"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 4"
    },
    {
      "code" : "note",
      "valueString" : "Cette prestation concerne l’ensemble des soins techniques et de surveillance décrits par le code de la santé publique  comme étant réalisés, à titre principal, par des professionnels infirmiers et pouvant, dans les conditions fixées par le même code, être délégués à d’autres catégories de professionnels exerçant dans la structure (R4311-4 CSP). \nBESOINS AUXQUELS CES PRESTATIONS REPONDENT :\nElles répondent aux besoins des personnes en matière de santé somatique ou psychique."
    }]
  },
  {
    "code" : "2.3.5",
    "display" : "Accompagnements en matière de ressources et d’autogestion",
    "property" : [{
      "code" : "parent",
      "valueCode" : "2.3"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 3"
    },
    {
      "code" : "note",
      "valueString" : "Les prestations rassemblées dans cette composante visent à soutenir la personne accompagnée dans son accès à l’ensemble des droits sociaux et aides afférentes dont elle peut bénéficier, pour gérer ses ressources et pour que cette gestion soit, si nécessaire, portée par un mandataire judiciaire à la protection des majeurs.\nCette prestation comprend trois composantes de niveau 4 : \n-\t2.3.5.1 - Accompagnements pour l’ouverture des droits\n-\t2.3.5.2 - Accompagnements pour l’autonomie de la personne dans la gestion de ses ressources\n-\t2.3.5.3 - Informations, conseils et mise en œuvre des mesures de protection des adultes\nCes accompagnements sont notamment réalisés par \n \tDes professionnels sociaux et éducatifs de l’accompagnement, en particulier des éducateurs et moniteurs : des éducateurs spécialisés, des assistants de service social et conseillers en économie sociale et familiale."
    },
    {
      "code" : "child",
      "valueCode" : "2.3.5.3"
    },
    {
      "code" : "child",
      "valueCode" : "2.3.5.2"
    },
    {
      "code" : "child",
      "valueCode" : "2.3.5.1"
    }]
  },
  {
    "code" : "3.1.4",
    "display" : "Qualité et sécurité",
    "property" : [{
      "code" : "parent",
      "valueCode" : "3.1"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 3"
    },
    {
      "code" : "note",
      "valueString" : "Les prestations pour la qualité et la sécurité visent à optimiser la qualité des prestations réalisées par les ESMS dans le cadre d’une démarche d’amélioration continue, les évaluations internes et externes, la promotion de la bientraitance, la gestion des risques, l’analyse des pratiques, les espaces ressources et le soutien aux professionnels.\nLes prestations pour la qualité et la sécurité ont été organisées en deux composantes, l’une centrée sur l’organisation de l’accompagnement des personnes en situation de handicap, et la seconde en direction des professionnels.\nLes professionnels réalisant ces prestations sont notamment :\n \tles professionnels cadres fonctionnels non hiérarchiques et professionnels non cadres dédiés, comme les responsables de la démarche d’amélioration continue de la qualité, les professionnels impliqués dans l’évaluation interne et accompagnant l’évaluation externe,\n \tles professionnels compétents en matière de promotion de la bientraitance (conception des politiques, suivi des incidents et évènements indésirables et actions correctives) et à la gestion des risques au niveau organisationnel (risque infectieux, continuité de l’exploitation en cas de fonctionnement dégradé, crises, etc…), \n \téventuellement des professionnels extérieurs comme des intérimaires ou personnels mis à disposition, etc…"
    },
    {
      "code" : "child",
      "valueCode" : "3.1.4.1"
    },
    {
      "code" : "child",
      "valueCode" : "3.1.4.3"
    },
    {
      "code" : "child",
      "valueCode" : "3.1.4.2"
    }]
  },
  {
    "code" : "2.1",
    "display" : "Prestations de soins, de maintien et de développement des capacités fonctionnelles",
    "property" : [{
      "code" : "parent",
      "valueCode" : "2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 2"
    },
    {
      "code" : "note",
      "valueString" : "Comme l’ensemble des prestations de soins et d’accompagnement, ces prestations présentent les trois caractéristiques suivantes : \n \tElles ont vocation à se dérouler dans tous les lieux de vie de la personne : au sein d’un établissement, d’un service, du domicile, sur le lieu de scolarisation ou d’exercice professionnel. \n \tElles comprennent un ensemble d’actions : dans la nomenclature, les prestations sont décrites en fonction de l’objectif poursuivi. La notion de prestation inclut par conséquent les éléments de processus qui sont des manières de réaliser la prestation.\n \tLes prestations directes comprennent toutes les interventions répondant aux besoins de la personne y compris hors sa présence (notamment avec sa famille ou des professionnels) sous réserve que cette modalité permette également de répondre aux besoins de la personne."
    },
    {
      "code" : "child",
      "valueCode" : "2.1.2"
    },
    {
      "code" : "child",
      "valueCode" : "2.1.1"
    }]
  },
  {
    "code" : "3.2.1",
    "display" : "Locaux et autres ressources pour accueillir",
    "property" : [{
      "code" : "parent",
      "valueCode" : "3.2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 3"
    },
    {
      "code" : "note",
      "valueString" : "La mise à disposition de locaux constitue une fonction support, c’est une condition sine qua non de la réalisation des prestations directes soit car ces prestations se déroulent dans les locaux de la structure (locaux pour héberger, locaux de soins, locaux pour accueillir le jour) soit car le fonctionnement de toute structure exige a minima des locaux administratifs. Ces locaux sont différenciés dans la nomenclature selon 4 usages. Seront donc identifiés des locaux et des matériels : \n-\tpour héberger les personnes handicapées et permettre par conséquent la réalisation de prestations directes dans ses locaux la nuit,\n-\tpour accueillir le jour les personnes et permettre par conséquent la réalisation de prestations directes le jour,\n-\tpour effectuer des prestations directes de soins, de maintien et de développement des capacités fonctionnelles,\n-\tpour réaliser les prestations indirectes liées à gérer, manager, coopérer \n-\tLa dernière et cinquième composante regroupe les prestations liées à l’hygiène, à l’entretien et à la sécurité de ces locaux ainsi que des espaces extérieurs. \nLes 5 composantes de niveau 4 sont donc les suivantes :\n \t3.2.1.1 : Locaux et autres ressources pour héberger\n \t3.2.1.2 : Locaux et autres ressources pour accueillir le jour\n \t3.2.1.3 : Locaux et autres ressources pour réaliser des prestations de soins, de maintien et de développement des capacités fonctionnelles\n \t3.2.1.4 : Locaux et autres ressources pour gérer, manager, coopérer\n \t3.2.1.5 : Hygiène, entretien et sécurité des locaux et espaces extérieurs.\nAinsi une structure médicalisée pour adultes en situation de handicap disposant dans son autorisation uniquement de places d’internat réalise parmi les prestations indirectes : \n-\tLa fourniture de locaux pour héberger \n-\tLa fourniture de locaux pour accueillir le jour\n-\tLa fourniture de locaux liés à la réalisation de prestations de soins \n-\tLa fourniture de locaux liés à la réalisation de prestations gérer, manager, coopérer\n-\tDes prestations génériques liées à la sécurité des locaux, de leur hygiène et des espaces extérieurs \nA contrario une structure non médicalisée ne fonctionnant que de nuit réalise parmi les prestations indirectes : \n-\tLa fourniture de locaux pour héberger \n-\tLa fourniture de locaux liés à la réalisation de prestations gérer, manager, coopérer\n-\tDes prestations génériques liées à la sécurité des locaux, de leur hygiène et des espaces extérieurs \nParmi les professionnels réalisant ces prestations, peuvent notamment être cités:\n-\tle personnel de surveillance de nuit, de surveillance de jour, concierges,\n-\tle personnel de maintenance, d’entretien, y compris des espaces verts"
    },
    {
      "code" : "child",
      "valueCode" : "3.2.1.5"
    },
    {
      "code" : "child",
      "valueCode" : "3.2.1.4"
    },
    {
      "code" : "child",
      "valueCode" : "3.2.1.3"
    },
    {
      "code" : "child",
      "valueCode" : "3.2.1.2"
    },
    {
      "code" : "child",
      "valueCode" : "3.2.1.1"
    }]
  },
  {
    "code" : "1.1.5",
    "display" : "Besoins en matière de fonctions cardio-vasculaire, hématopoïétique, immunitaire et respiratoire",
    "property" : [{
      "code" : "parent",
      "valueCode" : "1.1"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 4"
    },
    {
      "code" : "note",
      "valueString" : "Cette composante de niveau 3 traite des fonctions cardio-vasculaire, hématopoïétique (production du sang), immunitaire et respiratoire.\nDESCRIPTION \nBesoins en lien avec les fonctions impliquées dans le système cardio-vasculaire, les systèmes hématopoïétique (production du sang) et immunitaire, et le système respiratoire.\nBesoins quant aux structures des systèmes cardio-vasculaire, immunitaire, et respiratoire.\nCODES CIF CORRESPONDANTS (OMS, 2001)\nCette composante de niveau 4 porte sur l’ensemble des deux chapitres :\n◦\tb4 – Fonctions des systèmes cardio-vasculaire, hématopoïétique, immunitaire et respiratoire\n◦\ts4 – Structures liées des systèmes cardio-vasculaire, immunitaire et respiratoire \nCE QUE CE N’EST PAS \nIl ne s’agit pas des besoins d’accès aux soins courants couverts par la composante « 1.1.1.10 – Besoins pour entretenir et prendre soin de sa santé ».\nDans la même logique que pour le reste de la nomenclature, les besoins correspondent à un écart (principe d’évaluation de la situation), il ne s’agit donc pas des réponses à mettre en œuvre pour les compenser (principe d’accompagnement)."
    }]
  },
  {
    "code" : "2.2",
    "display" : "Prestations en matière d’autonomie",
    "property" : [{
      "code" : "parent",
      "valueCode" : "2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 2"
    },
    {
      "code" : "note",
      "valueString" : "Les prestations en matière d’autonomie sont par nature transversales à tous les domaines de la vie. \nLes prestations en matière d’autonomie s’inscrivent dans une logique de compensation qui inclut toutes les nuances d’un accompagnant visant le maintien et l’acquisition d’une autonomie maximale et peut constituer dès lors une aide partielle, répétée ou continue (« faire avec » la personne accompagnée) et aller, pour les situations d’autonomie les plus réduites, jusqu’à suppléer la personne dans la conduite de son activité (« faire pour (ou à la place de) » la personne accompagnée). \nLes prestations en matière d’autonomie peuvent être réalisées par tous les professionnels. Elles sont, à titre principal, réalisées par : \n \tdes aides médico-psychologiques\n \tdes éducateurs et moniteurs : éducateurs spécialisés, éducateurs de jeunes enfants, éducateurs techniques, moniteurs d’atelier, éducateurs scolaires, etc.\n \tdes assistants de service social et conseillers en économie sociale et familiale\n \tdes maîtres et maîtresses de maison\n \tdes interprètes, codeurs, interfaces de communication et interprètes\nCes prestations sont organisées en 3 composantes de niveau 3 : \n \taccompagnements pour les actes de la vie quotidienne\n \taccompagnements pour la communication et les relations avec autrui\n \taccompagnements pour prendre des décisions adaptées et pour la sécurité \nLES BESOINS AUXQUELS ELLES REPONDENT :\n\tElles répondent aux besoins en matière d’autonomie des personnes, dans leurs deux dimensions : \n \tl’autonomie fonctionnelle (la capacité fonctionnelle à faire) \n \tle comportement autonome (indépendance), la capacité à prendre des décisions, selon ses valeurs et à assumer les conséquences."
    },
    {
      "code" : "child",
      "valueCode" : "2.2.3"
    },
    {
      "code" : "child",
      "valueCode" : "2.2.2"
    },
    {
      "code" : "child",
      "valueCode" : "2.2.1"
    }]
  },
  {
    "code" : "3.1.4.2",
    "display" : "Analyse des pratiques, espaces ressource et soutien aux personnels",
    "property" : [{
      "code" : "parent",
      "valueCode" : "3.1.4"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 4"
    },
    {
      "code" : "note",
      "valueString" : "Cette prestation renvoie à :\n\tL’analyse des pratiques professionnelles (exemples : les « groupes Balint » ou les groupes d’analyse de la pratique centrés sur le récit par le professionnel concerné d’une relation d’aide éprouvante, et permettant avec l’apport du groupe une transformation de ses aptitudes professionnelles par une meilleure compréhension psychologique de lui-même ainsi que de la situation relationnelle dans laquelle il est impliqué),\n\tLes espaces-ressources dont le but est le soutien aux professionnels (temps réguliers et prévus) et la réflexion éthique,\n\tLes groupes ad hoc de soutien aux professionnels dans les situations difficiles (accompagnement du deuil, conséquences des violences, accidents, ruptures de parcours etc.). \nIl faut souligner que cette prestation cible les professionnels en contact avec les personnes en situation de handicap et vise à les soutenir dans ce qu’ils peuvent vivre  au quotidien ou lors d’évènements difficiles avec les personnes accompagnées et/ou avec l’équipe pluridisciplinaire. Cette prestation vise une transformation positive des aptitudes professionnelles.\nCE QUE CE N’EST PAS :\n\tLes prestations de supervision seront identifiées en 3.1.4.3. Prestations de supervision. \n\tLes prestations liées à la prévention des risques psychosociaux se trouveront en 3.1.1.3 - Gestion prévisionnelle des emplois et des compétences, formation professionnelle continue, conditions de travail et dialogue social\nLes professionnels mettant en œuvre cette prestation peuvent être notamment  des psychologues, thérapeutes, consultants salariés ou prestataires de la structure."
    }]
  },
  {
    "code" : "2.3.3.6",
    "display" : "Accompagnements pour l’exercice de mandats électoraux, la représentation des pairs et la pair aidance",
    "property" : [{
      "code" : "parent",
      "valueCode" : "2.3.3"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 4"
    },
    {
      "code" : "note",
      "valueString" : "Il s’agit des accompagnements permettant à la personne d’exercer ses mandats électoraux, de représenter ses pairs, par exemple dans le cadre d’instances de la démocratie sanitaire, mais également d’être pair-aidante, de soutenir d’autres personnes en situation de handicap. \nIl s’agit par exemple : \n\td’accompagnement pour renforcer les compétences d’action collective des personnes (par opposition aux seules compétences individuelles)\n\tdes actions de formation à l’autodétermination à destination des personnes\n\tde l’accompagnement pour l’autodétermination (coaching, ateliers)\nPour rappel, la pair-aidance s’appuie sur le postulat selon lequel l’expérience d’un même vécu et d’un parcours de rétablissement (« recovery ») constitue le support d’une relation d’entraide.\nCes accompagnements peuvent être réalisés par des professionnels sociaux et éducatifs de l’accompagnement. \nEn outre ces prestations s’inscrivent dans une logique de compensation qui inclut toutes les nuances d’un accompagnement : « apprendre à faire », « faire avec », « faire pour (ou à la place de) ». Elles ont pour objectif le développement, l’acquisition et le maintien du maximum d’autonomie de la personne, celle-ci pouvant ne plus avoir besoin d’un accompagnement pour exercer ce rôle social. \nBESOINS AUXQUELS LA PRESTATION REPOND : \nA titre principal, cette prestation répond aux besoins suivants :\n\tBesoins pour accéder aux droits et à la citoyenneté : \n \tBesoins pour accéder à la vie politique et à la citoyenneté\n \tBesoins pour faire du bénévolat \n\tBesoins pour apprendre à être aidant. \n \tBesoins pour apprendre à aider les autres à se déplacer, communiquer, avoir des relations avec autrui, avoir une bonne alimentation, veiller à leur santé. \nCE QUE CE N’EST PAS : \nD’autres accompagnements peuvent se dérouler dans le cadre de l’exercice d’un mandat électoral. Ils sont alors rattachés aux prestations afférentes, en matière d’autonomie, de soins ou de participation sociale."
    }]
  },
  {
    "code" : "2.3.4.3",
    "display" : "Accompagnements pour le développement de l’autonomie pour les déplacements",
    "property" : [{
      "code" : "parent",
      "valueCode" : "2.3.4"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 4"
    },
    {
      "code" : "note",
      "valueString" : "Cette prestation regroupe les accompagnements mis en œuvre pour permettre le maintien et le développement de l’autonomie des personnes dans leurs déplacements. \nIl s’agit : \nDe l’accompagnement pour permettre une utilisation autonome des transports en commun\nDe l’accompagnement pour l’apprentissage de la conduite de différents véhicules \nDe soutien pour la connaissance des règles de la circulation routière, en tant que piéton ou en tant que conducteur (préparation de la passation des épreuves de sécurité routière)\nEn outre ces prestations s’inscrivent dans une logique de compensation qui inclut toutes les nuances d’un accompagnement : « apprendre à faire », « faire avec », « faire pour (ou à la place de) ». Elles ont pour objectif le développement, l’acquisition et le maintien du maximum d’autonomie de la personne.\nBESOINS AUXQUELS LA PRESTATION REPOND : \n\tBesoins pour se déplacer avec un moyen de transport : \n◦\tPour utiliser un moyen de transport\n◦\tPour conduire un véhicule. \nCE QUE CE N’EST PAS : \n\tIl ne s’agit pas d’organiser ou de financer la passation du permis de conduire des véhicules motorisés. \n\tL’accompagnement réalisé pour identifier les ressources nécessaires à une personne pour financer sa passation du permis de conduire relève d’une prestation d’accompagnement en matière de ressources et d’autogestion (2-3-5)\n\tLa préparation des épreuves de sécurité routière par un professionnel enseignant relève d’une prestation d’accompagnement pour mener sa vie d’élève, d’étudiant ou d’apprenti. \nL’accompagnement d’une personne lors de ses déplacements pour un besoin lié à l’autonomie relève de la prestation afférente à son besoin (entretien personnel, communication, prendre des décisions adaptées)"
    }]
  },
  {
    "code" : "2.3.2.1",
    "display" : "Accompagnements pour vivre dans un logement",
    "property" : [{
      "code" : "parent",
      "valueCode" : "2.3.2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 4"
    },
    {
      "code" : "note",
      "valueString" : "Cette prestation recouvre les accompagnements réalisés pour permettre à la personne d’acquérir un logement, de le meubler, de maintenir ou développer des habitudes de vie, comportements et compétences lui permettant de vivre dans un logement. \nCes accompagnements sont notamment réalisés par des professionnels sociaux et éducatifs de l’accompagnement en particulier : \n \tdes aides médico psychologiques, \n \tdes éducateurs (éducateurs spécialisés, éducateurs de jeunes enfants), \n \tdes assistants de service social et conseillers en économie sociale et familiale, \n \tdes maîtres et maîtresses de maison\nEn outre ces prestations s’inscrivent dans une logique qui inclut toutes les nuances d’un accompagnement : de « apprendre à la personne à faire », à « faire avec », jusqu’à « faire pour (ou à la place de) ».\nExemples : \n \tAu sein d’un établissement médico-social : \nIl peut s’agir d’accompagner la recherche d’un logement autonome ou accompagné. \nIl peut également s’agir d’accompagner pour acquérir son ameublement personnel, de travailler le rapport aux temps familiaux de soirée, d’accompagner la cohabitation avec les autres résidents, etc.\n \tEn milieu ordinaire  :\nIl peut s’agir d’aider à l’aménagement d’un logement, à l’acquisition de compétences pratiques (gestion locative : gérer une fuite d’eau, payer son loyer, ses factures liées au logement, etc.), ou encore repérer les difficultés propres à la vie dans un logement et les résoudre (cohabitation avec le voisinage, etc.). \nBESOINS AUXQUELS LA PRESTATION REPOND A TITRE PRINCIPAL :\n\tBesoins pour vivre dans un logement : \t\n-\tBesoins pour avoir un lieu d’hébergement \n-\tBesoins pour vivre seul dans un logement. \n\tBesoins transversaux en matière d’apprentissage : respecter les règles sociales\nCE QUE CE N’EST PAS : \n\tLes prestations de soins de maintien et de développement des capacités fonctionnelles ainsi que les prestations en matière d’autonomie, y compris lorsqu’elles sont réalisées au logement de la personne sont identifiées selon les cas en 2-1 ou 2-2. Ainsi, l’appui de l’ergothérapeute pour une amélioration du logement est une prestation d’auxiliaire médical identifiée en 2.1.2.1.\n\tLe travail sur l’expression du projet de l’usager, y compris son projet de logement sera identifié en 2.3.1.1. \n\tIl ne s’agit pas d’identifier le fait qu’une prestation se déroule au logement de la personne puisque par principe toutes les prestations directes peuvent se dérouler sur tous les lieux de vie de la personne."
    }]
  },
  {
    "code" : "3.2.4.1",
    "display" : "Transports liés à accueillir (domicile-structure)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "3.2.4"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 4"
    },
    {
      "code" : "note",
      "valueString" : "Il s’agit des transports de personnes liés au fait qu’une personne soit accompagnée dans une structure, qu’elle soit service ou établissement. \nDu fait de cet accompagnement réalisé dans les murs de la structure, la structure médico-sociale peut être amenée à assurer une prestation de transport pour les personnes afin de leur permettre de se rendre dans la structure. Il s’agit des transports liés au fait pour la personne d’aller et venir entre la structure et son domicile, fréquemment visés par la règlementation. \nCes transports domicile-structure peuvent être réalisés par les professionnels de l’ESMS dont la fonction est par exemple celle de chauffeur ou d’accompagnateur de bus (ou par d’autres professionnels de la structure), ou par des tiers,.\nCes transports sont réalisés avec \n \tles moyens de transport de l’ESMS, \n \tou les véhicules personnels des professionnels,  des transports en commun (train, avion…), des sociétés de transport en autocars, ambulances, VSL-véhicules sanitaires légers, taxis conventionnés, et dont la charge est supportée par l’ESMS.\nOn trouvera par exemple les circuits de ramassage pour enfants et adolescents, les transports pour l’accueil de jour en FAM et en MAS, en ESAT lorsqu’ils existent, la prise en charge des transports domicile –SESSAD pour des prises en charge collectives."
    }]
  },
  {
    "code" : "2.1.2",
    "display" : "Rééducation et réadaptation fonctionnelle",
    "property" : [{
      "code" : "parent",
      "valueCode" : "2.1"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 3"
    },
    {
      "code" : "note",
      "valueString" : "Les prestations de rééducation et de réadaptation fonctionnelle sont réalisées, à titre principal, par trois types de professionnels :\n \tParmi les professionnels de santé identifiés par le code de la santé publique dans sa quatrième partie, la liste non exhaustive des auxiliaires médicaux suivants réalisent des prestations de rééducation et de réadaptation fonctionnelle : masseur-kinésithérapeute, pédicure-podologue, ergothérapeute, psychomotricien, orthophoniste, orthoptiste, audioprothésiste, prothésiste et orthésiste, diététicien.\n \tDes professionnels spécialistes de la réadaptation liée aux actes de la vie quotidienne et pour la mobilité des personnes ayant un besoin en lien avec les fonctions visuelles : les instructeurs en locomotion et les AVJistes (ou avéjistes). \n \tDes superviseurs.\nCes prestations ont trois visées : préventive, curative et palliative. \nBESOINS AUXQUELS CES PRESTATIONS REPONDENT : \nLa différence entre les prestations de rééducation et de réadaptation s ‘explique au regard des objectifs poursuivis et besoins afférents :\n \tla rééducation vise à rétablir ou maintenir une fonction du corps. \n \tla réadaptation vise à élaborer les stratégies de contournement permettant à la personne de réaliser les activités en tenant compte de ses caractéristiques physiques (les fonctions de son corps) et de son environnement.\nCes prestations répondent à des besoins en matière de santé somatique ou psychique."
    },
    {
      "code" : "child",
      "valueCode" : "2.1.2.1"
    }]
  },
  {
    "code" : "3.2.1.2",
    "display" : "Locaux et autres ressources pour accueillir le jour",
    "property" : [{
      "code" : "parent",
      "valueCode" : "3.2.1"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 4"
    },
    {
      "code" : "note",
      "valueString" : "Cette prestation consiste pour une structure médico-sociale à fournir des locaux permettant d’être accompagné en journée. \nCette prestation peut être mise en œuvre \n-\tPar différentes structures : service ou établissement\n-\tEn différents lieux dont la structure permet l’existence en assurant leur entretien, la couverture de leur charges, la location…: dans les murs de la structure, hors les murs (unités d’enseignement externalisées)\n-\tSelon des temporalités différentes tous les jours, en semaine uniquement, à l’année, de manière temporaire, en urgence. \nElle peut être combinée, dans la structure, avec la délivrance d’une prestation de fourniture de locaux pour héberger lorsque la structure effectue des accompagnements nuit et jour."
    }]
  },
  {
    "code" : "2.3.4",
    "display" : "Accompagnements pour participer à la vie sociale",
    "property" : [{
      "code" : "parent",
      "valueCode" : "2.3"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 3"
    },
    {
      "code" : "note",
      "valueString" : "La notion de vie sociale consiste, pour une personne, à s’engager et à interagir socialement.\nToute personne s’inscrit dans une vie sociale, que ce soit dans ses relations avec ses proches, son voisinage, les autres personnes accompagnées par l’établissement dans lequel la personne peut être accompagnée, dans les activités de loisirs, dans ses déplacements, etc. \nCette composante traite par conséquent des accompagnements réalisés pour participer à la vie sociale. Elle se décompose en 4 composantes de niveau 4 : \n-\t2.3.4.1 – Accompagnements du lien avec les proches et le voisinage\n-\t2.3.4.2 – Accompagnements pour la participation aux activités sociales et de loisirs \n-\t2.3.4.3 – Accompagnements pour le développement de l’autonomie dans les déplacements  \nEn outre ces prestations s’inscrivent dans une logique de compensation qui inclut toutes les nuances d’un accompagnement : « apprendre à faire », « faire avec », « faire pour (ou à la place de) ». Elles ont pour objectif le développement, l’acquisition et le maintien du maximum d’autonomie de la personne."
    },
    {
      "code" : "child",
      "valueCode" : "2.3.4.3"
    },
    {
      "code" : "child",
      "valueCode" : "2.3.4.2"
    },
    {
      "code" : "child",
      "valueCode" : "2.3.4.1"
    }]
  },
  {
    "code" : "3.1.2.2",
    "display" : "Gestion administrative",
    "property" : [{
      "code" : "parent",
      "valueCode" : "3.1.2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 4"
    },
    {
      "code" : "note",
      "valueString" : "Cette prestation correspond à la gestion administrative effectuée notamment par du personnel polyvalent dont les tâches peuvent être extrêmement variées par nature (accueil, vigilance, courrier, téléphone, reproduction des documents, classement, archivage, autres tâches administratives  etc.)."
    }]
  },
  {
    "code" : "3.2.4",
    "display" : "Transports liés au projet individuel",
    "property" : [{
      "code" : "parent",
      "valueCode" : "3.2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 3"
    },
    {
      "code" : "note",
      "valueString" : "Les structures médico-sociales peuvent être amenées à mettre en place des prestations de transports des personnes. Ces prestations sont organisées de manière individuelle ou collective, assurées par la structure ou par le recours à des prestataires financés par la structure. \nLes transports liés au projet individuels ne constituent pas directement une réponse aux besoins d’une personne tels que décrits  par la nomenclature des besoins : il n’existe pas de « besoin d’être transporté». Ces transports constituent par contre une condition sine qua non de la réalisation des prestations directes. \nIls se distinguent donc des transports liés à gérer-manager-coopérer (qui sont  nécessaires à la réalisation des prestations de pilotage) et des transports de biens et fournitures liés aux prestations de restauration et de gestion du linge (3.2.5). \nLes transports liés au projet individuel sont de deux natures que la structuration des prestations reprend :\n-\t3.2.4.1 Transports liés à accueillir \nIl s’agit des transports de personnes liés au fait pour une personne d’être accueillie physiquement dans une structure, qu’elle soit service ou établissement. Du fait de cet accompagnement réalisé dans les murs de la structure, la structure médico-sociale peut assurer une prestation de transport pour les personnes afin de leur permettre de se rendre dans la structure. Il s’agit des transports liés au fait pour la personne d’aller et venir entre la structure et son domicile, fréquemment visés par la règlementation. \n-\tPrestation 3.2.4.2 Transports liés aux prestations de soins, de maintien et de développement des capacités fonctionnelles \n-\tPrestation 3.2.4.3 Transports liés à l’autonomie et à la participation sociale \nCes deux prestations sont de même nature. Il s’agit de transports de personnes nécessaires à la délivrance d’une prestation directe relevant de l’un des trois domaines de prestations : soins, autonomie ou participation sociale. \nExemples : mettre en place des transports pour emmener les personnes accompagnées à l’école, au travail, pour consulter un soignant, se rendre dans un lieu distant de l’ESMS pour une activité de loisirs… \nCE QUE CE N’EST PAS :\n\tDans la nomenclature des prestations, toutes les prestations directes sont délivrées par principe sur tous les lieux de vie. Le fait qu’un professionnel se déplace pour effectuer une prestation hors les murs de la structure ne constitue pas une prestation mais le mode de réalisation de la prestation. Par conséquent, lorsque le professionnel se déplace pour effectuer une prestation de soins ou d’accompagnement, il ne s’agit pas d’une prestation de transport lié au projet individuel mais d’une prestation directe précise : pour mener sa vie d’élève, pour la communication…."
    },
    {
      "code" : "child",
      "valueCode" : "3.2.4.3"
    },
    {
      "code" : "child",
      "valueCode" : "3.2.4.2"
    },
    {
      "code" : "child",
      "valueCode" : "3.2.4.1"
    }]
  },
  {
    "code" : "3.2",
    "display" : "Fonctions logistiques",
    "property" : [{
      "code" : "parent",
      "valueCode" : "3"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 2"
    },
    {
      "code" : "note",
      "valueString" : "Parmi les prestations indirectes, les fonctions logistiques regroupent les prestations matérielles nécessaires à la réalisation des prestations directes : \n\tles mises à disposition de locaux  : il s’agira de locaux d’hébergement, de locaux pour accueillir de jour, de locaux de soins, de locaux pour gérer, manager, coopérer, \n\tles mises à disposition d’autres ressources: il s’agira également d’identifier, pour chacun des usages de ces locaux, l’ensemble des « autres ressources » nécessaires pour le fonctionnement habituel de l’ESMS (du matériel scolaire, du matériel de soins…), \n\tl’existence de prestations communes à l’ensemble de l’établissement ou du service médico-social  : prestation d’hygiène des locaux avec le matériel et les consommables adéquats, prestation d’entretien courant de la structure, mise en place des conditions de sécurité  contre les risques d’incendie, matériels et entretien des espaces extérieurs),\n\tle fait de fournir des repas aux personnes accompagnées,\n\tle fait d’effectuer l’entretien du linge,\n\tle fait de mettre en place des transports dits « liés au projet individuel » car nécessaires à la réalisation des prestations directes."
    },
    {
      "code" : "child",
      "valueCode" : "3.2.3"
    },
    {
      "code" : "child",
      "valueCode" : "3.2.1"
    },
    {
      "code" : "child",
      "valueCode" : "3.2.2"
    },
    {
      "code" : "child",
      "valueCode" : "3.2.4"
    },
    {
      "code" : "child",
      "valueCode" : "3.2.5"
    }]
  },
  {
    "code" : "1.3.4",
    "display" : "Besoins pour participer à la vie sociale et se déplacer avec un moyen de transport",
    "property" : [{
      "code" : "parent",
      "valueCode" : "1.3"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 3"
    },
    {
      "code" : "note",
      "valueString" : "Cette composante traite de la participation à la vie sociale (dans ses composantes relationnelles notamment), et des déplacements avec un moyen de transport.\nAinsi, cette composante de niveau 3 (1.3.4) Besoins pour participer à la vie sociale, se déplacer avec un moyen de transport est constituée de 2 composantes de niveau 4 comme suit :\n \t1.3.4.1 – Besoins pour participer à la vie sociale \n \t1.3.4.2 – Besoins pour se déplacer avec un moyen de transport"
    },
    {
      "code" : "child",
      "valueCode" : "1.3.4.2"
    },
    {
      "code" : "child",
      "valueCode" : "1.3.4.1"
    }]
  },
  {
    "code" : "1",
    "display" : "Besoins",
    "property" : [{
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "BLOC"
    },
    {
      "code" : "child",
      "valueCode" : "1.3"
    },
    {
      "code" : "child",
      "valueCode" : "1.2"
    },
    {
      "code" : "child",
      "valueCode" : "1.1"
    }]
  },
  {
    "code" : "1.3.3.5",
    "display" : "Besoins pour apprendre à être pair-aidant",
    "property" : [{
      "code" : "parent",
      "valueCode" : "1.3.3"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 4"
    },
    {
      "code" : "note",
      "valueString" : "Cette composante de niveau 4 porte sur la pair-aidance, mais également sur le besoin à pouvoir aider d’autres personnes, en particulier de son entourage.\nPour rappel, la pair-aidance s’appuie sur le postulat selon lequel l’expérience d’un même vécu  et d’un parcours de rétablissement (« recovery ») constitue le support d’une relation d’entraide.\nDans la classification internationale du fonctionnement, du handicap et de la santé (CIF), le besoin d’être accompagné pour être aidant se rapporte essentiellement à la cellule familiale ou à d’autres personnes (chapitre 6 relatifs à la vie domestique) sans préciser la notion de pair. Cependant le chapitre 7 de la CIF (relations particulières avec autrui) décrit une activité spécifique de « relations avec les pairs ».\nLe groupe technique national a choisi de faire une synthèse de ces deux activités (relations avec les pairs et s’occuper des autres) pour couvrir plus spécifiquement le besoin d’apprendre à être pair-aidant.\nDESCRIPTION : \nBesoins pour aider les autres et ses pairs à : \n - se déplacer\n- communiquer\n- avoir des relations avec autrui\n- avoir une bonne alimentation\n- veiller à leur santé\nCODES CIF CORRESPONDANTS (OMS, 2001) :\nLa composante de niveau 4 porte sur des activités du chapitre 7 (Relations particulières avec autrui) de la CIF : \n◦\td7402 Relations avec des pairs \nCréer et entretenir des relations spécifiques avec des personnes occupant la même position, ou jouissant du même rang ou du même prestige que soi-même en termes de position sociale.\n◦\td660 S'occuper des autres \nAider les membres du ménage et les autres dans leurs activités d'apprentissage, de communication, d'entretien personnel, de mouvement et de déplacement, à l'intérieur ou à l'extérieur, et se préoccuper du bien-être des membres de la famille et des autres personnes.\nCE QUE CE N’EST PAS :\nDans la même logique que pour le reste de la nomenclature, les besoins correspondent à un écart (principe d’évaluation de la situation), il ne s’agit donc pas des réponses à mettre en œuvre pour les compenser (principe d’accompagnement)."
    }]
  },
  {
    "code" : "3.1.5.2",
    "display" : "Appui-Ressources et partenariats institutionnels",
    "property" : [{
      "code" : "parent",
      "valueCode" : "3.1.5"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 4"
    },
    {
      "code" : "note",
      "valueString" : "Cette prestation correspond à l’action des ESMS : \n\ten matière d’appui/ressources sur le territoire : l’ESMS est identifié comme expert sur son territoire, il mobilise les tiers, répond à leurs sollicitations en matière de conseil ou de formation (ex: la démarche de labellisation S3A : accueil, accompagnement, accessibilité). \nExemples : \n-\tParticiper à la formation de professionnels : interventions dans le cursus d’enseignement des écoles de formation\n-\tMener des actions de sensibilisation auprès de professionnels ou tout public : proposer une intervention régulière aux professionnels de crèches, d’accueils collectifs de loisirs\n-\tExpertise-conseil et mise à disposition de temps de personnels  auprès d'autres structures médico-sociales, équipe relai handicap rare, structures de droit commun et autres organismes.\n-\tMise à disposition / prêts de matériel spécifique\n\ten matière de partenariat avec : \no\tles administrations et autorités de tarification.\nPar exemple, la participation aux instances de la démocratie sanitaire (conférence régionale de la santé et de l’autonomie, conférences de territoire...), la participation aux commissions d’appel à projet de l’ARS, du Conseil départemental (ou mixtes), la participation à des groupes de travail pour l’évaluation des besoins sur le territoire…\no\tles collectivités locales : municipalités, communautés d’agglomération, départements (par exemple pour participer aux commissions d’accessibilité, aux consultations du département pour le schéma des transports…), régions ,la MDPH (par exemple, siéger à la commission des droits et de l’autonomie des personnes handicapées -CDAPH-, répondre aux sollicitations de l’Equipe pluridisciplinaire de la MDPH)…\nCE QUE CE N’EST PAS : \n\tIl ne s’agit pas des relations avec les autorités concernant le fonctionnement de la structure, par exemple la négociation d’un CPOM, la procédure budgétaire ou le dialogue de gestion restent dans la gestion administrative, budgétaire, financière et comptable en 3.1.2.1.\n\tIl ne s’agit pas des travaux conjoints avec la MDPH pour un projet individuel d’une personne accompagnée. Ces derniers sont consubstantiels de la prestation directe afférente. Par exemple, l’élaboration de bilans pour une personne à destination de l’équipe pluridisciplinaire de la MDPH par un psychologue pourra être identifiée dans la composante de niveau 4 correspondante des prestations de soins, de maintien et de développement des capacités fonctionnelles (2.1)."
    }]
  },
  {
    "code" : "1.1.2",
    "display" : "Besoins en matière de fonctions sensorielles",
    "property" : [{
      "code" : "parent",
      "valueCode" : "1.1"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 4"
    },
    {
      "code" : "note",
      "valueString" : "Cette composante de niveau 3 traite des structures et des fonctions de l’œil et de l’oreille ainsi que des autres fonctions sensorielles. \nLa CIF classe dans un même chapitre les fonctions sensorielles et la douleur. L’équipe SERAFIN-PH et le groupe technique national ont choisi de distinguer les fonctions sensorielles et la douleur pour qualifier deux besoins différents. \nDESCRIPTION \nBesoins en lien avec les fonctions suivantes : la vue, l'ouïe, le goût, l’odorat, les fonctions proprioceptives, ainsi que les fonctions sensorielles associées à la température ou autres stimuli.\nBesoins quant aux structures de l'œil et de l'oreille.\nCODES CIF CORRESPONDANTS (OMS, 2001)\nCette composante de niveau 4 porte sur une partie du chapitre :\n◦\tb2 - fonctions sensorielles\no\tFonctions visuelles et fonctions connexes (b210-b229)\no\tFonctions de l’audition et fonction vestibulaire (b230-b249)\no\tFonctions sensorielles additionnelles (b250-b279)\n\tFonctions de goût\n\tFonctions de l’odorat\n\tFonctions proprioceptives\n\tFonctions sensorielles associés à la température ou d’autres stimuli\n\tAutre fonctions sensorielles additionnelles\nEt sur l’ensemble du chapitre :\n◦\ts2 - structures : œil, oreille et structures associées\nCE QUE CE N’EST PAS\nDans la CIF les fonctions sensorielles et la douleur font partie d’un même chapitre. Pour la nomenclature SERAFIN-PH, ces fonctions sont scindées en 2 ; aussi les besoins en matière de douleur font-ils l’objet d’une composante de niveau 4 propre « 1.1.1.3 – Besoins en matière de douleur ».\nIl ne s’agit pas des besoins d’accès aux soins courants qui sont couverts par la composante « 1.1.1.10 – Besoins pour entretenir et prendre soin de sa santé ».\nDans la même logique que pour le reste de la nomenclature, les besoins correspondent à un écart (principe d’évaluation de la situation), il ne s’agit donc pas des réponses à mettre en œuvre pour les compenser (principe d’accompagnement)."
    }]
  },
  {
    "code" : "2.3.5.3",
    "display" : "Informations, conseils et mise en œuvre des mesures de protection des adultes",
    "property" : [{
      "code" : "parent",
      "valueCode" : "2.3.5"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 4"
    },
    {
      "code" : "note",
      "valueString" : "Cette prestation recouvre les accompagnements pour informer et conseiller les bénéficiaires potentiels de l’existence des mesures de protection juridique des majeurs, et les accompagner si nécessaire dans les démarches afin de mobiliser les mesures de protection adaptées.\nDans les établissements publics du 6° et du 7° du L312-1 du code de l’action sociale et des familles, la prestation peut consister, pour une structure médico-sociale, à exercer un mandat de protection en qualité de préposé d’établissement. Il peut aussi s’agir des liens de coordination noués pour assurer les mesures de protection, entre les professionnels accompagnant la personne et son mandataire, qu’il soit professionnel (préposé d’établissement, salarié associatif ou libéral) ou membre de la famille.\nCette prestation est réalisée, à titre principal, par des mandataires judiciaires (dans le cas évoqué ci-avant) ou des professionnels d’établissement ou de service médico-social notamment : \n \tdes éducateurs et moniteurs : éducateurs spécialisés, éducateurs de jeunes enfants, éducateurs techniques, moniteurs d’atelier, éducateurs scolaires…\n \tdes assistants de service social et conseillers en économie sociale et familiale\nCes prestations s’inscrivent également dans une logique de compensation qui inclut toutes les nuances d’un accompagnement : « apprendre à faire », « faire avec », « faire pour (ou à la place de) ». Elles ont pour objectif le développement, l’acquisition et le maintien du maximum d’autonomie de la personne notamment dans la gestion de ses relations avec les professionnels chargés de la gestion de la mesure de protection qui la concerne.\nBESOINS ESSENTIELS AUXQUELS LA PRESTATION REPOND : \n\tBesoins en matière de ressources et d’autosuffisance économique"
    }]
  },
  {
    "code" : "1.3.4.2",
    "display" : "Besoins pour se déplacer avec un moyen de transport",
    "property" : [{
      "code" : "parent",
      "valueCode" : "1.3.4"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 4"
    },
    {
      "code" : "note",
      "valueString" : "Cette composante de niveau 4 porte sur les déplacements avec un moyen de transport, dont l’utilisation des moyens de transports et la conduite d’un véhicule.\nDESCRIPTION : \nBesoins pour utiliser un moyen de transport\nBesoins pour conduire un véhicule\nCODES CIF CORRESPONDANTS (OMS, 2001) :\nLa composante de niveau 4 porte sur une partie du chapitre 4 (mobilité) des activités et participation de la CIF : \n◦\td470- d479 Se déplacer avec un moyen de transport\no\td470 Utiliser un moyen de transport \nUtiliser un moyen de transport en tant que passager, être conduit en voiture ou en bus […], en voiture d’enfant ou poussette, en taxi […], en bus, en train, en tram, en avion, en métro, en bateau.\no\td475 Conduire un véhicule \nConduire un moyen de transport de quelque type que ce soit, comme conduire une voiture, rouler en vélo ou piloter un bateau \nCE QUE CE N’EST PAS :\nCette composante de niveau 4 ne porte pas sur les activités se déplacer et marcher. Elles en sont exclues car couvertes, dans le domaine Autonomie, par la composante de niveau 4 « 1.2.1.3 – Besoins pour la mobilité ».\nDans la même logique que pour le reste de la nomenclature, les besoins correspondent à un écart (principe d’évaluation de la situation), il ne s’agit donc pas des réponses à mettre en œuvre pour les compenser (principe d’accompagnement)."
    }]
  },
  {
    "code" : "2.3.3.1",
    "display" : "Accompagnements pour mener sa vie d’élève, d’étudiant ou d’apprenti",
    "property" : [{
      "code" : "parent",
      "valueCode" : "2.3.3"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 4"
    },
    {
      "code" : "note",
      "valueString" : "Cette prestation rassemble tous les accompagnements effectués auprès d’un élève, d’un apprenti ou d’un étudiant, pour répondre aux besoins transversaux en matière d’apprentissage et à ceux rencontrés dans le cadre du travail. Elle comprend également l’appui et l’accompagnement pour l’orientation professionnelle et la recherche de stages liés à la formation. \nCes accompagnements : \n◦\tSont des temps d’enseignement = (dont professionnels et y compris en alternance), avant et après le bac y compris lorsque ceux-ci donnent lieu à un contrat d’apprentissage ou un contrat de professionnalisation. \n◦\tSont également des temps d’accompagnement réalisés en même temps que le temps d’enseignement qui visent la complémentarité avec l’intervention pédagogique. \n◦\tSont enfin les temps d’accompagnement permettant d’aider la personne à rechercher un stage et à réaliser son stage\nCes accompagnements se déroulent dans tous les lieux de scolarisation ou formation initiale ou continue, quelle qu’en soit la forme administrative et la localisation.\nCes prestations sont réalisées, à titre principal, par : \n\tdes enseignants qu’ils soient salariés ou mis à disposition de l’établissement ou du service médico-social par l’éducation nationale\n\tdes professionnels sociaux et éducatifs de l’accompagnement et en particulier: \n \tdes aides médico psychologiques\n \tdes éducateurs et moniteurs : éducateurs spécialisés, éducateurs de jeunes enfants, éducateurs techniques, moniteurs d’atelier, éducateurs scolaires, etc.\nEn outre, ces prestations s’inscrivent dans une logique de compensation qui inclut toutes les nuances d’un accompagnement : « apprendre à faire », « faire avec », « faire pour (ou à la place de) ».. Elles ont pour objectif le développement, l’acquisition et le maintien du maximum d’autonomie de la personne.\nBESOINS AUXQUELS LA PRESTATION REPOND : \n\tBesoins en lien avec la vie scolaire et étudiante : \n \tBesoins pour l’éducation préscolaire\n \tBesoins pour l’éducation scolaire \n \tBesoins pour la formation professionnelle (initiale en particulier)\n \tBesoins pour l’éducation supérieure. \n\tBesoins transversaux en matière d’apprentissages : \n \tBesoins pour les apprentissages élémentaires (apprendre à lire, à écrire, à calculer, acquérir un savoir-faire). \n \tBesoins pour appliquer des connaissances (pour fixer son attention, pour mémoriser, pour lire, pour écrire, pour calculer, pour résoudre des problèmes, respecter les règles sociales de base, s'installer dans la classe, utiliser les supports pédagogiques)\n\tBesoins en lien avec le travail et l’emploi \n \tBesoins pour obtenir une activité professionnelle ou à caractère professionnel\n \tBesoins transversaux en lien avec le travail et l'emploi\nCes besoins transversaux ont été précisés, à la demande des membres du groupe technique national par le recours au volet 6 du GEVA. Il s’agit donc des besoins pour être ponctuel, organiser son travail, accepter des consignes, suivre des consignes, être en contact avec le public, assurer l’encadrement, travailler en équipe, exercer des tâches physiques, autres besoins. \nCE QUE CE N’EST PAS : \nRappel : d’autres prestations de soins, d’autonomie ou de participation sociale peuvent être réalisées pendant un temps consacré à l’enseignement, ou sur le lieu de l’apprentissage.\n\tExemples : \n-\tLes prestations d’interface de communication en classe constituent des prestations visées au « 2.2.1.2 -  Accompagnements pour la communication et les relations avec autrui». \n-\tUne séance de rééducation durant la journée de scolarisation se situe en « 2.1.2.1 - Prestations des auxiliaires médicaux, des instructeurs et avéjistes ».\n-\tL’accompagnement pour les actes essentiels sur un lieu de stage ou de scolarisation se retrouve en « 2.2.1.1 - Accompagnements pour les actes de la vie quotidienne »"
    }]
  },
  {
    "code" : "3.2.4.2",
    "display" : "Transports liés aux prestations de soins, de maintien et de developpement des capacités fonctionnelles",
    "property" : [{
      "code" : "parent",
      "valueCode" : "3.2.4"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 4"
    },
    {
      "code" : "note",
      "valueString" : "Les structures médico-sociales peuvent être amenées à mettre en place des prestations de transports des personnes. Ces prestations sont organisées de manière individuelle ou collective, assurées par la structure ou par le recours à des prestataires financés par la structure. \nLes transports liés au projet individuels ne constituent pas directement une réponse aux besoins d’une personne tels que synthétisés par la nomenclature des besoins : il n’existe pas de « besoin d’être transporté ». Ces transports constituent par contre une condition sine qua non de la réalisation des prestations directes. \nLes transports liés aux prestations de soins, de maintien et de développement des capacités fonctionnelles sont tous les transports des personnes en situation de handicap et des professionnels, nécessaires pour la mise en œuvre des prestations directes de soins, de maintien et de développement des capacités fonctionnelles.\nExemple : La mise en œuvre d’un transport pour une personne devant se rendre à une consultation de soins auprès d’un hôpital relève de cette prestation.  \nCE QUE CE N’EST PAS :\n\tDans la nomenclature des prestations, toutes les prestations directes sont délivrées par principe sur tous les lieux de vie. Le fait qu’un professionnel se déplace pour effectuer une prestation hors les murs de la structure ne constitue pas une prestation mais le mode de réalisation de la prestation. Par conséquent, lorsque le professionnel se déplace pour effectuer une prestation de soins ou d’accompagnement, il ne s’agit pas d’une prestation de transport lié au projet individuel mais d’une prestation directe précise."
    }]
  },
  {
    "code" : "3.2.1.3",
    "display" : "Locaux et autres ressources pour réaliser des prestations de soins, de maintien et de développement des capacités fonctionnelles",
    "property" : [{
      "code" : "parent",
      "valueCode" : "3.2.1"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 4"
    },
    {
      "code" : "note",
      "valueString" : "Cette prestation consiste pour une structure médico-sociale à fournir des locaux et du matériel de soins, ces derniers pouvant être utilisés de jour ou de nuit. \nCette prestation indirecte est le plus souvent la condition sine qua non de la délivrance de prestations directes de soins par une structure médico-sociale."
    }]
  },
  {
    "code" : "2.1.1",
    "display" : "Soins somatiques et psychiques",
    "property" : [{
      "code" : "parent",
      "valueCode" : "2.1"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 3"
    },
    {
      "code" : "note",
      "valueString" : "Les prestations de soins somatiques et psychiques sont réalisées à titre principal par quatre types de professionnels, quel que soit leur statut vis-à-vis de la structure (salariat, prestations de service, honoraires) : \n \tdes professionnels médicaux : médecins toutes spécialités, chirurgiens-dentistes et sages-femmes\n \tdes infirmiers, aides-soignants, auxiliaires de puériculture et aides-médico-psychologiques ; \n \tdes psychologues ; \n \tdes professionnels de la pharmacie : pharmaciens et préparateurs en pharmacie.\nLes soins délivrés par ces professionnels pourront être à visée préventive, curative ou palliative. \nLes soins bucco-dentaires font parties de cette composante.\nBESOINS AUXQUELS CES PRESTATIONS REPONDENT :\nElles répondent aux besoins en matière de santé somatique ou psychique des personnes, identifiés comme des écarts au niveau des différentes fonctions du corps, ainsi que pour entretenir et prendre soin de sa santé. \nRappel : Conformément à la logique de fonctionnement des nomenclatures, la réponse apportée à des besoins en matière de santé pourra être multiple : prestations de soins, de maintien et de développement des capacités fonctionnelles, prestations en matière d’autonomie, et prestations de participation sociale pourront également être mobilisées."
    },
    {
      "code" : "child",
      "valueCode" : "2.1.1.4"
    },
    {
      "code" : "child",
      "valueCode" : "2.1.1.3"
    },
    {
      "code" : "child",
      "valueCode" : "2.1.1.2"
    },
    {
      "code" : "child",
      "valueCode" : "2.1.1.1"
    }]
  },
  {
    "code" : "3.1.6",
    "display" : "Transports liés à gérer, manager, coopérer",
    "property" : [{
      "code" : "parent",
      "valueCode" : "3.1"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 3"
    },
    {
      "code" : "note",
      "valueString" : "Cette prestation correspond à tous les transports mobilisés pour la mise en œuvre des prestations « gérer, manager, coopérer » : \n\tGestion des ressources humaines et du dialogue social\n\tGestion administrative, budgétaire, financière et comptable\n\tInformations et communication\n\tQualité et sécurité\n\tRelations avec le territoire"
    }]
  },
  {
    "code" : "2.3.3",
    "display" : "Accompagnements pour exercer ses rôles sociaux",
    "property" : [{
      "code" : "parent",
      "valueCode" : "2.3"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 3"
    },
    {
      "code" : "note",
      "valueString" : "La notion de rôle social a été choisie pour qualifier les différents statuts sociaux d’une personne. \nToute personne peut choisir de s’inscrire dans une relation familiale ou affective. Elle est, par ailleurs, successivement élève, étudiante, apprentie, en formation professionnelle ou en emploi. Elle peut, indépendamment de ces différents statuts, être accompagnée par structure médico-sociale pour réaliser des activités de jour spécialisées. Elle peut enfin être élue ou soumettre sa candidature à un scrutin électoral, vouloir acquérir des compétences pour aider son entourage, ou encore représenter ses pairs.\nCette composante traite par conséquent des accompagnements réalisés pour exercer ces différents rôles sociaux. Elle se décompose en 6 composantes de niveau 4 : \no\t2.3.3.1 – Accompagnements pour mener sa vie d’élève, d’étudiant ou d’apprenti\no\t2.3.3.2 – Accompagnements pour préparer sa vie professionnelle \no\t2.3.3.3 – Accompagnements pour mener sa vie professionnelle \no\t2.3.3.4 – Accompagnements pour réaliser des activités de jour spécialisées \no\t2.3.3.5 – Accompagnements de la vie familiale, de la parentalité, de la vie affective et sexuelle\no\t2.3.3.6- Accompagnements pour l’exercice de mandats électoraux, la représentation de pairs, la pair-aidance\nCes accompagnements peuvent notamment être réalisées par :\n-\tdes enseignants \n-\tdes professionnels sociaux et éducatifs de l’accompagnement et en particulier: \n \tdes aides médico psychologiques\n \tdes éducateurs et moniteurs : éducateurs spécialisés, éducateurs de jeunes enfants, éducateurs techniques, moniteurs d’atelier, éducateurs scolaires…\nEn outre ces prestations s’inscrivent dans une logique de compensation qui inclut toutes les nuances d’un accompagnement : « apprendre à faire », « faire avec », « faire pour (ou à la place de) ». Elles ont pour objectif le développement, l’acquisition et le maintien du maximum d’autonomie de la personne."
    },
    {
      "code" : "child",
      "valueCode" : "2.3.3.4"
    },
    {
      "code" : "child",
      "valueCode" : "2.3.3.3"
    },
    {
      "code" : "child",
      "valueCode" : "2.3.3.2"
    },
    {
      "code" : "child",
      "valueCode" : "2.3.3.1"
    },
    {
      "code" : "child",
      "valueCode" : "2.3.3.6"
    },
    {
      "code" : "child",
      "valueCode" : "2.3.3.5"
    }]
  },
  {
    "code" : "2.1.2.1",
    "display" : "Prestations des auxiliaires médicaux, des instructeurs en locomotion et avéjistes",
    "property" : [{
      "code" : "parent",
      "valueCode" : "2.1.2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 4"
    },
    {
      "code" : "note",
      "valueString" : "Les prestations de rééducation et de réadaptation fonctionnelle sont réparties en deux catégories de prestations en fonction des professionnels qui les délivrent, à titre principal. Il s’agit ici de décrire les prestations de rééducation et de réadaptation fonctionnelle réalisées par deux types de professionnels quel que soit leur statut vis-à-vis de la structure (salariat, prestations de service, honoraires).\nParmi les professionnels de santé identifiés par le code de la santé publique dans sa quatrième partie, ces prestations sont réalisées, à titre principal, par les auxiliaires médicaux suivants : \no\tmasseur-kinésithérapeute, pédicure-podologue, ergothérapeute, psychomotricien, orthophoniste, orthoptiste, audioprothésiste, prothésiste et orthésiste, diététicien \nCes prestations sont également portées par : \no\tdes professionnels spécialistes de la réadaptation liée aux actes de la vie quotidienne et pour la mobilité des personnes ayant un besoin en lien avec les fonctions visuelles : les instructeurs en locomotion et les AVJistes (ou avéjistes). \nLeurs prestations ont trois dimensions : préventive, curative et palliative. \nBESOINS AUXQUELS CES PRESTATIONS REPONDENT : \nCes prestations répondent à des besoins en matière de santé ou à des besoins en matière d’autonomie. Les prestations se situeront \n \tsur le plan de la rééducation, pour répondre à des besoins en matière de santé. La rééducation vise à rétablir ou maintenir une fonction du corps. \n \tsur celui de la réadaptation pour répondre à des besoins en matière d’autonomie. La réadaptation vise à élaborer les stratégies de contournement permettant à la personne de réaliser les activités et de participer en tenant compte de ses caractéristiques individuelles (les fonctions de son corps).\nBien que ces prestations ne répondent pas directement aux besoins liés à la participation sociale des personnes, leur mise en œuvre dans tous les lieux de vie est de nature à permettre cette participation."
    }]
  },
  {
    "code" : "1.1.10",
    "display" : "Besoins pour entretenir et prendre soin de sa santé",
    "property" : [{
      "code" : "parent",
      "valueCode" : "1.1"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 4"
    },
    {
      "code" : "note",
      "valueString" : "Cette composante porte sur l’accès aux soins courants ou primaires, ou de premier niveau, tels que l’IRDES (Institut de recherche et documentation en économie de la santé), l’OMS (Organisation mondiale de la santé) et le code de la santé publique (issu notamment de la loi Hôpital, patients, santé, territoire) définissent ces notions. \nDESCRIPTION \nBesoins pour assurer ou exprimer des besoins quant à son confort physique, sa santé, son bien-être physique et mental\nBesoins pour prendre soin de soi, en en ayant conscience et en faisant ce qu'il faut pour prendre soin de sa santé et pour prévenir une mauvaise santé\nCODES CIF CORRESPONDANTS (OMS, 2001)\n \td570 Prendre soin de sa santé : assurer son confort physique, son bien-être physique et mental, comme avoir un régime équilibré, avoir un niveau d'activité physique approprié, se tenir au chaud ou au frais, éviter de nuire à sa santé, avoir des rapports sexuels protégés, par exemple en utilisant des préservatifs, en se faisant vacciner, et en subissant des examens physiques réguliers.\n \td5702 Entretenir sa santé : prendre soin de soi en étant conscient de ses besoins et en faisant ce qu'il faut pour prendre soin de sa santé, à la fois pour réagir aux risques pour la santé et pour prévenir une mauvaise santé, par exemple en consultant des professionnels, en suivant l'avis du médecin et des autres professionnels de santé, en évitant les risques pour la santé comme les blessures, les maladies transmissibles, la prise de drogue, et les maladies sexuellement transmissibles.\nCE QUE CE N’EST PAS\nDans la même logique que pour le reste de la nomenclature, les besoins correspondent à un écart (principe d’évaluation de la situation), il ne s’agit donc pas des réponses à mettre en œuvre pour les compenser (principe d’accompagnement)."
    }]
  },
  {
    "code" : "2.1.1.4",
    "display" : "Prestations des pharmaciens et préparateurs en pharmacie",
    "property" : [{
      "code" : "parent",
      "valueCode" : "2.1.1"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 4"
    },
    {
      "code" : "note",
      "valueString" : "Les prestations des pharmaciens et préparateurs en pharmacie sont souvent réalisées par des professionnels au bénéfice d’une structure médico-sociale. \nCette prestation consiste à mettre à la disposition de la structure un approvisionnement en produits pharmaceutiques permettant le traitement médicamenteux des personnes que la structure accompagne. \nCette prestation est par nature personnalisée, chaque traitement répondant à un objectif poursuivi en matière de santé somatique ou psychique.\nBESOINS AUXQUELS LA PRESTATION REPOND :\nElle répond exclusivement aux besoins en matière de santé somatique ou psychique liées aux différentes fonctions du corps des personnes accompagnées : \n \tBesoins en matière de fonctions mentales, psychiques, cognitives et de système nerveux\n \tBesoins en matière de fonctions sensorielles\n \tBesoins en matière de douleur\n \tBesoins relatifs à la voix, à la parole et à l’appareil bucco-dentaire\n \tBesoins en matière de fonctions cardio-vasculaire, hématopoïétique, immunitaire et respiratoire\n \tBesoins en matière de fonctions digestive, métabolique et endocrinienne\n \tBesoins en matière de fonctions génito-urinaires et reproductives\n \tBesoins en matière de fonctions locomotrices\n \tBesoins relatifs à la peau et aux structures associées"
    }]
  },
  {
    "code" : "3.2.3",
    "display" : "Entretenir le linge",
    "property" : [{
      "code" : "parent",
      "valueCode" : "3.2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 3"
    },
    {
      "code" : "note",
      "valueString" : "Parmi les prestations indirectes qu’elle met en œuvre, la structure médico-sociale peut être amenée à effectuer l’entretien de linge : \n\tlinge plat\n\tlinge personnel des résidents\n\tlinge du personnel et des travailleurs d’ESAT\nCette prestation ne constitue pas une réponse à un besoin tel qu’identifié dans le cadre de la nomenclature des besoins, elle est cependant une condition sine qua non de la réalisation de certaines prestations directes et souvent lié à un mode de fonctionnement de la structure. \nLa prestation peut être effectuée par la structure directement ou par le recours à un prestataire, \nCE QUE CE N’EST PAS :\n-\tLe fait d’accompagner une personne pour l’entretien autonome de son ligne (trier son linge, utiliser une machine à laver…) constitue une réponse à des besoins en matière d’accompagnement au logement, il s’agit d’une prestation d’accompagnements pour accomplir les activités domestiques."
    }]
  },
  {
    "code" : "2.4",
    "display" : "Prestation de coordination renforcée pour la cohérence du parcours",
    "property" : [{
      "code" : "parent",
      "valueCode" : "2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 2"
    },
    {
      "code" : "note",
      "valueString" : "La prestation de coordination renforcée pour la cohérence du parcours s’impose ou prend le relai de la coordination usuelle mise en œuvre par les professionnels accompagnant des personnes en situation de handicap, lorsque cette dernière ne constitue plus une réponse suffisante.  \nLes accompagnements sont souvent pluridisciplinaires et s’inscrivent dans un cadre partenarial. C’est pourquoi la coordination est indissociable de la mise en œuvre de chaque prestation. \nEn effet chaque prestation directe présente trois caractéristiques parmi lesquelles deux sont directement liées à la notion de coordination : \n\tLa notion de prestation inclut des éléments qui font partie intégrante de son processus de réalisation. Ces éléments de processus sont des manières de faire et des étapes de réalisation. Il s’agit par exemple de l’entrée/l’admission dans une structure médico-sociale, la sortie de cette structure, l’évaluation, la définition et la coordination du projet personnalisé, la mise en œuvre de la prestation en face à face avec la personne, l’évaluation régulière de la situation, des objectifs, des actions mises en œuvre et des résultats, etc.\nCes différentes actions ne sont pas forcément chronologiques ou successives dans le temps mais peuvent être concomitantes. Dans cet ensemble de ces activités qui font processus, la coordination fait donc partie intégrante de l’accompagnement et de la manière de réaliser chaque prestation. Ce niveau de coordination est parfois dit « usuel » ou « ordinaire ». \n\tLes prestations directes comprennent toutes les interventions répondant aux besoins de la personne y compris en son absence (hors face à face)  sous réserve que cette modalité permette de répondre aux besoins de la personne. \nCompte tenu de ces principes, la nomenclature des prestations n’identifie pas spécifiquement la coordination ordinaire ou usuelle entre professionnels (y compris entre professionnels évoluant dans des structures ou secteurs différents) pour la réalisation d’un projet personnalisé. Cette coordination est intrinsèque à la conduite d’un accompagnement de qualité, elle fait partie du processus de réalisation de chaque prestation et n’a pas à être décrite de manière distincte de la prestation. \nExemples : \n-\tTravailler avec l’enseignant peut constituer une démarche de coordination attendue pour la mise en œuvre de la prestation d’accompagnements pour mener sa vie d’élève, d’étudiant ou d’apprenti. \n-\tL’organisation du travail : les réunions d’équipes, les réunions pluridisciplinaires font également partie du processus de réalisation des prestations pour mener sa vie professionnelle.\nLa nomenclature des prestations distingue : \n\tla coopération avec les acteurs du territoire (conventionner, former des partenaires, échanger des pratiques, participer à des instances administratives) visant à améliorer l’accompagnement global des personnes et l’identifie parmi les prestations indirectes (3.1.5 relations avec le territoire). \n\tune prestation de coordination dite renforcée qui présente un niveau de complexité supérieur à la coordination dite usuelle ou ordinaire mise en œuvre par les professionnels.\nLa distinction entre la coordination usuelle et coordination renforcée pour la cohérence du parcours est en partie dépendante des organisations et de leurs évolutions : une structure identifiera la nécessité d’une coordination renforcée là où une autre structure placerait à un niveau supérieur de complexité la frontière entre les deux niveaux d’intensité de la coordination.   \nLe groupe technique national SERAFIN-PH a identifié deux caractéristiques constitutives de la coordination renforcée pour la cohérence du parcours. Ces caractéristiques se réfèrent à la complexité de la situation d’une part, et de l’accompagnement d’autre part. Elles sont cumulatives. \n1ere caractéristique : la complexité de la situation\n \tLa coordination renforcée peut consister à construire un plan d’accompagnement global (PAG) pour répondre à des situations complexes, du fait du projet de la personne et de l’offre territoriale à mobiliser pour répondre aux besoins de la personne.  \nCe PAG ainsi élaboré peut être temporaire, alternatif ou pérenne. \nLes situations de rupture, les personnes n’ayant pas de solution d’accompagnement, les périodes de transition à venir ou en cours constituent autant de repères de complexité (cf.  Recommandation « Pratiques de coopération et de coordination du parcours de la personne handicapée  » de la Haute Autorité de Santé)\n2eme caractéristique : un accompagnement complexe portant sur plusieurs domaines de prestations et relevant de partenaires nombreux et appartenant à des secteurs différents. \n \tLa coordination renforcée répond à un niveau de complexité supérieur du fait de partenaires concourant à la mise en œuvre du projet plus nombreux et relevant de secteurs différents (social, sanitaire, ’éducation nationale et enseignement supérieur,  formation professionnelletravail, etc.). Le caractère multisectoriel est un critère de complexité dans la mesure où il constitue également un risque de morcellement de l’accompagnement et nécessite donc une concertation rapprochée.\n \tL’accompagnement est en outre caractérisé par un recours à des prestations relevant de différents domaines des prestations (soins, autonomie, participation sociale). \nLa coordination renforcée présente d’autres caractéristiques : \n \tElle vise à mobiliser les ressources du territoire et à permettre la mise en œuvre d’actions parfois innovantes, en réunissant en particulier les directions des structures concernées et les autorités de contrôle et de tarification  pour apporter une réponse à la personne assurant  la cohérence globale de son parcours d’accompagnement. \n \tDans le cadre d’une prestation de coordination renforcée, les acteurs parties prenantes de l’accompagnement (professionnels, aidants, etc.) sont garants :  \no\tde la réalisation d’une analyse croisée et partagée de la situation.. \no\tde la coresponsabilité des différents acteurs dans l’accompagnement de la personne. \n \tUne évaluation multidimensionnelle peut être pilotée par une structure médico-sociale ou tout autre acteur qualifié identifié au moment de la concertation. Une personne référente (coordonnateur de parcours) est ainsi nommée pour être garante de la mise en œuvre des accompagnements décidés dans ce temps de coordination, et qui peut donner lieu à un plan d’accompagnement global (PAG). La personne référente est amenée à retracer les engagements réciproques de chaque acteur. \nDu fait de la complexité à laquelle elle répond, la mise en œuvre d’une prestation de coordination renforcée est nécessairement structurée autour de différentes étapes et s’appuie sur différents outils : \n \tdétermination des objectifs,  formalisation d’un projet personnalisé ou d’un PAG fondé sur une évaluation multidimensionnelle,  \n \tidentification des acteurs ressources des différents champs pour répondre au projet de la personne, \n \tcoordination des interventions effectuées pour assurerla continuité du parcours d’accompagnement de la personne, \n \tévaluation et traçabilité du suivi du parcours  (recensement des actions conduites et desobjectifs à atteindre,  à poursuivre,…). \nCes éléments font partie du processus de la prestation. \nLa coordination renforcée ne constitue pas l’apanage d’un type de dispositif de coordination ou de plateforme, elle est cependant proche de notions préexistantes telles que la « gestion de cas », et de missions réalisées par les dispositifs d’appui à la coordination (convergence des plateformes territoriales d’appui, des « MAIA » et des réseaux de santé territoriaux), pôles de compétences et de prestations externalisées (PCPE) ou des équipes-relais handicap rare. \nElle peut être réalisée par tous les professionnels.  \nBESOINS AUXQUELS LA PRESTATION REPOND : \nCette prestation constitue une exception au principe selon lequel toutes les prestations de soins et d’accompagnement constituent une réponse à un ou plusieurs besoins identifiés dans la nomenclature des besoins. \nElle ne remplace aucune des prestations de la nomenclature des prestations. Elle est de même nature que la coordination usuelle qui relève du processus de réalisation de toute prestation et ne s’en distingue que par son niveau d’intensité, qui garantit la meilleure réponse possible à plusieurs besoins de la personne dans une situation complexe."
    }]
  },
  {
    "code" : "3.1",
    "display" : "Fonctions Gérer, manager, coopérer",
    "property" : [{
      "code" : "parent",
      "valueCode" : "3"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 2"
    },
    {
      "code" : "note",
      "valueString" : "Les fonctions gérer, manager, coopérer regroupent l’ensemble des fonctions réalisées au niveau de la direction d’une structure. Ainsi, il s’agit de l’ensemble des fonctions de gestion réalisées sous la responsabilité de l’organe de direction :\n-\tla gestion des ressources humaines et du dialogue social\n-\tla gestion administrative, budgétaire, financière et comptable\nIl s’agit également d’un ensemble de fonctions rendues nécessaires par l’objet même de l’action médico-sociale :\n-\tla gestion des informations et la communication\n-\tle fait de garantir la qualité et la sécurité dans l’exercice des différentes missions de l’ESMS\n-\tla mise en œuvre des relations avec le territoire\nLes professionnels qui sont amenés à réaliser ces cinq fonctions sont, à titre principal :\n-\tles professionnels cadres hiérarchiques (ayant une délégation de pouvoir -DUP- ou une subdélégation de pouvoir, et/ou assurant des entretiens annuels avec des N-1),\n-\tles cadres fonctionnels non hiérarchiques et techniciens,\n-\tl’ensemble des professionnels administratifs"
    },
    {
      "code" : "child",
      "valueCode" : "3.1.4"
    },
    {
      "code" : "child",
      "valueCode" : "3.1.3"
    },
    {
      "code" : "child",
      "valueCode" : "3.1.2"
    },
    {
      "code" : "child",
      "valueCode" : "3.1.1"
    },
    {
      "code" : "child",
      "valueCode" : "3.1.6"
    },
    {
      "code" : "child",
      "valueCode" : "3.1.5"
    }]
  },
  {
    "code" : "1.3.5",
    "display" : "Besoins en matière de ressources et d'autosuffisance économique",
    "property" : [{
      "code" : "parent",
      "valueCode" : "1.3"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 3"
    },
    {
      "code" : "note",
      "valueString" : "Cette composante traite de la gestion des ressources dans une perspective d’autogestion et d’autosuffisance économique.\nL’autosuffisance économique est l’accès aux ressources, que ce soit des salaires, des revenus de substitution ou des allocations.\nLa gestion des ressources comprend notamment les tâches administratives inhérentes à cette gestion. \nDESCRIPTION : \nBesoins pour accéder à l’autosuffisance économique\nBesoin pour la gestion des ressources\nBesoins pour la réalisation des tâches administratives pour la gestion des ressources\nCODES CIF CORRESPONDANTS (OMS, 2001) :\nLa composante de niveau 4 porte sur une des activités du chapitre 8 (grands domaines de la vie) des activités et participation de la CIF : \n◦\td870 Autosuffisance économique \nAvoir le contrôle de ressources économiques, de sources publiques ou privées, afin d'assurer la sécurité économique pour le temps présent et pour l'avenir\nCE QUE CE N’EST PAS :\nIl ne s’agit pas de la contrepartie à ces ressources. Par exemple le travail, l’emploi, ayant entrainé le versement du salaire est couvert par la composante « 1.3.3.2 – Besoins en lien avec le travail et l’emploi ».\nDans la même logique que pour le reste de la nomenclature, les besoins correspondent à un écart (principe d’évaluation de la situation), il ne s’agit donc pas des réponses à mettre en œuvre pour les compenser (principe d’accompagnement)."
    }]
  },
  {
    "code" : "3.1.5.1",
    "display" : "Coopérations, conventions avec les acteurs spécialisés et du droit commun",
    "property" : [{
      "code" : "parent",
      "valueCode" : "3.1.5"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 4"
    },
    {
      "code" : "note",
      "valueString" : "Cette prestation correspond aux démarches de l’ESMS vers les acteurs spécialisés et de droit commun de son environnement pour développer des coopérations, et conventionner avec les partenaires afin de rendre plus efficientes les prestations de soins et accompagnements, mais aussi les fonctions de pilotage et fonctions support (gérer, manager, coopérer et fonctions logistiques). \nCe sont des « coopérations … pour organiser une réponse coordonnée et de proximité aux besoins de la population dans les différents territoires, dans un objectif de continuité et de décloisonnement des interventions sociales et médico-sociales… » (Article L311-1 du CASF) (°).  \nLes acteurs spécialisés sont les acteurs des secteurs sanitaire, social et médico-social. C’est ainsi que l’on conventionnera avec un service d’urgences, on contractera pour la fourniture des repas par un ESAT d’une autre organisation gestionnaire, on participera à un réseau…\nLes acteurs du droit commun désignent les acteurs pour l’emploi (partenariat avec Cap-Emploi, Pôle emploi), les entreprises, l’école (ex: conventions constitutives d’unités d’enseignement ou conventions de coopération), les espaces sportifs, culturels, de loisirs, les commerces, transports en commun, etc…"
    }]
  },
  {
    "code" : "2",
    "display" : "Prestations directes - Soins et d’accompagnement",
    "property" : [{
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "BLOC"
    },
    {
      "code" : "child",
      "valueCode" : "2.2"
    },
    {
      "code" : "child",
      "valueCode" : "2.3"
    },
    {
      "code" : "child",
      "valueCode" : "2.1"
    },
    {
      "code" : "child",
      "valueCode" : "2.4"
    }]
  },
  {
    "code" : "1.1.3",
    "display" : "Besoins en matière de douleur",
    "property" : [{
      "code" : "parent",
      "valueCode" : "1.1"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 4"
    },
    {
      "code" : "note",
      "valueString" : "Cette composante de niveau 3 traite de la douleur. \nLa CIF classe dans un même chapitre les fonctions sensorielles et la douleur. L’équipe SERAFIN-PH et le groupe technique national ont choisi de distinguer les fonctions sensorielles et la douleur pour qualifier deux besoins différents. \nDESCRIPTION \nBesoins en matière de sensation de douleur\nCODES CIF CORRESPONDANTS (OMS, 2001)\nCette composante de niveau 4 porte uniquement sur une partie du chapitre :\n◦\tb2 - fonctions sensorielles et douleur\no\tDouleurs (b280-b289)\nCE QUE CE N’EST PAS\nDans la CIF les fonctions sensorielles et la douleur font partie d’un même chapitre. Pour la nomenclature SERAFIN-PH, ces fonctions sont scindées en 2, aussi les besoins en matière de fonctions sensorielles font l’objet d’une composante de niveau 4 propre « 1.1.1.2 – Besoins en matière de fonctions sensorielles ».\nIl ne s’agit pas des besoins d’accès aux soins courants couverts par la composante « 1.1.1.10 – Besoins pour entretenir et prendre soin de sa santé ».\nDans la même logique que pour le reste de la nomenclature, les besoins correspondent à un écart (principe d’évaluation de la situation), il ne s’agit donc pas des réponses à mettre en œuvre pour les compenser (principe d’accompagnement)."
    }]
  },
  {
    "code" : "2.3.5.2",
    "display" : "Accompagnements pour l’autonomie de la personne dans la gestion des ressources",
    "property" : [{
      "code" : "parent",
      "valueCode" : "2.3.5"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 4"
    },
    {
      "code" : "note",
      "valueString" : "Cette prestation recouvre les accompagnements réalisés pour favoriser l’autonomie des personnes dans la gestion de leurs ressources quelle que soit la nature de celles-ci. \nIl s’agit : \n\tDe la délivrance d’informations et de conseils en matière d’économie (valeur de l’argent, gestion d’un budget, consommation).\n\tDe la cogestion avec la personne de ses ressources, d’un budget (par exemple à l’occasion de ses achats ou de perspectives d’achats)\n\tDe l’interface avec les représentants légaux des personnes accompagnées,  le cas échéant leurs mandataires judiciaires à la protection des majeurs et délégués aux prestations familiales.\nCette prestation est notamment réalisée par des professionnels sociaux et éducatifs de l’accompagnement, parmi lesquels: \n \tdes aides médico-psychologiques\n \tdes éducateurs et moniteurs : éducateurs spécialisés, éducateurs de jeunes enfants, éducateurs techniques, moniteurs d’atelier, éducateurs scolaires, etc.\n \tdes assistants de service social et conseillers en économie sociale et familiale\nCes prestations s’inscrivent également dans une logique de compensation qui inclut toutes les nuances d’un accompagnement : « apprendre à faire », « faire avec », « faire pour (ou à la place de) ». Elles ont pour objectif le développement, l’acquisition et le maintien du maximum d’autonomie de la personne dans la gestion de ses ressources. \nBESOINS AUXQUELS LA PRESTATION REPOND : \n\tBesoins en matière de ressources et d’autosuffisance économique \nCE QUE CE N’EST PAS : \n\tIl ne s’agit pas d’accompagner la personne à effectuer des achats dans un but précis : cela peut relever, selon la situation, d’un accompagnement pour vivre dans un logement (achat de fournitures par exemple, 2.3.2.1) ou d’un accompagnement pour accomplir les activités domestiques (2.3.2.2).\n\tIl ne s’agit pas de l’exercice du rôle de mandataire judiciaire ou de délégué aux prestations identifié en 2.3.5.3 - Informations, conseils et mise en œuvre des mesures de protection des adultes."
    }]
  },
  {
    "code" : "1.3.2.1",
    "display" : "Besoins pour vivre dans un logement",
    "property" : [{
      "code" : "parent",
      "valueCode" : "1.3.2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+01:00"
    },
    {
      "code" : "type",
      "valueString" : "Niveau 4"
    },
    {
      "code" : "note",
      "valueString" : "Cette composante de niveau 4 traite de la vie dans un logement ou dans un lieu d’hébergement.\nLe logement ou l’hébergement est entendu comme individuel ou collectif. Il peut s’agir des besoins en lien avec la vie dans un logement individuel (en location, en sous-location, en co-location, en tant que propriétaire…), dans un logement adapté, accompagné ou toute forme de logement intermédiaire, ou dans un établissement, qu’il s’agisse d’un hébergement collectif, semi-collectif, individuel.\nDESCRIPTION : \nBesoins pour avoir un lieu d'hébergement.\nIl s’agit des besoins pour acquérir un logement, pour le conserver, pour le meubler. Cela recouvre donc par exemple le fait de rechercher un logement adapté à sa situation, faire des visites.\nBesoin pour vivre seul dans un logement.\nIl s’agit des besoins en lien avec le fait d’habiter un logement : le maintenir en l’état ou l’améliorer. \nCODES CIF CORRESPONDANTS (OMS, 2001) :\nLa composante de niveau 4 porte notamment sur les activités/participation sociale de l’activité suivante du chapitre 6 de la CIF : \n◦\td610 Acquérir un endroit pour vivre\nCE QUE CE N’EST PAS :\nCette composante ne couvre pas les activités domestiques ou les tâches ménagères (préparer les repas, faire le ménage, etc…) qui sont complémentaires au besoin pour vivre dans un logement tels que décrit ci-dessus. Ces activités et besoins relève de la composante 1.3.2.2 « Besoins pour accomplir les activités domestiques ».\nDans la même logique que pour le reste de la nomenclature, les besoins correspondent à un écart (principe d’évaluation de la situation), il ne s’agit donc pas des réponses à mettre en œuvre pour les compenser (principe d’accompagnement)."
    }]
  }]
}

```
