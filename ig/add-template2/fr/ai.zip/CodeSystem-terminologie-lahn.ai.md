# Liste des Actes Inovants Hors Nomenclature - Terminologies de Santé v1.10.0

## CodeSystem: Liste des Actes Inovants Hors Nomenclature 

 
La liste des actes innovants hors nomenclature (LAHN) a été mise en place par la direction générale de l’offre de soins (DGOS) en 2024, dans le cadre du développement de l’innovation en santé. Elle est la fusion du RIHN et de la Liste Complémentaire (LC). L’objectif est de soutenir l’innovation et de la dynamiser par une prise en charge et une évaluation rapide des actes innovants. La LAHN contient une liste d’actes innovants (biologie et anatomocytopathologie) pris en charge à titre transitoire moyennant un recueil de données pour leur évaluation. 

Ce système de codes est référencé dans la définition des ensembles de valeurs suivants :

* Cette terminologie de référence (CodeSystem) n'est pas utilisée ici; elle peut être utilisée ailleurs (par exemple spécifications et/ou implémentations qui utilisent ce contenu)

-------

 [Description du (des) tableau(x) ci-dessus](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "terminologie-lahn",
  "meta" : {
    "versionId" : "5",
    "lastUpdated" : "2026-02-04T16:07:18.237+01:00",
    "profile" : ["http://hl7.org/fhir/StructureDefinition/shareablecodesystem"]
  },
  "url" : "https://smt.esante.gouv.fr/terminologie-lahn",
  "identifier" : [{
    "use" : "usual",
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:oid:1.2.250.1.213.2.79"
  },
  {
    "use" : "secondary",
    "system" : "https://smt.esante.gouv.fr/",
    "value" : "terminologie-lahn"
  }],
  "version" : "2026 v1.0",
  "name" : "LAHN",
  "title" : "Liste des Actes Inovants Hors Nomenclature",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-06-02T14:00:56+00:00",
  "publisher" : "Agence du numérique en santé",
  "description" : "La liste des actes innovants hors nomenclature (LAHN) a été mise en place par la direction générale de l’offre de soins (DGOS) en 2024, dans le cadre du développement de l’innovation en santé. Elle est la fusion du RIHN et de la Liste Complémentaire (LC). L’objectif est de soutenir l’innovation et de la dynamiser par une prise en charge et une évaluation rapide des actes innovants. La LAHN contient une liste d’actes innovants (biologie et anatomocytopathologie) pris en charge à titre transitoire moyennant un recueil de données pour leur évaluation.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "FR",
      "display" : "France (la)"
    }]
  }],
  "copyright" : "[LOv2](https://github.com/etalab/licence-ouverte/blob/master/LO.md)",
  "valueSet" : "https://smt.esante.gouv.fr/terminologie-lahn?vs",
  "content" : "complete",
  "count" : 767,
  "filter" : [{
    "code" : "root",
    "operator" : ["="],
    "value" : "True or false."
  },
  {
    "code" : "deprecated",
    "operator" : ["="],
    "value" : "True or false."
  },
  {
    "code" : "imported",
    "operator" : ["="],
    "value" : "True or false"
  }],
  "property" : [{
    "code" : "created",
    "uri" : "http://purl.org/dc/terms/created",
    "type" : "dateTime"
  },
  {
    "code" : "modified",
    "uri" : "http://purl.org/dc/terms/modified",
    "type" : "dateTime"
  },
  {
    "code" : "type",
    "uri" : "http://purl.org/dc/elements/1.1/type",
    "description" : "Type fonctionnel d'un concept",
    "type" : "string"
  },
  {
    "code" : "note",
    "uri" : "http://www.w3.org/2004/02/skos/core#note",
    "type" : "string"
  },
  {
    "code" : "prixMaximal",
    "uri" : "http://www.data.esante.gouv.fr/DGOS/LAHN/prixMaximal",
    "type" : "decimal"
  },
  {
    "code" : "deprecated",
    "uri" : "http://www.w3.org/2002/07/owl#deprecated",
    "type" : "boolean"
  },
  {
    "code" : "parent",
    "uri" : "http://hl7.org/fhir/concept-properties#parent",
    "description" : "Codes des parents du concept courant",
    "type" : "code"
  },
  {
    "code" : "child",
    "uri" : "http://hl7.org/fhir/concept-properties#child",
    "description" : "Codes des enfants du concept courant",
    "type" : "code"
  },
  {
    "code" : "imported",
    "description" : "Indicates if the concept is imported from another code system.",
    "type" : "boolean"
  },
  {
    "code" : "root",
    "description" : "Indicates if this concept is a root concept (i.e. Thing is equivalent or a direct parent).",
    "type" : "boolean"
  }],
  "concept" : [{
    "code" : "K202",
    "display" : "Alpha 2 macroglobuline (alpha 2 macroglo) (dosage)  (liquides biologiques autres que sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "En attente d'une modification potentielle du libellé de l'acte NABM [1805] prenant en compte les autres liquides biologiques que le sang."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 10.8
    }]
  },
  {
    "code" : "G195",
    "display" : "Test d'activation des basophiles par cytométrie en flux",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Par dilution d'un d'allergène testé. Examen utile dans le cas ou la recherche d'IgE spécifiques n'est pas contributive. Standardisation nationale des modalités opératoires en cours. Acte à encadrer pour le contrôle de la prescription et des étapes analytiques et post-analytique"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 27.0
    }]
  },
  {
    "code" : "G062",
    "display" : "Dosage de mica soluble",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 18.9
    }]
  },
  {
    "code" : "K117",
    "display" : "Facteur chimioattractant MCP-1",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-05"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2022-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 32.4
    }]
  },
  {
    "code" : "P058",
    "display" : "Etude par immuno-empreinte d'une ou plusieurs protéines (liquides biologiques)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "16-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Indication: protéine(s) déjà connue(s) pour être en lien avec la pathologie héréditaire recherchée."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 162.0
    }]
  },
  {
    "code" : "C017",
    "display" : "Conservation annuelle de tissu germinaux (ovaire et testicule prépubère)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "03"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2020-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation par an et par patient(e). Remplace Cryoconservation de tissu germinaux (ovaire et testicule prépubère)"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 67.5
    }]
  },
  {
    "code" : "I047",
    "display" : "Métanéphrines plasmatiques libres (LC/MS/MS)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "09"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Spécialisé"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 35.1
    }]
  },
  {
    "code" : "J003",
    "display" : "Phosphatases alcalines (liquides biologiques autres que le sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "10-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "En attente d'une modification potentielle du libellé de l'acte NABM [0514] prenant en compte les autres liquides biologiques que le sang."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 5.4
    }]
  },
  {
    "code" : "N518",
    "display" : "Transcrit de fusion, fibrosarcome infantile (1 transcrit)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-3-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Identification d'anomalies spécifiques dans les sarcomes"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 162.0
    }]
  },
  {
    "code" : "N409",
    "display" : "Identification d’anomalies structurelles des syndromes lymphoprolifératifs et lymphomes non hodgkiniens par locus (forfait 2 à 5 anomalies de structure (gènes de fusion)) (par ex BCL1-IgH ou BCL2-IgH  (forfaitisé avec les SLP et LNH)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-3-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2019-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Fusion des actes [N409], [N410] et [N413]"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 124.2
    }]
  },
  {
    "code" : "J027",
    "display" : "Catalase tissulaire",
    "property" : [{
      "code" : "parent",
      "valueCode" : "10-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2022-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 40.5
    }]
  },
  {
    "code" : "K116",
    "display" : "Isoprostanes",
    "property" : [{
      "code" : "parent",
      "valueCode" : "10-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2022-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 40.5
    }]
  },
  {
    "code" : "G085",
    "display" : "Test d’exploration fonctionnelle de l’apoptose des lymphocytes T",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-04"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Mesure de l'apoptose par annexine v (par couple annexine v + Ac ou IP) sur culture de lymphocytes T activés"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 540.0
    }]
  },
  {
    "code" : "P057",
    "display" : "Analyse quantitative et qualitative des glycosaminoglycanes (liquides biologiques)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "16-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Inclut la quantification des glycosaminoglycanes totaux et analyse qualitative des 4 espèces majoritaires des mucopolysaccharides"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 135.0
    }]
  },
  {
    "code" : "G194",
    "display" : "Herpesviridae (HSV, CMV, VZV) : Charge immunitaire",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-07"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 29.7
    }]
  },
  {
    "code" : "I048",
    "display" : "Progestérone (liquides biologiques autres que le sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "09"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "En attente d'une modification potentielle du libellé de l'acte NABM [0334] prenant en compte les autres liquides biologiques que le sang."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 16.2
    }]
  },
  {
    "code" : "I024",
    "display" : "CBG ( Cortisol Binding Protein) (sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "09"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Spécialisé"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 37.8
    }]
  },
  {
    "code" : "L229",
    "display" : "Activité de la Protéine de Transfert des Esters de Cholestérol (CETP)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "10-04"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 81.0
    }]
  },
  {
    "code" : "N519",
    "display" : "Amplification MDM2/CDK4",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-3-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Identification d'anomalies spécifiques dans les sarcomes"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 162.0
    }]
  },
  {
    "code" : "J004",
    "display" : "Phosphatases acides (liquides biologiques)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "10-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 18.9
    }]
  },
  {
    "code" : "C100",
    "display" : "Suivi continu des embryons \"système time-lapse\"",
    "property" : [{
      "code" : "parent",
      "valueCode" : "03"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 243.0
    }]
  },
  {
    "code" : "J028",
    "display" : "Cholinestérase ou pseudocholinesterases",
    "property" : [{
      "code" : "parent",
      "valueCode" : "10-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 13.5
    }]
  },
  {
    "code" : "K119",
    "display" : "Mélanine (recherche)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2022-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 18.9
    }]
  },
  {
    "code" : "P056",
    "display" : "Profil des oligosaccharides (liquides biologiques)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "16-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Par technique séparative"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 135.0
    }]
  },
  {
    "code" : "I049",
    "display" : "17OH Progestérone (liquides biologiques autres que le sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "09"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "En attente d'une modification potentielle du libellé de l'acte NABM [1135] prenant en compte les autres liquides biologiques que le sang."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 24.3
    }]
  },
  {
    "code" : "I025",
    "display" : "FSH (liquide biologique autres que le sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "09"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "En attente d'une modification potentielle du libellé de l'acte NABM [0473] prenant en compte les autres liquides biologiques que le sang."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 37.8
    }]
  },
  {
    "code" : "I001",
    "display" : "HCG ou béta HCG (recherche ou dosage dans un liquide biologique autre que le sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "09"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2025-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "En attente de la fusion potentielle des actes NABM [7401] et [7402] et d'une modification potentielle du libellé de l'acte résultant prenant en compte les autres liquides biologiques que le sang."
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 35.1
    }]
  },
  {
    "code" : "N516",
    "display" : "Transcrit de fusion, tumeur desmoplastique à cellules rondes (1 transcrit)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-3-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Identification d'anomalies spécifiques dans les sarcomes"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 162.0
    }]
  },
  {
    "code" : "N407",
    "display" : "Recherche ou quantification du transcrit de fusion BCR-ABL1 par RT-PCR",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-3-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2022-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 110.7
    }]
  },
  {
    "code" : "J029",
    "display" : "Cholinestérases érythrocytaires",
    "property" : [{
      "code" : "parent",
      "valueCode" : "10-03"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2022-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 27.0
    }]
  },
  {
    "code" : "A033",
    "display" : "Examen cytopathologique ou histopathologiques en  microscopie électronique",
    "property" : [{
      "code" : "parent",
      "valueCode" : "01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Fusion des actes [A030], [A031], [A032], [A033]."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 89.6
    }]
  },
  {
    "code" : "K203",
    "display" : "Cathepsine  et Visfatine",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 37.8
    }]
  },
  {
    "code" : "P055",
    "display" : "Neurotransmetteurs (LCR)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "16-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 135.0
    }]
  },
  {
    "code" : "I026",
    "display" : "LH (liquide biologique autres que le sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "09"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "En attente d'une modification potentielle du libellé de l'acte NABM [0472] prenant en compte les autres liquides biologiques que le sang."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 37.8
    }]
  },
  {
    "code" : "N408",
    "display" : "Recherche et/ou quantification au diagnotic par locus",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-3-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Hors BCR-ABL [1035 de la NABM]. Par exemple :  CCND1, EVI1, TLX1/3, CRLF, DEK-CAN, STAT3, FLT3…"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 113.4
    }]
  },
  {
    "code" : "L207",
    "display" : "Activité bilirubine UDP glucuronosyltransférase sur tissu hépatique",
    "property" : [{
      "code" : "parent",
      "valueCode" : "10-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2022-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 108.0
    }]
  },
  {
    "code" : "N517",
    "display" : "Transcrit de fusion, sarcome fibromyxoide de bas grade",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-3-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Identification d'anomalies spécifiques dans les sarcomes"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 162.0
    }]
  },
  {
    "code" : "J006",
    "display" : "Alanine aminotransférase (ALAT, TGP) (liquides biologiques autres que le sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "10-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2022-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "En attente d'une modification potentielle du libellé de l'acte NABM [0516] prenant en compte les autres liquides biologiques que le sang."
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 5.4
    }]
  },
  {
    "code" : "G191",
    "display" : "Dosage des IgG anti-antigène capsulaire du pneumocoque (sérologie pneumococcique) (réponse vaccinale)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-05"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 27.0
    }]
  },
  {
    "code" : "E107",
    "display" : "Prothrombine résiduelle du sérum",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation. Examen simple de dépistage d'une anomalie des phospholipides plaquettaires (syndrome de Scott)"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 6.75
    }]
  },
  {
    "code" : "I003",
    "display" : "Hormone Anti-Mullërienne (AMH)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "09"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2022-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Très prescrit"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 37.8
    }]
  },
  {
    "code" : "N934",
    "display" : "Test de résistance aux antiviraux par séquençage des gènes porteurs de mutations de résistance [<3000 bases]",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-2-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Inclus : contrôle pré-analyse, extraction, quelle que soit la méthode, amplification du gène (partiel ou complet) par PCR simple ou nichée, contrôle rapide de PCR sur gel d'agarose, réaction de séquence, analyse des données, interprétation et rendu des résultats. Une cotation par séquence"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 270.0
    }]
  },
  {
    "code" : "C012",
    "display" : "IMSI (choix des spermatozoïdes à injecter dans l'ovocyte suite à leur observation à très fort grossissement)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "03"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Observation longue car cette technique est indiquée en cas de spermatozoïdes présentant un très fort pourcentage d'anomalies morphologiques. Permet la sélection à fort grossissement (X 6000) des spermatozoïdes sans anomalies morphologiques à injecter dans l'ovocyte. Une seule cotation qui s'ajoute à l'acte NABM ICSI [0061]."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 256.5
    }]
  },
  {
    "code" : "G081",
    "display" : "PN : Expression des molécules d'adhérence CD11b, CD18, CD62L",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-04"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Par molécule. Acte devant être encadré pour sa prescription et les étapes pré et post analytiques"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 27.0
    }]
  },
  {
    "code" : "G190",
    "display" : "Dosage des IgG anti-haemophilus (réponse vaccinale)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-05"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 27.0
    }]
  },
  {
    "code" : "E108",
    "display" : "Résistance à la Protéine C activée (RPCa)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Intérêt de dépister en cas de pathologie acquise un risque thrombotique"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 16.2
    }]
  },
  {
    "code" : "N935",
    "display" : "Test de résistance aux antiviraux par séquençage des gènes porteurs de mutations de résistance [>3000 bases]",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-2-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Inclus : contrôle pré-analyse, extraction, quelle que soit la méthode, amplification du gène (partiel ou complet) par PCR simple ou nichée, contrôle rapide de PCR sur gel d'agarose, réaction de séquence, analyse des données, interprétation et rendu des résultats. Une cotation par séquence"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 405.0
    }]
  },
  {
    "code" : "C011",
    "display" : "Prélèvement de globules polaires ou blastomères en vue de diagnostic préconceptionnel (DPC) ou de diagnostic préimplantatoire (DPI)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "03"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 783.0
    }]
  },
  {
    "code" : "J008",
    "display" : "Aspartate aminotransférase (ASAT, TGO) (liquides biologiques autres que le sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "10-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "En attente d'une modification potentielle du libellé de l'acte NABM [0517] prenant en compte les autres liquides biologiques que le sang."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 5.4
    }]
  },
  {
    "code" : "D100",
    "display" : "Etude de la qualité du noyau du spermatozoïde",
    "property" : [{
      "code" : "parent",
      "valueCode" : "04"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 121.5
    }]
  },
  {
    "code" : "L094",
    "display" : "Clairance au vert d'indocyanine",
    "property" : [{
      "code" : "parent",
      "valueCode" : "12"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Réserve hépatique ou évaluation post-opératoire"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 40.5
    }]
  },
  {
    "code" : "B034",
    "display" : "Hybridation sur puce à ADN (sans les vérifications)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 550.0
    }]
  },
  {
    "code" : "P059",
    "display" : "Exploration par BN-PAGE de la chaine respiratoire mitochondriale (tout tissus)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "16-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 270.0
    }]
  },
  {
    "code" : "I006",
    "display" : "IGFBP 1 (Iinsulin-like growth factor binding protein 1) (sécrétions vaginales)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "09"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Spécialisé"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 27.0
    }]
  },
  {
    "code" : "E106",
    "display" : "Protéine S, recherche d'un auto-Ac",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation. Utilité diagnostique démontrée en biologie médicale. Impact sur la prise en charge thérapeutique"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 37.8
    }]
  },
  {
    "code" : "C013",
    "display" : "Test pré-IMSI",
    "property" : [{
      "code" : "parent",
      "valueCode" : "03"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Ce test correspond à évaluer la possibilité de trouver des spermatozoïdes\" utilisables\" pour une IMSI ultérieure"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 108.0
    }]
  },
  {
    "code" : "11",
    "display" : "Protéines - Marqueurs tumoraux - Vitamines",
    "property" : [{
      "code" : "parent",
      "valueCode" : "LAHN"
    },
    {
      "code" : "type",
      "valueString" : "Chapitre"
    },
    {
      "code" : "child",
      "valueCode" : "11-01"
    },
    {
      "code" : "child",
      "valueCode" : "11-06"
    },
    {
      "code" : "child",
      "valueCode" : "11-07"
    },
    {
      "code" : "child",
      "valueCode" : "11-02"
    },
    {
      "code" : "child",
      "valueCode" : "11-04"
    },
    {
      "code" : "child",
      "valueCode" : "11-03"
    },
    {
      "code" : "child",
      "valueCode" : "11-05"
    }]
  },
  {
    "code" : "I087",
    "display" : "Résistine",
    "property" : [{
      "code" : "parent",
      "valueCode" : "09"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 37.8
    }]
  },
  {
    "code" : "K157",
    "display" : "IgD (dosage en nephelemetrie) (sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-04"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "[K157] et [K158] : même mesure mais méthodes différentes. Dosage également en turbidimétrie ; interprétation biologique nécessitant une expertise, à associer avec exploration de la mévalonate kinase"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 10.8
    }]
  },
  {
    "code" : "M009",
    "display" : "Métal ou autre élément : dosage par spectrométrie d'émission atomique avec ionisation par plasma induit (icp-oes)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "13-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une cotation par métal ou autre élément dosé"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 32.4
    }]
  },
  {
    "code" : "K048",
    "display" : "RBP (retinol binding protein) (dosage) (liquides biologiquesautres que le sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "En attente d'une modification potentielle du libellé de l'acte NABM [1818] prenant en compte les autres liquides biologiques que le sang."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 16.2
    }]
  },
  {
    "code" : "M118",
    "display" : "Génotypage du cytochrome P450 2D6 dans le cadre d’une prescription d’eluglistat ou de tamoxifène",
    "property" : [{
      "code" : "parent",
      "valueCode" : "13-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 78.3
    }]
  },
  {
    "code" : "G240",
    "display" : "sérodiagnostic de staphylocoque par cytométrie en flux",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-05"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation. Détection des infections ostéo-articulaires"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 62.1
    }]
  },
  {
    "code" : "10-04",
    "display" : "Enzymologie lipidique",
    "property" : [{
      "code" : "parent",
      "valueCode" : "10"
    },
    {
      "code" : "type",
      "valueString" : "Sous-chapitre"
    },
    {
      "code" : "child",
      "valueCode" : "L229"
    },
    {
      "code" : "child",
      "valueCode" : "J016"
    },
    {
      "code" : "child",
      "valueCode" : "J085"
    },
    {
      "code" : "child",
      "valueCode" : "J052"
    }]
  },
  {
    "code" : "G155",
    "display" : "Auto-Ac anti-NMO (neuro-myélite optique) (par IFI)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 54.0
    }]
  },
  {
    "code" : "G022",
    "display" : "Ac anti-cytoplasme : identification des anti-ARNt-synthétases et autres anti-Ag cytoplasmiques (autres que JO1)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 18.9
    }]
  },
  {
    "code" : "G131",
    "display" : "Herpes 8 IgG ELISA",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-07"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 18.9
    }]
  },
  {
    "code" : "G179",
    "display" : "Etude du chimérisme (sur sang total ou moelle)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-03"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "A réaliser au sein de laboratoires accrédités par l'European Federation for Imunogenetics (EFI)"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 135.0
    }]
  },
  {
    "code" : "L137",
    "display" : "Acide lactique (liquides biologiques autres que sang, ponction)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "12"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Fusion des actes [L137], [L142] et [L183]. En attente d'une modification potentielle du libellé de l'acte NABM [0530] prenant en compte les autres liquides biologiques que le sang."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 8.1
    }]
  },
  {
    "code" : "F041",
    "display" : "Culture Trichomonas",
    "property" : [{
      "code" : "parent",
      "valueCode" : "06-05"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "La culture des prélèvements augmente la sensibilité du diagnostic"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 40.5
    }]
  },
  {
    "code" : "N534",
    "display" : "Mutation IDH1/2",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-3-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Prise en charge des gliomes"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 116.1
    }]
  },
  {
    "code" : "L028",
    "display" : "Acides gras libres T0 à T16 (sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "12"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 5.4
    }]
  },
  {
    "code" : "N510",
    "display" : "Transcrit de fusion, chondrosarcome myxoïde (3 transcrits)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-3-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Identification d'anomalies spécifiques dans les sarcomes"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 297.0
    }]
  },
  {
    "code" : "10-03",
    "display" : "Enzymologie érythrocytaire",
    "property" : [{
      "code" : "parent",
      "valueCode" : "10"
    },
    {
      "code" : "type",
      "valueString" : "Sous-chapitre"
    },
    {
      "code" : "child",
      "valueCode" : "J044"
    },
    {
      "code" : "child",
      "valueCode" : "L046"
    },
    {
      "code" : "child",
      "valueCode" : "J064"
    },
    {
      "code" : "child",
      "valueCode" : "L045"
    },
    {
      "code" : "child",
      "valueCode" : "J091"
    },
    {
      "code" : "child",
      "valueCode" : "J026"
    },
    {
      "code" : "child",
      "valueCode" : "J103"
    },
    {
      "code" : "child",
      "valueCode" : "J097"
    },
    {
      "code" : "child",
      "valueCode" : "J029"
    }]
  },
  {
    "code" : "L113",
    "display" : "Urée (liquides biologiques autres que le sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "12"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Fusion des actes [L113] et [L181]. En attente d'une modification potentielle du libellé de l'acte NABM [0591] prenant en compte les autres liquides biologiques que le sang."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 2.7
    }]
  },
  {
    "code" : "J043",
    "display" : "Glutathion péroxydase",
    "property" : [{
      "code" : "parent",
      "valueCode" : "10-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 27.0
    }]
  },
  {
    "code" : "P050",
    "display" : "Chromatographie des acides aminés (liquides biologiques)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "16-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Au moins les 22 acides aminés nutritionnels"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 135.0
    }]
  },
  {
    "code" : "I088",
    "display" : "Peptide YY (PYY, Peptide Tyrosine Tyrosine, Pancreatic Peptide YY)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "09"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 37.8
    }]
  },
  {
    "code" : "K047",
    "display" : "IgM (liquides biologiques autres que le sang, ponctions)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-04"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "En attente d'une modification potentielle du libellé de l'acte NABM [1816] prenant en compte les autres liquides biologiques que le sang."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 10.8
    }]
  },
  {
    "code" : "M119",
    "display" : "Dosage de l’activité de la dihydropyridine deshydrogenase par une méthode chromatographique pour ajustement d’un traitement par fluoropyrimidines (ex : 5-fluorouracile)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "13-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2020-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 40.5
    }]
  },
  {
    "code" : "G154",
    "display" : "Auto-Ac anti-21-hydroxylase (par RIA)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 54.0
    }]
  },
  {
    "code" : "K156",
    "display" : "Dépistage des déficits d'interaction du facteur H aux surfaces",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2025-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Examen de 1ère  intention dans certaines pathologies (MAT) ; réalisation technique et interprétation biologique nécessitant une expertise"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 27.0
    }]
  },
  {
    "code" : "N317",
    "display" : "Mise au point d'une PCR quantitative à façon pour vérification d'une anomalie détectée en microarray",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-3-1"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "(comprend le design des oligonucléotides, la commande et l'analyse en PCRq des parents et du propositus)"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 378.0
    }]
  },
  {
    "code" : "L027",
    "display" : "Acide gras à très longue chaine (liquides biologiques)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "16-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "De C22 à C26 minimum"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 135.0
    }]
  },
  {
    "code" : "E086",
    "display" : "Fragment 1.2 de la prothrombine",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation. Marqueur d'activation de la coagulation (activation de la prothrombine)"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 37.8
    }]
  },
  {
    "code" : "N535",
    "display" : "Mutation BRAF (hors mutation V600)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-3-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Dans la prise en charge du CBNPC, l'acte n'est pas à coder au RIHN, car il doit être intégré dans le panel."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 116.1
    }]
  },
  {
    "code" : "N511",
    "display" : "Transcrit de fusion, rhabdomyosarcome (2 transcrits)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-3-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Identification d'anomalies spécifiques dans les sarcomes"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 229.5
    }]
  },
  {
    "code" : "L003",
    "display" : "Cuivre (liquide biologique autres que sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "12"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Fusion des actes [L003] et [L130] en attente d'une modification potentielle du libellé de l'acte NABM [0547] prenant en compte les autres liquides biologiques que le sang."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 27.0
    }]
  },
  {
    "code" : "J020",
    "display" : "Acétylcholinestérase",
    "property" : [{
      "code" : "parent",
      "valueCode" : "10-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 13.5
    }]
  },
  {
    "code" : "10",
    "display" : "Enzymologie",
    "property" : [{
      "code" : "parent",
      "valueCode" : "LAHN"
    },
    {
      "code" : "type",
      "valueString" : "Chapitre"
    },
    {
      "code" : "child",
      "valueCode" : "10-02"
    },
    {
      "code" : "child",
      "valueCode" : "10-01"
    },
    {
      "code" : "child",
      "valueCode" : "10-03"
    },
    {
      "code" : "child",
      "valueCode" : "10-04"
    },
    {
      "code" : "child",
      "valueCode" : "J083"
    }]
  },
  {
    "code" : "J044",
    "display" : "Glutathion réductase érythrocytaire",
    "property" : [{
      "code" : "parent",
      "valueCode" : "10-03"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 27.0
    }]
  },
  {
    "code" : "K159",
    "display" : "Ferritine (liquides biologiques autres que sang, ponctions)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2022-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "En attente d'une modification potentielle du libellé de l'acte NABM [1213] prenant en compte les autres liquides biologiques que le sang."
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 12.15
    }]
  },
  {
    "code" : "13",
    "display" : "Médicaments - Toxiques",
    "property" : [{
      "code" : "parent",
      "valueCode" : "LAHN"
    },
    {
      "code" : "type",
      "valueString" : "Chapitre"
    },
    {
      "code" : "child",
      "valueCode" : "13-02"
    },
    {
      "code" : "child",
      "valueCode" : "13-01"
    }]
  },
  {
    "code" : "K026",
    "display" : "C3 nephritic factor (Ac anti C3 convertase alterne) par technique néphélométrique",
    "designation" : [{
      "language" : "fr",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009",
        "display" : "Synonym"
      },
      "value" : "C3 nephritic factor (Ac anti C3 convertase alterne) par technique hémolytique"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "En attente d'inscription à la NABM."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 81.0
    }]
  },
  {
    "code" : "K135",
    "display" : "Immunoblot anti-C1 inhibiteur",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2025-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Examen de seconde intention dans le cadre d'un déficit fonctionnel de C1 inhibiteur ; encadrement de la prescription et nécessité d'une expertise technique"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 135.0
    }]
  },
  {
    "code" : "I041",
    "display" : "GHRH (sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "09"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Spécialisé"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 54.0
    }]
  },
  {
    "code" : "M007",
    "display" : "Métaux et autres éléments : dosage multiélémentaire par spectrométrie de masse avec ionisation par plasma induit (icp-ms)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "13-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Avec plafonnement à 5 éléments par prélèvement"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 32.4
    }]
  },
  {
    "code" : "M116",
    "display" : "Screening toxicologique  comprenant au moins 200 molécules par une méthode de chromatographie avec identification de l'ensemble des molécules",
    "property" : [{
      "code" : "parent",
      "valueCode" : "13-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Non cumulable avec acte [M117]"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 81.0
    }]
  },
  {
    "code" : "G068",
    "display" : "PN : étude de l'amorçage de l'explosion oxydative",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-04"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 108.0
    }]
  },
  {
    "code" : "G044",
    "display" : "Ac anti-Ag onco-neuronaux",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 81.0
    }]
  },
  {
    "code" : "G153",
    "display" : "Auto-Ac anti-récepteur sensible au calcium (par immunotransfert)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 54.0
    }]
  },
  {
    "code" : "K111",
    "display" : "Ac récepteur de la TSH bloquant",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 81.0
    }]
  },
  {
    "code" : "I089",
    "display" : "Ghréline (sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "09"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 37.8
    }]
  },
  {
    "code" : "F063",
    "display" : "Identification de Légionella par agglutination",
    "property" : [{
      "code" : "parent",
      "valueCode" : "06-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "En attente de l'intégration potentielle au sein de l'acte NABM [5292] de l'identification de Légionella par agglutination"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 16.2
    }]
  },
  {
    "code" : "L139",
    "display" : "Protéine Tau et ses isoformes (phosphorylation (phospho-Tau), exon-spécifique, clivage..) en dosage individuel (tout liquide biologique)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "12"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Quelle que soit la technique (ELISA, spectrométrie de masse…) par dosage d'un isoforme"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 54.0
    }]
  },
  {
    "code" : "N314",
    "display" : "Forfait Tests fonctionnels ex vivo imposant de recourir à la mutagénèse dirigée ou à un clonage en minigène",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-3-1"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Ce forfait concerne la confirmation du caractère délétère d'une mutation identifiée par l'analyse de l'ADN génomique lorsque le gène s'exprime dans un tissu non accessible."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 810.0
    }]
  },
  {
    "code" : "N532",
    "display" : "Méthylation MGMT",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-3-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Marqueur prédictif dans les glioblastomes"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 137.7
    }]
  },
  {
    "code" : "J045",
    "display" : "Glutathion S transférase (GST) alpha",
    "property" : [{
      "code" : "parent",
      "valueCode" : "10-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2022-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 27.0
    }]
  },
  {
    "code" : "K049",
    "display" : "Transferrine ou sidérophylline (liquides biologiques autres que le sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "En attente d'une modification potentielle du libellé de l'acte NABM [1819] prenant en compte les autres liquides biologiques que le sang."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 10.8
    }]
  },
  {
    "code" : "12",
    "display" : "Biochimie",
    "property" : [{
      "code" : "parent",
      "valueCode" : "LAHN"
    },
    {
      "code" : "type",
      "valueString" : "Chapitre"
    },
    {
      "code" : "child",
      "valueCode" : "L188"
    },
    {
      "code" : "child",
      "valueCode" : "L124"
    },
    {
      "code" : "child",
      "valueCode" : "L170"
    },
    {
      "code" : "child",
      "valueCode" : "L137"
    },
    {
      "code" : "child",
      "valueCode" : "L049"
    },
    {
      "code" : "child",
      "valueCode" : "L017"
    },
    {
      "code" : "child",
      "valueCode" : "L100"
    },
    {
      "code" : "child",
      "valueCode" : "L044"
    },
    {
      "code" : "child",
      "valueCode" : "L177"
    },
    {
      "code" : "child",
      "valueCode" : "L113"
    },
    {
      "code" : "child",
      "valueCode" : "L172"
    },
    {
      "code" : "child",
      "valueCode" : "L140"
    },
    {
      "code" : "child",
      "valueCode" : "L084"
    },
    {
      "code" : "child",
      "valueCode" : "L139"
    },
    {
      "code" : "child",
      "valueCode" : "L107"
    },
    {
      "code" : "child",
      "valueCode" : "L121"
    },
    {
      "code" : "child",
      "valueCode" : "L001"
    },
    {
      "code" : "child",
      "valueCode" : "L235"
    },
    {
      "code" : "child",
      "valueCode" : "L147"
    },
    {
      "code" : "child",
      "valueCode" : "L161"
    },
    {
      "code" : "child",
      "valueCode" : "L059"
    },
    {
      "code" : "child",
      "valueCode" : "L041"
    },
    {
      "code" : "child",
      "valueCode" : "L128"
    },
    {
      "code" : "child",
      "valueCode" : "L110"
    },
    {
      "code" : "child",
      "valueCode" : "L008"
    },
    {
      "code" : "child",
      "valueCode" : "L054"
    },
    {
      "code" : "child",
      "valueCode" : "L022"
    },
    {
      "code" : "child",
      "valueCode" : "L187"
    },
    {
      "code" : "child",
      "valueCode" : "L109"
    },
    {
      "code" : "child",
      "valueCode" : "L003"
    },
    {
      "code" : "child",
      "valueCode" : "L094"
    },
    {
      "code" : "child",
      "valueCode" : "L043"
    },
    {
      "code" : "child",
      "valueCode" : "L218"
    },
    {
      "code" : "child",
      "valueCode" : "L011"
    },
    {
      "code" : "child",
      "valueCode" : "L176"
    },
    {
      "code" : "child",
      "valueCode" : "L125"
    },
    {
      "code" : "child",
      "valueCode" : "L083"
    },
    {
      "code" : "child",
      "valueCode" : "L178"
    },
    {
      "code" : "child",
      "valueCode" : "L072"
    },
    {
      "code" : "child",
      "valueCode" : "L173"
    },
    {
      "code" : "child",
      "valueCode" : "L085"
    },
    {
      "code" : "child",
      "valueCode" : "L053"
    },
    {
      "code" : "child",
      "valueCode" : "L021"
    },
    {
      "code" : "child",
      "valueCode" : "L034"
    },
    {
      "code" : "child",
      "valueCode" : "L002"
    },
    {
      "code" : "child",
      "valueCode" : "L135"
    },
    {
      "code" : "child",
      "valueCode" : "L236"
    },
    {
      "code" : "child",
      "valueCode" : "L028"
    },
    {
      "code" : "child",
      "valueCode" : "L217"
    },
    {
      "code" : "child",
      "valueCode" : "L010"
    },
    {
      "code" : "child",
      "valueCode" : "L111"
    },
    {
      "code" : "child",
      "valueCode" : "L087"
    },
    {
      "code" : "child",
      "valueCode" : "L009"
    },
    {
      "code" : "child",
      "valueCode" : "L020"
    },
    {
      "code" : "child",
      "valueCode" : "L097"
    },
    {
      "code" : "child",
      "valueCode" : "L099"
    },
    {
      "code" : "child",
      "valueCode" : "L029"
    },
    {
      "code" : "child",
      "valueCode" : "L190"
    },
    {
      "code" : "child",
      "valueCode" : "L064"
    },
    {
      "code" : "child",
      "valueCode" : "L133"
    },
    {
      "code" : "child",
      "valueCode" : "L146"
    }]
  },
  {
    "code" : "I042",
    "display" : "Biotine B8 (sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-06"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 54.0
    }]
  },
  {
    "code" : "K025",
    "display" : "AP50 ou AH50 par réaction d’hémolyse",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "En attente d'inscription à la NABM"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 10.8
    }]
  },
  {
    "code" : "K158",
    "display" : "IgD (dosage en ELISA) (sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-04"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "[K157] et [K158] : même mesure mais méthodes différentes. Dosage également en turbidimétrie ; interprétation biologique nécessitant une expertise, à associer avec exploration de la mévalonate kinase"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 18.9
    }]
  },
  {
    "code" : "M117",
    "display" : "Screening toxicologique  comprenant au moins 200 molécules par au moins 2 méthodes de chromatographie complémentaires avec identification de l'ensemble des molécules",
    "property" : [{
      "code" : "parent",
      "valueCode" : "13-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Non cumulable avec acte [M116]"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 135.0
    }]
  },
  {
    "code" : "G152",
    "display" : "Auto-Ac anti-ZnT8 en radioligand assay",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 81.0
    }]
  },
  {
    "code" : "M008",
    "display" : "Métal ou autre élément : dosage isolé par spectrométrie de masse avec ionisation par plasma induit (icp-ms)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "13-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 81.0
    }]
  },
  {
    "code" : "G067",
    "display" : "PN : mouvement spontané et chimiotactisme des PN",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-04"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Acte devant être encadré pour sa prescription et les étapes pré et post analytiques"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 256.5
    }]
  },
  {
    "code" : "G043",
    "display" : "M. de l'intestin : recherche des Ac anti-saccharomyces cerevisiae (ASCA) d'isotype IgG par ELISA",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 18.9
    }]
  },
  {
    "code" : "G176",
    "display" : "Typage d'un locus HLA de classe I ou de classe II en biologie moléculaire, résolution haute",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-03"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Fusion des actes [G176] et [G177]. A réaliser selon standards EFI"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 189.0
    }]
  },
  {
    "code" : "K110",
    "display" : "Ac récepteur de la TSH stimulant",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 81.0
    }]
  },
  {
    "code" : "J046",
    "display" : "Glutathion S transférase pi",
    "property" : [{
      "code" : "parent",
      "valueCode" : "10-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2022-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 27.0
    }]
  },
  {
    "code" : "L114",
    "display" : "Protéines totales (liquides biologiques hors sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "En attente d'une modification potentielle du libellé de l'acte NABM [2258] prenant en compte les autres liquides biologiques que le sang."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 2.7
    }]
  },
  {
    "code" : "N315",
    "display" : "Forfait Test fonctionnels  ex vivo à partir de matériel issu du patient (ARN ou protéine)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-3-1"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Ce forfait concerne la confirmation du caractère délétère d'une mutation identifiée par analyse de l'ADN génomique en étudiant les ARN ou les protéines du patient."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 135.0
    }]
  },
  {
    "code" : "L138",
    "display" : "TRAP (Total Peroxyl Radical Tracking Antioxydant) (sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "10-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 27.0
    }]
  },
  {
    "code" : "L029",
    "display" : "Acides gras non estérifiés",
    "property" : [{
      "code" : "parent",
      "valueCode" : "12"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2019-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 18.9
    }]
  },
  {
    "code" : "E084",
    "display" : "Facteur XIII, Ag",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation. A réaliser seulement si acte [0173]] diminué. A réserver à centre de référence ou centre expert."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 37.8
    }]
  },
  {
    "code" : "N400",
    "display" : "Recherche de clonalité B par locus",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-3-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Fusion des actes [N400], [N401], [N402] et [N403]"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 207.9
    }]
  },
  {
    "code" : "N533",
    "display" : "Méthylation MLH-1",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-3-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Indique le caractère sporadique de cancers avec instabilité des microsatellites"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 137.7
    }]
  },
  {
    "code" : "K137",
    "display" : "Mannan Binding Lectin (MBL) (dosage fonctionnel)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2025-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Examen de 2nde ou 3ième intention ; nécessité d'une expertise technique"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 54.0
    }]
  },
  {
    "code" : "K113",
    "display" : "Ac anti-T3 (Sérum)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 40.5
    }]
  },
  {
    "code" : "G042",
    "display" : "M. de l'intestin : recherche des Ac anti-saccharomyces cerevisiae (ASCA) d'isotype IgA par ELISA",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 18.9
    }]
  },
  {
    "code" : "G151",
    "display" : "Auto-Ac anti-IA2 en radioligand assay",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 81.0
    }]
  },
  {
    "code" : "15",
    "display" : "Diagnostic prénatal",
    "property" : [{
      "code" : "parent",
      "valueCode" : "LAHN"
    },
    {
      "code" : "type",
      "valueString" : "Chapitre"
    }]
  },
  {
    "code" : "G199",
    "display" : "Ac anti-Annexine V IgG",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 18.9
    }]
  },
  {
    "code" : "L008",
    "display" : "Iode (sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "12"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Pas d'EEQ. Technique actuelle ICPMS .Intérêt dans interventions thyroïde."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 24.3
    }]
  },
  {
    "code" : "N514",
    "display" : "Transcrit de fusion, sarcome à cellules claires (2 transcrits)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-3-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Identification d'anomalies spécifiques dans les sarcomes"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 229.5
    }]
  },
  {
    "code" : "A120",
    "display" : "Enzymologie sur coupe > 3 enzymes",
    "property" : [{
      "code" : "parent",
      "valueCode" : "01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une cotation par lame"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 56.0
    }]
  },
  {
    "code" : "P054",
    "display" : "Points redox",
    "property" : [{
      "code" : "parent",
      "valueCode" : "16-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Comprenant les acides lactiques, pyruvique, 3-hydroxy-butirique et acéto-acétique"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 32.4
    }]
  },
  {
    "code" : "E081",
    "display" : "Facteur VIII, Ag",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation. Recommandations du CRMH, en cours de rédaction, préconiseront le dosage antigènique en complément de la caractérisation phénotypique basée sur les mesures d’activité, afin de reconnaître les hémophiles CRM."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 37.8
    }]
  },
  {
    "code" : "14",
    "display" : "Tests d'amplification génique et d'hybridation moléculaire (diagnostic prénatal exclu)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "LAHN"
    },
    {
      "code" : "type",
      "valueString" : "Chapitre"
    },
    {
      "code" : "child",
      "valueCode" : "14-2"
    },
    {
      "code" : "child",
      "valueCode" : "14-1"
    },
    {
      "code" : "child",
      "valueCode" : "14-3"
    }]
  },
  {
    "code" : "K003",
    "display" : "Protéines membranaires érythrocytaires (électrophorèses)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 27.0
    }]
  },
  {
    "code" : "G041",
    "display" : "Ac antirécepteur insuline",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 18.9
    }]
  },
  {
    "code" : "G174",
    "display" : "Typage d'un locus HLA de classe I ou de classe II en biologie moléculaire, résolution basse ou intermédiaire",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-03"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Fusion des actes [G174] et [G175]. A réaliser selon standards EFI"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 67.5
    }]
  },
  {
    "code" : "B100",
    "display" : "Dépistage non invasif des anomalies chromosomiques par analyse de l'ADN fœtal circulant",
    "property" : [{
      "code" : "parent",
      "valueCode" : "02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Indications : hors indications des actes 4084, 4085, 4086, 4087 et 4088 de la NABM et selon les recommandations de la HAS"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 362.88
    }]
  },
  {
    "code" : "A122",
    "display" : "Analyse protéomique basée sur la  spectrométrie de masse en tandem après microdissection laser",
    "property" : [{
      "code" : "parent",
      "valueCode" : "01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2020-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Typage des amyloses"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 200.0
    }]
  },
  {
    "code" : "G150",
    "display" : "Auto-Ac anti-GAD en radioligand assay",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 81.0
    }]
  },
  {
    "code" : "G089",
    "display" : "Test de prolifération en thymidine tritiée sur PBMC",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-04"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Pour une stimulation. 10 stimulations maximum. Acte devant être encadré pour sa prescription et les étapes pré et post analytiques"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 64.8
    }]
  },
  {
    "code" : "G065",
    "display" : "Marquage cellulaire quelqu'il soit en cytométrie en flux (par Ac)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-04"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Cotation totale maximale limitée à 24 Ac, y compris CD3, CD4, CD8 et CD45. Ne pas comptabiliser les contrôles isotypiques et les Ac de fenêtrage inclus dans le code NABM [1122]. Acte devant être encadré pour sa prescription et les étapes pré et post analytiques"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 27.0
    }]
  },
  {
    "code" : "G198",
    "display" : "MAI nso : Ac anti phospholipides (autres que ceux codifiés en 1460 et G023 et G024) IgG et IgM",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Par isotype"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 18.9
    }]
  },
  {
    "code" : "N515",
    "display" : "Transcrit de fusion (RET/PTC1, RET/PTC3)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-3-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Identification d'anomalies spécifiques dans les sarcomes"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 229.5
    }]
  },
  {
    "code" : "F062",
    "display" : "Mycobactéries : identification par immunochromatographie",
    "property" : [{
      "code" : "parent",
      "valueCode" : "06-03"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 27.0
    }]
  },
  {
    "code" : "A121",
    "display" : "Autopsie adulte (> 15 ans et 3 mois) : moelle épinière",
    "property" : [{
      "code" : "parent",
      "valueCode" : "01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Examen macroscopique et histologique après bloc paraffine de la moelle épinière"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 33.6
    }]
  },
  {
    "code" : "B101",
    "display" : "Clonage des points de cassures par séquençage haut débit",
    "property" : [{
      "code" : "parent",
      "valueCode" : "02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Hors exome et génome entier, pour séquence < 500 kb"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 270.0
    }]
  },
  {
    "code" : "E082",
    "display" : "Facteur XI, Ag",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation. Permet une caractérisation complète du diagnostic de déficit en facteur XI"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 37.8
    }]
  },
  {
    "code" : "P053",
    "display" : "Chromatographie des porphyrines (liquides biologiques)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "16-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Profil de 6 porphyrines minimum"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 135.0
    }]
  },
  {
    "code" : "K115",
    "display" : "Ac anti-TSH (Sérum)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 40.5
    }]
  },
  {
    "code" : "17",
    "display" : "Microbiologie médicale par pathologie",
    "property" : [{
      "code" : "parent",
      "valueCode" : "LAHN"
    },
    {
      "code" : "type",
      "valueString" : "Chapitre"
    }]
  },
  {
    "code" : "K139",
    "display" : "Activité de la Carboxypeptidase N",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-03"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Analyse ultra spécialisée"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 135.0
    }]
  },
  {
    "code" : "G040",
    "display" : "Auto-Ac anti-transglutaminase IgG en radioligand assay",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 81.0
    }]
  },
  {
    "code" : "G088",
    "display" : "Test de cytotoxicité: pour le test de base",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-04"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Par cible. Acte devant être encadré pour sa prescription et les étapes pré et post analytiques"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 270.0
    }]
  },
  {
    "code" : "N318",
    "display" : "Recherche de réarrangements génomiques ciblés  par  Multiplex Ligation-dependent Probe Amplification (MLPA).",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-3"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Concerne un nombre limité de maladies héréditaires pour lesquelles la recherche de réarragements récurrents reste nécessaire au diagnostic (ex: Amyotrophie spinale). Permet également l'évaluation des gains ou pertes alleliques dans les leucémies ou lymphomes."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 234.9
    }]
  },
  {
    "code" : "N536",
    "display" : "Réarrangement du gène ROS-1",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-3-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Dans la prise en charge du CBNPC, l'acte n'est pas à coder au RIHN, car il doit être intégré dans le panel, sauf en cas d'urgence, où une approche monogénique est à privilégier (source HAS)"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 110.7
    }]
  },
  {
    "code" : "N512",
    "display" : "Transcrit de fusion, liposarcome myxoide (3 transcrits)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-3-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Identification d'anomalies spécifiques dans les sarcomes"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 297.0
    }]
  },
  {
    "code" : "P052",
    "display" : "Profil des acylcarnitines (liquides biologiques)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "16-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "De C2 à C18 minimum"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 135.0
    }]
  },
  {
    "code" : "I022",
    "display" : "Adiponectine",
    "property" : [{
      "code" : "parent",
      "valueCode" : "09"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 37.8
    }]
  },
  {
    "code" : "K138",
    "display" : "Activité de l'Aminopeptidase P",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-03"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Analyse ultra spécialisée. Dosage sur cinétique longue, substrat FRET Fluorescence (ou Förster Resonance Energy Transfert) permet d'étudier des interactions entre deux molécules, les évènements de proximité dans les système biologique."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 135.0
    }]
  },
  {
    "code" : "K114",
    "display" : "Ac anti-T4 (Sérum)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 40.5
    }]
  },
  {
    "code" : "G063",
    "display" : "Evaluation du contenu en myélopéroxydase des Polynucléaires Neutrophiles (PN)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-04"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 54.0
    }]
  },
  {
    "code" : "16",
    "display" : "Diagnostic biologique des maladies héréditaire",
    "property" : [{
      "code" : "parent",
      "valueCode" : "LAHN"
    },
    {
      "code" : "type",
      "valueString" : "Chapitre"
    },
    {
      "code" : "child",
      "valueCode" : "16-01"
    },
    {
      "code" : "child",
      "valueCode" : "16-02"
    }]
  },
  {
    "code" : "I046",
    "display" : "Glucagon-like-peptide 1 (GLP-1)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "09"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 40.5
    }]
  },
  {
    "code" : "J002",
    "display" : "Phosphatases alcalines isoenzymes (électrophorèse) (sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "10-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Spécialisé"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 54.0
    }]
  },
  {
    "code" : "L009",
    "display" : "Manganèse (liquides biologiques)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "12"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Fusion des actes [L009] et [L078]. Intérêt dans certaines neuropathies."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 27.0
    }]
  },
  {
    "code" : "J026",
    "display" : "Catalase érythrocytaire",
    "property" : [{
      "code" : "parent",
      "valueCode" : "10-03"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 40.5
    }]
  },
  {
    "code" : "N404",
    "display" : "Recherche de clonalité T par locus",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-3-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Fusion des actes [N404], [N405] et [N406]"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 207.9
    }]
  },
  {
    "code" : "N537",
    "display" : "Signature d'expression génique dans le cancer du sein",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-3-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Indications : selon les indications de la HAS\nEn attente de réévaluation."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 1849.5
    }]
  },
  {
    "code" : "N513",
    "display" : "Transcrit de fusion, synovialosarcome (2 transcrits)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-3-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Identification d'anomalies spécifiques dans les sarcomes"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 229.5
    }]
  },
  {
    "code" : "P051",
    "display" : "Chromatographie des acides organiques (liquides biologiques)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "16-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 135.0
    }]
  },
  {
    "code" : "07",
    "display" : "Immunologie",
    "property" : [{
      "code" : "parent",
      "valueCode" : "LAHN"
    },
    {
      "code" : "type",
      "valueString" : "Chapitre"
    },
    {
      "code" : "child",
      "valueCode" : "07-02"
    },
    {
      "code" : "child",
      "valueCode" : "07-04"
    },
    {
      "code" : "child",
      "valueCode" : "07-07"
    },
    {
      "code" : "child",
      "valueCode" : "07-03"
    },
    {
      "code" : "child",
      "valueCode" : "07-06"
    },
    {
      "code" : "child",
      "valueCode" : "07-05"
    },
    {
      "code" : "child",
      "valueCode" : "07-01"
    }]
  },
  {
    "code" : "G200",
    "display" : "Ac anti-fibrillarine",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-04"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 18.9
    }]
  },
  {
    "code" : "K185",
    "display" : "Ostéoprotégérine sérique",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 35.1
    }]
  },
  {
    "code" : "M013",
    "display" : "Autre médicament ou toxique : dosage par électrochimie (électrodes spécifiques)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "13-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une cotation par médicament ou toxique dosé"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 32.4
    }]
  },
  {
    "code" : "K161",
    "display" : "Ac anti-Thyroglobuline (liquide de ponction)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "En attente d'une modification potentielle du libellé de l'acte NABM [1484] prenant en compte les autres liquides biologiques que le sang."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 40.5
    }]
  },
  {
    "code" : "G115",
    "display" : "Toxoplasmose: Recherche d'autres marqueurs de toxoplasmose évolutive pour datation et évaluation du risque  si sérologie de dépistage évoquant une infection évolutive: IgM",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-06"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2020-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Examen réservé à des laboratoires agréés ou spécialisés. ISAGA ou 2ème ELISA. Valeur des IgA et IgM pour différencier une toxoplasmose évolutive d'une séquelle sérologique (selon les recommandations du CNR de la toxoplasmose):"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 8.1
    }]
  },
  {
    "code" : "G224",
    "display" : "Typage d'un locus HLA de classe I ou de classe II en biologie moléculaire, résolution allélique",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-03"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Selon standards EFI"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 378.0
    }]
  },
  {
    "code" : "V008",
    "display" : "PCR classique ou temps réel quantitative multiplex pour < 10 couples d'amorces (ADN/ARN)  - Indications évaluées par la HAS",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2025-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Indications évaluées par la HAS permettant une exemption à la décote."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 170.1
    }]
  },
  {
    "code" : "E154",
    "display" : "Activité anti thrombine ou anti Xa des médicaments (hors héparine ou dérivés)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une cotation par nouveau antithrombotique. Dosage + courbe pour nouveaux antithrombotiques. test indispensable permettant d'évaluer la concentration du médicament afin d'évaluer le risque hémorragique pour les AOD et la zone thérapeutique pour les anti-thrombines administrés par voie IV"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 16.2
    }]
  },
  {
    "code" : "E130",
    "display" : "Propeptide facteur Willebrand",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation. Voir recommandations du Centre de référence Maladie de Willebrand : examen de 2nde intention pour la caractérisation d'une VWD"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 37.8
    }]
  },
  {
    "code" : "I091",
    "display" : "Hormone de croissance (somatotropine) (GH) (liquides biologiques autres que sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "09"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Spécialisé. En attente d'une modification potentielle du libellé de l'acte NABM [7423] prenant en compte les autres liquides biologiques que le sang."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 48.6
    }]
  },
  {
    "code" : "L056",
    "display" : "Diènes conjugués (sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "10-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2022-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 21.6
    }]
  },
  {
    "code" : "N453",
    "display" : "Forfait séquençage haut débit (NGS) > 20 kb et < 100 kb",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-3-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Selon indications fixées par l'INCa et la DGOS\nLorsqu'il s'agit d'un acte qui concerne un test de détection des mutations génétiques [Test compagnon], l'acte n'est pas à coder au RAHN car il est inscrit à la CCAM et à la NABM :\nhttps://www.legifrance.gouv.fr/download/pdf?id=e1zu17CprDOqj9lE78rLBxw7vDZFNnoUYrgSjWmeUG4="
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 1503.9
    }]
  },
  {
    "code" : "F025",
    "display" : "Ag soluble Pneumocoque par Test immunochromatographique",
    "property" : [{
      "code" : "parent",
      "valueCode" : "06-03"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 27.0
    }]
  },
  {
    "code" : "06",
    "display" : "Microbiologie",
    "property" : [{
      "code" : "parent",
      "valueCode" : "LAHN"
    },
    {
      "code" : "type",
      "valueString" : "Chapitre"
    },
    {
      "code" : "child",
      "valueCode" : "06-05"
    },
    {
      "code" : "child",
      "valueCode" : "06-03"
    },
    {
      "code" : "child",
      "valueCode" : "06-01"
    },
    {
      "code" : "child",
      "valueCode" : "06-02"
    },
    {
      "code" : "child",
      "valueCode" : "06-04"
    },
    {
      "code" : "child",
      "valueCode" : "06-06"
    }]
  },
  {
    "code" : "K184",
    "display" : "Collagène de type IV",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Marqueur de fibrose hépatique"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 35.1
    }]
  },
  {
    "code" : "K160",
    "display" : "Des-gamma-carboxy prothrombine (DCP) ou PIVKA",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 37.8
    }]
  },
  {
    "code" : "K051",
    "display" : "Dosages sériques des chaines légères libres kappa et lambda (sérum)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-04"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Fusion des ancien code [K051] et [K052]. Examen de 1ere intention dans certaines indications pour le dosage sérique. Réalisation technique et interprétation biologique nécessitant une expertise"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 40.5
    }]
  },
  {
    "code" : "K099",
    "display" : "Ferritine glycosylée",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 54.0
    }]
  },
  {
    "code" : "G114",
    "display" : "Toxoplasmose: Recherche d'autres marqueurs de toxoplasmose évolutive pour datation et évaluation du risque si sérologie de dépistage évoquant une infection\névolutive: IgG",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-06"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2020-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Examen réservé à des laboratoires agréés ou spécialisés. IFI ou 2ème ELISA ou TS dilué. 2ème technique nécessaire en cas de résultats 1ère\ntechnique limite ou non quantifiable ou si discordance entre les 2 premières techniques IgG. Importance de confirmer la spécificité des faible taux d'IgG dans toute suspiscion de toxoplasmose évolutive"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 8.1
    }]
  },
  {
    "code" : "V007",
    "display" : "PCR classique ou temps réel qualitative multiplex pour < 10 couples d'amorces (ADN/ARN) - Indications évaluées par la HAS",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2025-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Indications évaluées par la HAS permettant une exemption à la décote."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 135.0
    }]
  },
  {
    "code" : "G139",
    "display" : "AC neutralisant anti IFN-bêta",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-04"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 40.5
    }]
  },
  {
    "code" : "E046",
    "display" : "Willebrand, fixation au collagène (liaison VWF-collagène)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation. Voir recommandations du Centre de référence Maladie de Willebrand : examen de 2nde intention pour la caractérisation d'une VWD"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 67.5
    }]
  },
  {
    "code" : "E155",
    "display" : "Typage d’un variant de l’hémoglobine (étude phénotypique) hormis isofloculation et citrate agar",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation. Combinaison de 7 techniques alternatives : électrophorèse sur acétate de cellulose pH9, urée pH9, urée pH6, urée/triton, HPLC sur birad® Variant I, HPLC sur gel de silice en phase normale et phase inverse, électrophorèse capillaire de chaine dénaturante et  électrophorèse capillaire non dénaturante."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 97.2
    }]
  },
  {
    "code" : "E131",
    "display" : "Willebrand : liaison VWF-GPIb",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation. Voir recommandations du Centre de référence Maladie de Willebrand : examen de 2nde intention pour la caractérisation d'une VWD"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 48.6
    }]
  },
  {
    "code" : "L055",
    "display" : "Statut antioxydant total (TAS) (sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "10-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 27.0
    }]
  },
  {
    "code" : "L188",
    "display" : "Acide urique (liquides biologiques autres que sang, ponctions)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "12"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Fusion des actes [L188] et [L193]. En attente d'une modification potentielle du libellé de l'acte NABM [0532] prenant en compte les autres liquides biologiques que le sang."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 2.7
    }]
  },
  {
    "code" : "N454",
    "display" : "Forfait séquençage haut débit (NGS) > 100 kb et < 500 kb",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-3-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Selon indications fixées par l'INCa et la DGOS\nLorsqu'il s'agit d'un acte qui concerne un test de détection des mutations génétiques [Test compagnon], l'acte n'est pas à coder au RAHN car il est inscrit à la CCAM et à la NABM :\nhttps://www.legifrance.gouv.fr/download/pdf?id=e1zu17CprDOqj9lE78rLBxw7vDZFNnoUYrgSjWmeUG4="
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 2205.9
    }]
  },
  {
    "code" : "L140",
    "display" : "Peptide Amyloïde béta et ses isoformes (1-42, 1-40, 1-38, tronqué, PyroGlu, précurseur...) en dosage individuel (tout liquide biologique)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "12"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Quelle que soit la technique (ELISA, spectrométrie de masse…) par dosage d'un isoforme"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 54.0
    }]
  },
  {
    "code" : "11-02",
    "display" : "Complément (exploration du complément et marqueurs associés)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11"
    },
    {
      "code" : "type",
      "valueString" : "Sous-chapitre"
    },
    {
      "code" : "child",
      "valueCode" : "K032"
    },
    {
      "code" : "child",
      "valueCode" : "K197"
    },
    {
      "code" : "child",
      "valueCode" : "K026"
    },
    {
      "code" : "child",
      "valueCode" : "K034"
    },
    {
      "code" : "child",
      "valueCode" : "K199"
    },
    {
      "code" : "child",
      "valueCode" : "K135"
    },
    {
      "code" : "child",
      "valueCode" : "K194"
    },
    {
      "code" : "child",
      "valueCode" : "K156"
    },
    {
      "code" : "child",
      "valueCode" : "K036"
    },
    {
      "code" : "child",
      "valueCode" : "K137"
    },
    {
      "code" : "child",
      "valueCode" : "K196"
    },
    {
      "code" : "child",
      "valueCode" : "K044"
    },
    {
      "code" : "child",
      "valueCode" : "K025"
    },
    {
      "code" : "child",
      "valueCode" : "K038"
    },
    {
      "code" : "child",
      "valueCode" : "K033"
    },
    {
      "code" : "child",
      "valueCode" : "K198"
    },
    {
      "code" : "child",
      "valueCode" : "K035"
    }]
  },
  {
    "code" : "I093",
    "display" : "Insulin-like Growth Factor-II (IGF-II) ou  Somatomédine A haut poids moléculaire (par western-blot)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "09"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 48.6
    }]
  },
  {
    "code" : "09",
    "display" : "Hormonologie",
    "property" : [{
      "code" : "parent",
      "valueCode" : "LAHN"
    },
    {
      "code" : "type",
      "valueString" : "Chapitre"
    },
    {
      "code" : "child",
      "valueCode" : "I048"
    },
    {
      "code" : "child",
      "valueCode" : "I094"
    },
    {
      "code" : "child",
      "valueCode" : "I088"
    },
    {
      "code" : "child",
      "valueCode" : "I056"
    },
    {
      "code" : "child",
      "valueCode" : "I024"
    },
    {
      "code" : "child",
      "valueCode" : "I083"
    },
    {
      "code" : "child",
      "valueCode" : "I051"
    },
    {
      "code" : "child",
      "valueCode" : "I101"
    },
    {
      "code" : "child",
      "valueCode" : "I091"
    },
    {
      "code" : "child",
      "valueCode" : "I058"
    },
    {
      "code" : "child",
      "valueCode" : "I026"
    },
    {
      "code" : "child",
      "valueCode" : "I039"
    },
    {
      "code" : "child",
      "valueCode" : "I034"
    },
    {
      "code" : "child",
      "valueCode" : "K015"
    },
    {
      "code" : "child",
      "valueCode" : "I079"
    },
    {
      "code" : "child",
      "valueCode" : "I047"
    },
    {
      "code" : "child",
      "valueCode" : "I093"
    },
    {
      "code" : "child",
      "valueCode" : "I061"
    },
    {
      "code" : "child",
      "valueCode" : "I010"
    },
    {
      "code" : "child",
      "valueCode" : "I087"
    },
    {
      "code" : "child",
      "valueCode" : "I050"
    },
    {
      "code" : "child",
      "valueCode" : "I049"
    },
    {
      "code" : "child",
      "valueCode" : "I017"
    },
    {
      "code" : "child",
      "valueCode" : "I100"
    },
    {
      "code" : "child",
      "valueCode" : "I089"
    },
    {
      "code" : "child",
      "valueCode" : "I025"
    },
    {
      "code" : "child",
      "valueCode" : "I084"
    },
    {
      "code" : "child",
      "valueCode" : "I006"
    },
    {
      "code" : "child",
      "valueCode" : "I052"
    },
    {
      "code" : "child",
      "valueCode" : "I001"
    },
    {
      "code" : "child",
      "valueCode" : "I102"
    },
    {
      "code" : "child",
      "valueCode" : "I046"
    },
    {
      "code" : "child",
      "valueCode" : "I060"
    },
    {
      "code" : "child",
      "valueCode" : "I041"
    },
    {
      "code" : "child",
      "valueCode" : "I054"
    },
    {
      "code" : "child",
      "valueCode" : "I022"
    },
    {
      "code" : "child",
      "valueCode" : "I003"
    }]
  },
  {
    "code" : "K163",
    "display" : "Polyamines (spermine, spermidine, putrescine)\npar polyamine",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2022-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 16.2
    }]
  },
  {
    "code" : "G028",
    "display" : "Ac anti- titine",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 81.0
    }]
  },
  {
    "code" : "M120",
    "display" : "Dosage d’un anti-inflammatoire par une méthode chromatographique dans un liquide biologique",
    "property" : [{
      "code" : "parent",
      "valueCode" : "13-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 32.4
    }]
  },
  {
    "code" : "K054",
    "display" : "Dosage d'une cytokine ou d'un récepteur de cytokines par ELISA\n(toute cytokine, tout récepteur)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-05"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Même mesure , méthode analytique différente dont le choix dépend de la nature de l'échantilon, le nombre de tests d'un série. Un grand nombre de cytokines peuvent être dosées dans des situations cliniques très variées. Les données analytiques et l'efficacité et l'utilité cliniques sont très variables selon les cytokines et le contexte clinique. Quelques indications précises sont identifiées (IL-10 dans le LCR ou l'humeur vitrée pour le diagnostic de lymphome, IL-6 dans le LCR et SEP. D'autres doivent être évaluées."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 37.8
    }]
  },
  {
    "code" : "K187",
    "display" : "Vitamine E (érythrocytaire)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-06"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Spécialisé"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 40.5
    }]
  },
  {
    "code" : "E067",
    "display" : "Antithrombine, activité progressive",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Fait partie du diagnostic de déficit en antithrombine."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 10.8
    }]
  },
  {
    "code" : "E043",
    "display" : "Willebrand, activité inhibitrice (anti facteur Willebrand)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation. Ce test a son intérêt dans le syndrome de VWD acquis et la recherche d'alloAc chez les VWD type 3 mais les performances analytiques sont à valider."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 40.5
    }]
  },
  {
    "code" : "E152",
    "display" : "Monomères de fibrine technique quantitative sur automate",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation. Technique automatisée dans le cadre de l'accréditation"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 8.1
    }]
  },
  {
    "code" : "L034",
    "display" : "Apolipoprotéine E (phénotype)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "12"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 54.0
    }]
  },
  {
    "code" : "N451",
    "display" : "Quantification d'une cible d'oncogénétique somatique lors du diagnostic ou du suivi d'une leucémie ou d'un lymphome (ou Maladie Résiduelle)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-3-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Sont définies pour chaque hémopathie maligne l'identification des cibles moléculaires et leur nombre"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 135.0
    }]
  },
  {
    "code" : "J097",
    "display" : "Enolase érythrocytaire",
    "property" : [{
      "code" : "parent",
      "valueCode" : "10-03"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2019-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 13.5
    }]
  },
  {
    "code" : "L010",
    "display" : "Sélénium (liquides biologiques)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "12"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Fusion des actes [L010] et [L079]. Intérêt dans déficits immunitaires, hémodialysés, sujets fragilisés, maladies infectieuses, cardiopathies, intoxications alimentaires,….."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 27.0
    }]
  },
  {
    "code" : "11-01",
    "display" : "Protéines",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11"
    },
    {
      "code" : "type",
      "valueString" : "Sous-chapitre"
    },
    {
      "code" : "child",
      "valueCode" : "K048"
    },
    {
      "code" : "child",
      "valueCode" : "K306"
    },
    {
      "code" : "child",
      "valueCode" : "L050"
    },
    {
      "code" : "child",
      "valueCode" : "K176"
    },
    {
      "code" : "child",
      "valueCode" : "K301"
    },
    {
      "code" : "child",
      "valueCode" : "E042"
    },
    {
      "code" : "child",
      "valueCode" : "K184"
    },
    {
      "code" : "child",
      "valueCode" : "K096"
    },
    {
      "code" : "child",
      "valueCode" : "K077"
    },
    {
      "code" : "child",
      "valueCode" : "K202"
    },
    {
      "code" : "child",
      "valueCode" : "K160"
    },
    {
      "code" : "child",
      "valueCode" : "K303"
    },
    {
      "code" : "child",
      "valueCode" : "K173"
    },
    {
      "code" : "child",
      "valueCode" : "K021"
    },
    {
      "code" : "child",
      "valueCode" : "K186"
    },
    {
      "code" : "child",
      "valueCode" : "K154"
    },
    {
      "code" : "child",
      "valueCode" : "K098"
    },
    {
      "code" : "child",
      "valueCode" : "K162"
    },
    {
      "code" : "child",
      "valueCode" : "K130"
    },
    {
      "code" : "child",
      "valueCode" : "K305"
    },
    {
      "code" : "child",
      "valueCode" : "K300"
    },
    {
      "code" : "child",
      "valueCode" : "K049"
    },
    {
      "code" : "child",
      "valueCode" : "K017"
    },
    {
      "code" : "child",
      "valueCode" : "K164"
    },
    {
      "code" : "child",
      "valueCode" : "K012"
    },
    {
      "code" : "child",
      "valueCode" : "K302"
    },
    {
      "code" : "child",
      "valueCode" : "L114"
    },
    {
      "code" : "child",
      "valueCode" : "K185"
    },
    {
      "code" : "child",
      "valueCode" : "K180"
    },
    {
      "code" : "child",
      "valueCode" : "K203"
    },
    {
      "code" : "child",
      "valueCode" : "K193"
    },
    {
      "code" : "child",
      "valueCode" : "K304"
    },
    {
      "code" : "child",
      "valueCode" : "K109"
    },
    {
      "code" : "child",
      "valueCode" : "K099"
    },
    {
      "code" : "child",
      "valueCode" : "K003"
    },
    {
      "code" : "child",
      "valueCode" : "K016"
    },
    {
      "code" : "child",
      "valueCode" : "K163"
    },
    {
      "code" : "child",
      "valueCode" : "K152"
    },
    {
      "code" : "child",
      "valueCode" : "K119"
    },
    {
      "code" : "child",
      "valueCode" : "K159"
    },
    {
      "code" : "child",
      "valueCode" : "J104"
    },
    {
      "code" : "child",
      "valueCode" : "K020"
    }]
  },
  {
    "code" : "H008",
    "display" : "Recherche non orientée par ME",
    "property" : [{
      "code" : "parent",
      "valueCode" : "08-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 54.0
    }]
  },
  {
    "code" : "I094",
    "display" : "Analyse des métabolites urinaires du cortisol en HPLC MS/MS comprend : cortisol, cortisone, THF, allo THF, THE, alpha cortol, bêta cortol, alpha cortolone et bêta cortolone,",
    "property" : [{
      "code" : "parent",
      "valueCode" : "09"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Etape enzymatique préalable incluse"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 135.0
    }]
  },
  {
    "code" : "K162",
    "display" : "Protéine Amyloïde A (SAA)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 18.9
    }]
  },
  {
    "code" : "08",
    "display" : "Virologie",
    "property" : [{
      "code" : "parent",
      "valueCode" : "LAHN"
    },
    {
      "code" : "type",
      "valueString" : "Chapitre"
    },
    {
      "code" : "child",
      "valueCode" : "08-01"
    },
    {
      "code" : "child",
      "valueCode" : "08-02"
    }]
  },
  {
    "code" : "N149",
    "display" : "Herpès virus humain 6:  typage (détermination de variant A ou B)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-2-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Validation d'un examen fondé sur une double PCR spécifique qualitative en temps réel"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 54.0
    }]
  },
  {
    "code" : "M012",
    "display" : "Autre médicament ou toxique : dosage par colorimétrie",
    "property" : [{
      "code" : "parent",
      "valueCode" : "13-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une cotation par médicament ou toxique dosé"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 18.9
    }]
  },
  {
    "code" : "G027",
    "display" : "Ac anti-MuSK",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 81.0
    }]
  },
  {
    "code" : "M121",
    "display" : "Dosage  de deux médicaments immunosuppresseurs prélevés simultanément (ciclosporine, acide mycophénolique, tacrolimus, sirolimus, évérolimus,…) par une méthode chromatographique dans le sang",
    "property" : [{
      "code" : "parent",
      "valueCode" : "13-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 37.8
    }]
  },
  {
    "code" : "K186",
    "display" : "Copeptine",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Cet acte est à coupler avec une troponine haute sensibilité (diagnostic d'exclusion) et un ECG ne montrant pas un infarctus du myocarde."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 40.5
    }]
  },
  {
    "code" : "K077",
    "display" : "Peptide collagène III (p-III-p)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 37.8
    }]
  },
  {
    "code" : "G136",
    "display" : "HIV différenciation M1/2-0",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-07"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 48.6
    }]
  },
  {
    "code" : "V009",
    "display" : "PCR classique ou temps réel qualitative multiplex pour ≥ 10 couples d'amorces (ADN/ARN)  - Indications évaluées par la HAS",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2025-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Indications évaluées par la HAS permettant une exemption à la décote."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 270.0
    }]
  },
  {
    "code" : "E044",
    "display" : "Willebrand, analyse des multimères",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Analyse des multimères (méthode complexe). Une seule cotation. Voir recommandations du Centre de référence Maladie de Willebrand : examen de 2nde intention pour la caractérisation d'une VWD"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 135.0
    }]
  },
  {
    "code" : "H007",
    "display" : "Antivirogramme herpèsvirus",
    "property" : [{
      "code" : "parent",
      "valueCode" : "08-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Par antiviral testé vis-à-vis d'un virus de la famille des Herpesviridae"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 94.5
    }]
  },
  {
    "code" : "N452",
    "display" : "Forfait  séquençage haut débit (NGS) < 20 kb",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-3-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Selon indications fixées par l'INCa et la DGOS\nLorsqu'il s'agit d'un acte qui concerne un test de détection des mutations génétiques [Test compagnon], l'acte n'est pas à coder au RAHN car il est inscrit à la CCAM et à la NABM :\nhttps://www.legifrance.gouv.fr/download/pdf?id=e1zu17CprDOqj9lE78rLBxw7vDZFNnoUYrgSjWmeUG4="
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 882.9
    }]
  },
  {
    "code" : "11-04",
    "display" : "Immunoglobulines",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11"
    },
    {
      "code" : "type",
      "valueString" : "Sous-chapitre"
    },
    {
      "code" : "child",
      "valueCode" : "K157"
    },
    {
      "code" : "child",
      "valueCode" : "K083"
    },
    {
      "code" : "child",
      "valueCode" : "K051"
    },
    {
      "code" : "child",
      "valueCode" : "K045"
    },
    {
      "code" : "child",
      "valueCode" : "K146"
    },
    {
      "code" : "child",
      "valueCode" : "K085"
    },
    {
      "code" : "child",
      "valueCode" : "K047"
    },
    {
      "code" : "child",
      "valueCode" : "K148"
    },
    {
      "code" : "child",
      "valueCode" : "K050"
    },
    {
      "code" : "child",
      "valueCode" : "K158"
    },
    {
      "code" : "child",
      "valueCode" : "K046"
    },
    {
      "code" : "child",
      "valueCode" : "K147"
    },
    {
      "code" : "child",
      "valueCode" : "K086"
    },
    {
      "code" : "child",
      "valueCode" : "K081"
    }]
  },
  {
    "code" : "G111",
    "display" : "Trichinose : SD de confirmation par une technique IE (western blot)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-06"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2025-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "La technique d'immunoempreinte est plus sensible et plus spécifique :"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 48.6
    }]
  },
  {
    "code" : "M102",
    "display" : "Génotypage de la dihydropyrimidine deshydrogénase (DPYD) pour ajustement de la dose d'un traitement  par fluoropyrimidines (ex : 5-fluorouracile)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "13-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2019-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 110.7
    }]
  },
  {
    "code" : "G244",
    "display" : "Ac anti-pompe à protons",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 18.9
    }]
  },
  {
    "code" : "K141",
    "display" : "Activité kininogénase spontanée du plasma",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-03"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Analyse ultra spécialisée"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 67.5
    }]
  },
  {
    "code" : "G026",
    "display" : "Ac anti-IgA",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 18.9
    }]
  },
  {
    "code" : "V004",
    "display" : "Forfait  séquençage haut débit (NGS) < 20 kb (cas index) - Indications évaluées par la HAS",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-3-1"
    },
    {
      "code" : "created",
      "valueDateTime" : "2025-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Indications évaluées par la HAS permettant une exemption à la décote."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 882.9
    }]
  },
  {
    "code" : "K032",
    "display" : "Dosage fonctionnel de C1 inhibiteur",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "En attente d'inscription à la NABM."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 18.9
    }]
  },
  {
    "code" : "N457",
    "display" : "Forfait mutationnel syndromes lymphoprolifératifs et lymphomes non-Hodgkiniens",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-3-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Mutations à impact diagnostique et/ou théranostique des syndromes lymphoprolifératifs et lymphomes non hodgkiniens (forfait 2 à 5) : MYD88 L265P, BRAF V600E, STAT3 exons 20 et 21, TP53 exons 4 à 9, NOTCH1 exon 34. Par cible"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 124.2
    }]
  },
  {
    "code" : "L121",
    "display" : "Phosphore minéral (dyalisat)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "12"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "En attente d'une modification potentielle du libellé de l'acte NABM [0563] prenant en compte les autres liquides biologiques que le sang."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 4.05
    }]
  },
  {
    "code" : "11-05",
    "display" : "Cytokines",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11"
    },
    {
      "code" : "type",
      "valueString" : "Sous-chapitre"
    },
    {
      "code" : "child",
      "valueCode" : "K055"
    },
    {
      "code" : "child",
      "valueCode" : "K151"
    },
    {
      "code" : "child",
      "valueCode" : "K054"
    },
    {
      "code" : "child",
      "valueCode" : "K117"
    }]
  },
  {
    "code" : "H006",
    "display" : "VIH antivirogramme",
    "property" : [{
      "code" : "parent",
      "valueCode" : "08-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2022-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 324.0
    }]
  },
  {
    "code" : "11-03",
    "display" : "Dosages impliqués dans l'exploration d'un angioedème",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11"
    },
    {
      "code" : "type",
      "valueString" : "Sous-chapitre"
    },
    {
      "code" : "child",
      "valueCode" : "K138"
    },
    {
      "code" : "child",
      "valueCode" : "K141"
    },
    {
      "code" : "child",
      "valueCode" : "K140"
    },
    {
      "code" : "child",
      "valueCode" : "K139"
    },
    {
      "code" : "child",
      "valueCode" : "K142"
    }]
  },
  {
    "code" : "K140",
    "display" : "Activité de la Dipeptidylpeptidase IV",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-03"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Analyse ultra spécialisée. Dosage sur cinétique longue, substrat FRET"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 135.0
    }]
  },
  {
    "code" : "M103",
    "display" : "Génotypage de la thiopurine-s-méthyl-transférase (TPMT) pour ajustement de la dose d'un traitement  comprenant un médicament thiopurinique",
    "property" : [{
      "code" : "parent",
      "valueCode" : "13-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 110.7
    }]
  },
  {
    "code" : "G110",
    "display" : "Paludisme : recherche Ag solubles par une technique immunochromatographique (tests de diagnostic rapide).",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-06"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "A faire si frottis et goutte épaisse négatifs.  Cf. conférence de consensus sur la prise en charge du paludisme de la société de pathologie. La recherche des Ag plasmodiaux dans le sang circulant est un outil indispensable au diagnostic de paludismeen France de part sa sensibilité, sa spécificité et sa rapidité/facilité de réalisation au regard d'une pathologie potentiellement léthale:"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 27.0
    }]
  },
  {
    "code" : "K188",
    "display" : "Ag prostatique spécifique (PSA) (dosage) (liquides biologiques autres que sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-07"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2022-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "En attente d'une modification potentielle du libellé de l'acte NABM [7318] prenant en compte les autres liquides biologiques que le sang."
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 20.25
    }]
  },
  {
    "code" : "G049",
    "display" : "MAI du système nerveux périphérique : profil anti-gangliosides IgG (GM1, GM2, GM3, GD1a, GD1b, GD3, GT1a, GT1b, GQ1b)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 40.5
    }]
  },
  {
    "code" : "V003",
    "display" : "Forfait séquençage haut débit (NGS) > 100 kb et < 500 kb - Indications évaluées par la HAS",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-3-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2025-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Indications évaluées par la HAS permettant une exemption à la décote.\nEn attente d'inscription aux nomenclatures"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 2205.9
    }]
  },
  {
    "code" : "K164",
    "display" : "Thiols protéiques plasmatiques",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 18.9
    }]
  },
  {
    "code" : "G025",
    "display" : "Ac anti-AIE 75",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 81.0
    }]
  },
  {
    "code" : "G158",
    "display" : "Auto-Ac anti-collagène",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 18.9
    }]
  },
  {
    "code" : "K055",
    "display" : "Dosage d'une cytokine par cytométrie en flux (technique billes)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-05"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "cf. commentaire acte [K054]"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 37.8
    }]
  },
  {
    "code" : "L059",
    "display" : "Pigments  et sels biliaires (recherche) (liquides biologiques autres que le sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "12"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "En attente d'une modification potentielle du libellé de l'acte NABM [0631] prenant en compte les autres liquides biologiques que le sang."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 5.4
    }]
  },
  {
    "code" : "E042",
    "display" : "Protéines S-100 (liquides biologiques )",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 32.4
    }]
  },
  {
    "code" : "E151",
    "display" : "Titrage des agglutinines froides (pour suivi thérapeutique)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-03"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "En attente de l'intégration potentielle au sein de l'acte NABM [1149] du titrage des agglutinines froides (pour suivi thérapeutique)"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 5.4
    }]
  },
  {
    "code" : "N458",
    "display" : "Forfait mutationnel leucémies aigues lymphoblastiques",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-3-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Mutations à impact diagnostique et/ou théranostique des leucémies aiguës lymphoblastiques (forfait 2 à 5) : NOTCH1 exons 26, 27, 28 et 34, FBXW7 exons 9 et 10, RAS et PTEN. Par cible"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 124.2
    }]
  },
  {
    "code" : "L011",
    "display" : "Silicium (et silicones) (liquides biologiques)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "12"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Fusion des actes [L011] et [L080]. Intérêt dans certaines arthropathies et implants siliconés."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 81.0
    }]
  },
  {
    "code" : "J052",
    "display" : "Phospholipase A2",
    "property" : [{
      "code" : "parent",
      "valueCode" : "10-04"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2019-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Spécialisé"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 81.0
    }]
  },
  {
    "code" : "F046",
    "display" : "Détection antigénique de la PLP2a  pour recherche résistance à la méthicilline des staphylocoques",
    "designation" : [{
      "language" : "fr",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009",
        "display" : "Synonym"
      },
      "value" : "Détection de la PLP2a (agglutination) pour recherche résistance à la méthicilline (SARM)"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "06-06"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 27.0
    }]
  },
  {
    "code" : "G024",
    "display" : "MAI nso : auto-Ac anti-b2GP1 par technique utilisant un marqueur d'isotype IgM",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 18.9
    }]
  },
  {
    "code" : "G133",
    "display" : "Herpes 8 IgG IF2 lytique",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-07"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 16.2
    }]
  },
  {
    "code" : "M015",
    "display" : "Métal ou autre élément : dosage par spectrométrie d'absorption atomique",
    "property" : [{
      "code" : "parent",
      "valueCode" : "13-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une cotation par métal ou autre élément dosé"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 32.4
    }]
  },
  {
    "code" : "N019",
    "display" : "Etude de la méthylation",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-3-1"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Concerne un nombre limité de maladies héréditaires pour lesquelles l'étude de la méthylation reste nécessaire au diagnostic (ex: syndromes de Prader-Willy et Angelman)."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 180.9
    }]
  },
  {
    "code" : "M100",
    "display" : "Dosage d'un antituberculeux par une méthode chromatographique dans un liquide biologique",
    "property" : [{
      "code" : "parent",
      "valueCode" : "13-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "En attente d'une modification potentielle du libellé et de la fusion des actes NABM [1652] [1653] prenant en compte les autres liquides biologiques que le sang."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 40.5
    }]
  },
  {
    "code" : "G242",
    "display" : "MAI du système nerveux périphérique : identification Ac anti-myéline par IFI",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 10.8
    }]
  },
  {
    "code" : "K034",
    "display" : "Dosage fonctionnel de C4",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2025-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Examen de 2nde ou 3ième intention ; réalisation technique et interprétation biologique nécessitant une expertise"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 32.4
    }]
  },
  {
    "code" : "G157",
    "display" : "Auto-Ac anti-NMDA",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 81.0
    }]
  },
  {
    "code" : "V006",
    "display" : "Forfait séquençage haut débit (NGS) > 100 kb et < 500 kb (cas index)  - Indications évaluées par la HAS",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-3-1"
    },
    {
      "code" : "created",
      "valueDateTime" : "2025-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Indications évaluées par la HAS permettant une exemption à la décote."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 2205.9
    }]
  },
  {
    "code" : "L147",
    "display" : "Lipoprotéines (ultracentrifugation) (sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "12"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 27.0
    }]
  },
  {
    "code" : "E063",
    "display" : "Ac spécifique d'un facteur de coagulation (hors facteurs VIII et IX), recherche",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une cotation par anticorps recherché. A réserver à centre de référence ou centre expert."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 21.6
    }]
  },
  {
    "code" : "N455",
    "display" : "Forfait mutationnel syndromes myéloprolifératifs",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-3-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Autres mutations à impact diagnostique et/ou théranostique des syndromes myéloprolifératifs (forfait 2 à 5): CALR exon 9, MPL W515 , JAK2 exon 12, CSFR3 exons 14 à 17, SETBP1 exon 4. Par cible"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 124.2
    }]
  },
  {
    "code" : "11-07",
    "display" : "Marqueurs Tumoraux",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11"
    },
    {
      "code" : "type",
      "valueString" : "Sous-chapitre"
    },
    {
      "code" : "child",
      "valueCode" : "K190"
    },
    {
      "code" : "child",
      "valueCode" : "K106"
    },
    {
      "code" : "child",
      "valueCode" : "I018"
    },
    {
      "code" : "child",
      "valueCode" : "K127"
    },
    {
      "code" : "child",
      "valueCode" : "K108"
    },
    {
      "code" : "child",
      "valueCode" : "K103"
    },
    {
      "code" : "child",
      "valueCode" : "K129"
    },
    {
      "code" : "child",
      "valueCode" : "K105"
    },
    {
      "code" : "child",
      "valueCode" : "K100"
    },
    {
      "code" : "child",
      "valueCode" : "K107"
    },
    {
      "code" : "child",
      "valueCode" : "K102"
    },
    {
      "code" : "child",
      "valueCode" : "K192"
    },
    {
      "code" : "child",
      "valueCode" : "K188"
    }]
  },
  {
    "code" : "10-01",
    "display" : "Enzymologie",
    "property" : [{
      "code" : "parent",
      "valueCode" : "10"
    },
    {
      "code" : "type",
      "valueString" : "Sous-chapitre"
    },
    {
      "code" : "child",
      "valueCode" : "J036"
    },
    {
      "code" : "child",
      "valueCode" : "J004"
    },
    {
      "code" : "child",
      "valueCode" : "J012"
    },
    {
      "code" : "child",
      "valueCode" : "J020"
    },
    {
      "code" : "child",
      "valueCode" : "J121"
    },
    {
      "code" : "child",
      "valueCode" : "J008"
    },
    {
      "code" : "child",
      "valueCode" : "J003"
    },
    {
      "code" : "child",
      "valueCode" : "J011"
    },
    {
      "code" : "child",
      "valueCode" : "J088"
    },
    {
      "code" : "child",
      "valueCode" : "J120"
    },
    {
      "code" : "child",
      "valueCode" : "J018"
    },
    {
      "code" : "child",
      "valueCode" : "J002"
    },
    {
      "code" : "child",
      "valueCode" : "J079"
    },
    {
      "code" : "child",
      "valueCode" : "J015"
    },
    {
      "code" : "child",
      "valueCode" : "J028"
    },
    {
      "code" : "child",
      "valueCode" : "J010"
    },
    {
      "code" : "child",
      "valueCode" : "J006"
    },
    {
      "code" : "child",
      "valueCode" : "J078"
    },
    {
      "code" : "child",
      "valueCode" : "L207"
    }]
  },
  {
    "code" : "I050",
    "display" : "Delta 4 androstènedione (liquide autre que le sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "09"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Spécialisé"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 22.95
    }]
  },
  {
    "code" : "G023",
    "display" : "MAI nso : auto-Ac anti-b2GP1 par technique utilisant un marqueur d'isotype IgG",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 18.9
    }]
  },
  {
    "code" : "G156",
    "display" : "Auto-Ac anti-aquaporine de type 4",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 81.0
    }]
  },
  {
    "code" : "M101",
    "display" : "Génotypage du cytochrome P450 3A5 pour ajustement de la dose d'un traitement comprenant du tacrolimus en transplantation",
    "property" : [{
      "code" : "parent",
      "valueCode" : "13-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 78.3
    }]
  },
  {
    "code" : "G132",
    "display" : "Herpes 8 IgG IF latence",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-07"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 16.2
    }]
  },
  {
    "code" : "K033",
    "display" : "Dosage fonctionnel de C2",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2025-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Examen de 2nde ou 3ième intention ; réalisation technique et interprétation biologique nécessitant une expertise"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 32.4
    }]
  },
  {
    "code" : "K142",
    "display" : "Activabilité kininogénase (capacité d'activation des proenzymes, test de Kluft)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-03"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Analyse ultra spécialisée"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 67.5
    }]
  },
  {
    "code" : "G047",
    "display" : "MAI du système nerveux périphérique : Ac anti-SGPG/SLGPG",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 18.9
    }]
  },
  {
    "code" : "V005",
    "display" : "Forfait séquençage haut débit (NGS) > 20 kb et < 100 kb (cas index)  - Indications évaluées par la HAS",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-3-1"
    },
    {
      "code" : "created",
      "valueDateTime" : "2025-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Indications évaluées par la HAS permettant une exemption à la décote."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 1503.9
    }]
  },
  {
    "code" : "E064",
    "display" : "Ac spécifique d'un facteur de coagulation  (hors facteurs VIII et IX), titrage",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une cotation par anticorps titré. A réserver à centre de référence ou centre expert."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 21.6
    }]
  },
  {
    "code" : "10-02",
    "display" : "Enzymologie du stress oxydatif",
    "property" : [{
      "code" : "parent",
      "valueCode" : "10"
    },
    {
      "code" : "type",
      "valueString" : "Sous-chapitre"
    },
    {
      "code" : "child",
      "valueCode" : "L055"
    },
    {
      "code" : "child",
      "valueCode" : "L052"
    },
    {
      "code" : "child",
      "valueCode" : "L048"
    },
    {
      "code" : "child",
      "valueCode" : "J043"
    },
    {
      "code" : "child",
      "valueCode" : "L138"
    },
    {
      "code" : "child",
      "valueCode" : "J065"
    },
    {
      "code" : "child",
      "valueCode" : "J046"
    },
    {
      "code" : "child",
      "valueCode" : "J027"
    },
    {
      "code" : "child",
      "valueCode" : "K181"
    },
    {
      "code" : "child",
      "valueCode" : "K116"
    },
    {
      "code" : "child",
      "valueCode" : "L056"
    },
    {
      "code" : "child",
      "valueCode" : "L069"
    },
    {
      "code" : "child",
      "valueCode" : "L051"
    },
    {
      "code" : "child",
      "valueCode" : "J045"
    },
    {
      "code" : "child",
      "valueCode" : "L047"
    }]
  },
  {
    "code" : "E040",
    "display" : "Procollagène",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 37.8
    }]
  },
  {
    "code" : "11-06",
    "display" : "Vitamines",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11"
    },
    {
      "code" : "type",
      "valueString" : "Sous-chapitre"
    },
    {
      "code" : "child",
      "valueCode" : "K094"
    },
    {
      "code" : "child",
      "valueCode" : "I042"
    },
    {
      "code" : "child",
      "valueCode" : "K183"
    },
    {
      "code" : "child",
      "valueCode" : "K187"
    },
    {
      "code" : "child",
      "valueCode" : "L042"
    },
    {
      "code" : "child",
      "valueCode" : "K088"
    },
    {
      "code" : "child",
      "valueCode" : "K093"
    },
    {
      "code" : "child",
      "valueCode" : "K092"
    },
    {
      "code" : "child",
      "valueCode" : "K174"
    },
    {
      "code" : "child",
      "valueCode" : "K182"
    }]
  },
  {
    "code" : "N456",
    "display" : "Forfait mutationnel syndromes myélodysplasiques",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-3-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Mutations à impact diagnostique et/ou théranostique des syndromes myélodysplasiques (forfait 2 à 5) : SF3B1 exons 14, 15 et 16. Par cible"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 124.2
    }]
  },
  {
    "code" : "L146",
    "display" : "Apolipoprotéine  E (dosage)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "12"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2019-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 13.5
    }]
  },
  {
    "code" : "J078",
    "display" : "Aldolase (liquides biologiques autres que le sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "10-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2022-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Fusion des actes [J078] et [J100] en attente d'une modification potentielle du libellé de l'acte NABM [1513] prenant en compte les autres liquides biologiques que le sang et les ponctions."
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 6.75
    }]
  },
  {
    "code" : "13-01",
    "display" : "Pharmacologie (dosage de médicaments)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "13"
    },
    {
      "code" : "type",
      "valueString" : "Sous-chapitre"
    },
    {
      "code" : "child",
      "valueCode" : "M056"
    },
    {
      "code" : "child",
      "valueCode" : "M120"
    },
    {
      "code" : "child",
      "valueCode" : "M101"
    },
    {
      "code" : "child",
      "valueCode" : "M013"
    },
    {
      "code" : "child",
      "valueCode" : "M053"
    },
    {
      "code" : "child",
      "valueCode" : "M002"
    },
    {
      "code" : "child",
      "valueCode" : "M103"
    },
    {
      "code" : "child",
      "valueCode" : "M004"
    },
    {
      "code" : "child",
      "valueCode" : "M118"
    },
    {
      "code" : "child",
      "valueCode" : "M100"
    },
    {
      "code" : "child",
      "valueCode" : "M012"
    },
    {
      "code" : "child",
      "valueCode" : "M025"
    },
    {
      "code" : "child",
      "valueCode" : "M121"
    },
    {
      "code" : "child",
      "valueCode" : "M001"
    },
    {
      "code" : "child",
      "valueCode" : "M003"
    },
    {
      "code" : "child",
      "valueCode" : "M104"
    },
    {
      "code" : "child",
      "valueCode" : "M119"
    },
    {
      "code" : "child",
      "valueCode" : "M102"
    }]
  },
  {
    "code" : "N142",
    "display" : "Détection ADN proviral par PCR + Southern blot 1 région génomique",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-2-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Inclus: analyse des données"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 162.0
    }]
  },
  {
    "code" : "G090",
    "display" : "Test Elispot sur PBMC",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-04"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Pour une stimulation. 10 stimulations maximum. Acte devant être encadré pour sa prescription et les étapes pré et post analytiques"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 70.2
    }]
  },
  {
    "code" : "L072",
    "display" : "Iode urinaire (iodurie) (urines)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "12"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Validé OMS. Marqueur du statut nutritionnel en iode. Technique actuelle ICPMS"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 24.3
    }]
  },
  {
    "code" : "E139",
    "display" : "Test à la mépacrine",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation. Conférence de consensus \"standardisation de l'exploration des pathologies plaquettaires\" (février 2009) du Centre de référence des pathologies plaquettaires : examen de niveau 2 (confirmation d'une orientation diagnostique)"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 32.4
    }]
  },
  {
    "code" : "M053",
    "display" : "Dosage d'un Ac monoclonal thérapeutique par une méthode autre que la cytométrie",
    "property" : [{
      "code" : "parent",
      "valueCode" : "13-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 27.0
    }]
  },
  {
    "code" : "E115",
    "display" : "Tissue Factor Pathway inhibitor (TFPI)  total",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation. Dépistage d'une anomalie rare de la coagulation dans un contexte thrombotique"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 37.8
    }]
  },
  {
    "code" : "E114",
    "display" : "Tissue Factor Pathway inhibitor (TFPI) libre",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation. Dépistage d'une anomalie rare de la coagulation dans un contexte thrombotique"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 37.8
    }]
  },
  {
    "code" : "K092",
    "display" : "Vitamine C (acide ascorbique)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-06"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2019-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 29.7
    }]
  },
  {
    "code" : "C044",
    "display" : "Dévitrification embryonnaire",
    "property" : [{
      "code" : "parent",
      "valueCode" : "03"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2020-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une cotation par cycle, quelque soit le nombre d'embryon"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 135.0
    }]
  },
  {
    "code" : "13-02",
    "display" : "Toxicologie (dosage de toxiques)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "13"
    },
    {
      "code" : "type",
      "valueString" : "Sous-chapitre"
    },
    {
      "code" : "child",
      "valueCode" : "M117"
    },
    {
      "code" : "child",
      "valueCode" : "M112"
    },
    {
      "code" : "child",
      "valueCode" : "M106"
    },
    {
      "code" : "child",
      "valueCode" : "M114"
    },
    {
      "code" : "child",
      "valueCode" : "M007"
    },
    {
      "code" : "child",
      "valueCode" : "M108"
    },
    {
      "code" : "child",
      "valueCode" : "M015"
    },
    {
      "code" : "child",
      "valueCode" : "M116"
    },
    {
      "code" : "child",
      "valueCode" : "M111"
    },
    {
      "code" : "child",
      "valueCode" : "M009"
    },
    {
      "code" : "child",
      "valueCode" : "M105"
    },
    {
      "code" : "child",
      "valueCode" : "M113"
    },
    {
      "code" : "child",
      "valueCode" : "M020"
    },
    {
      "code" : "child",
      "valueCode" : "M107"
    },
    {
      "code" : "child",
      "valueCode" : "M115"
    },
    {
      "code" : "child",
      "valueCode" : "M110"
    },
    {
      "code" : "child",
      "valueCode" : "M008"
    },
    {
      "code" : "child",
      "valueCode" : "M109"
    }]
  },
  {
    "code" : "N143",
    "display" : "Détection ADN proviral par PCR + Southern blot 2 régions génomiques",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-2-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Inclus: analyse des données"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 278.1
    }]
  },
  {
    "code" : "E116",
    "display" : "Thrombomoduline soluble",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation. Marqueur d'activation endothéliale d'une grande spécificité"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 37.8
    }]
  },
  {
    "code" : "G208",
    "display" : "Dénombrement de cellules endothéliales circulantes par immunoséparation magnétique",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 81.0
    }]
  },
  {
    "code" : "E200",
    "display" : "Cytologie des liquides et/ou appositions (hors sang et moelle)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Acte issu de la fusion des actes [B039], [E123] et [E146]. Concerne tous les prélèvements biologiques en cytospin (Examen cytologique : Après centrifugation d'un prélèvement dans une chambre d'échantillon jetable + lame. Obtention d'une monocouche cellulaire sur la lame + coloration MGG) ou étalement ou apposition susceptibles de comporter des cellules hématopoïétiques (examen cytologique sous microscope des cellules récupérées par empreintes au niveau de la conjonctive, transparisées et colorées. Il permet d'objectiver l'intensité de la souffrance cellulaire conjonctivale, de quantifier précisément les processus pathologiques : lymphocytes, polynucléaires, inflammation...)."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 27.0
    }]
  },
  {
    "code" : "C043",
    "display" : "Congélation/vitrification des ovocytes",
    "property" : [{
      "code" : "parent",
      "valueCode" : "03"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2020-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une cotation par ponction. Remplace \"vitrification ovocytaire\""
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 216.0
    }]
  },
  {
    "code" : "L050",
    "display" : "6-sulfatoxymélatonine",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 37.8
    }]
  },
  {
    "code" : "K094",
    "display" : "Vitamine K1 (phylloquinone)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-06"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Reco. HAS (mucoviscidose - maladie coeliaque)"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 108.0
    }]
  },
  {
    "code" : "V002",
    "display" : "Forfait séquençage haut débit (NGS) > 20 kb et < 100 kb - Indications évaluées par la HAS",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-3-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2025-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Indications évaluées par la HAS permettant une exemption à la décote.\nEn attente d'inscription aux nomenclatures"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 1503.9
    }]
  },
  {
    "code" : "E137",
    "display" : "Génération de thrombine",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation. Test global permettant d'évaluer le potentiel de génération de thrombine d'un plasma en mesurant en temps réel sa capacité à générer de la thrombine et sa capacité d'inhiber la coagulation."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 48.6
    }]
  },
  {
    "code" : "E136",
    "display" : "Facteur V plaquettaire",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation. A réaliser si acte [1015] diminué pour caractérisation du déficit en facteur V"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 37.8
    }]
  },
  {
    "code" : "G207",
    "display" : "Charge immunitaire fongique ou parasitaire (en dehors de la toxoplasmose) dans un liquide biologique",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-06"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Importance dans le diagnostic des toxocaroses oculaires  et des endophtalmies fongiques"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 27.0
    }]
  },
  {
    "code" : "E003",
    "display" : "Analyse du cycle cellulaire, par cytométrie en flux",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 81.0
    }]
  },
  {
    "code" : "E112",
    "display" : "Temps occlusion Platelet Function Analyzer (PFA)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une cotation par cartouche. Seul test existant pour l'exploration globale de l'hémostase primaire depuis le retrait du TS de la NABM, mais pour une pertinence d'orientation diagnostique de maladie de Willebrand, il doit être associé à d'autres examens"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 13.5
    }]
  },
  {
    "code" : "C022",
    "display" : "Conservation annuelle des ovocytes",
    "property" : [{
      "code" : "parent",
      "valueCode" : "03"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2020-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "une seule cotation par an et par patiente. Remplace \"Cryoconservation d'ovocyte\""
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 40.5
    }]
  },
  {
    "code" : "N140",
    "display" : "Forfait séquençage à partir de prélèvement de génome infectieux à ADN",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Inclus: analyse des données. Hors séquençage NGS"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 164.7
    }]
  },
  {
    "code" : "N141",
    "display" : "Forfait séquençage de génome viral: Génome à ARN (< 700 nucléotides)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-2-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Inclus: analyse des données"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 186.3
    }]
  },
  {
    "code" : "V001",
    "display" : "Forfait  séquençage haut débit (NGS) < 20 kb - Indications évaluées par la HAS",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-3-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2025-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Indications évaluées par la HAS permettant une exemption à la décote.\nEn attente d'inscription aux nomenclatures"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 882.9
    }]
  },
  {
    "code" : "E138",
    "display" : "Rétractation du caillot",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Intérêt pour le diagnostic de la thrombasthénie de Glanzmann. Test recommandé dans le document du Centre de Référence des Pathologies Plaquettaires (standardisation de l'exploration des pathologies plaquettaires)"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 1.35
    }]
  },
  {
    "code" : "K093",
    "display" : "Vitamine C oxydée/réduite (acide ascorbique, déhydroascorbique)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-06"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2019-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Spécialisé"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 37.8
    }]
  },
  {
    "code" : "C045",
    "display" : "Réchauffement des ovocytes",
    "property" : [{
      "code" : "parent",
      "valueCode" : "03"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2020-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation. Remplace \"dévitrification ovocytaire\""
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 135.0
    }]
  },
  {
    "code" : "A086",
    "display" : "Autopsie adulte (> 15 ans et 3 mois) : bloc viscéral",
    "property" : [{
      "code" : "parent",
      "valueCode" : "01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Examen externe, prélèvement et dissection du bloc viscéral, examen macroscopique et histologique après bloc paraffine des organes individualisés"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 1337.0
    }]
  },
  {
    "code" : "L097",
    "display" : "Inuline (Clairance)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "12"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2020-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 113.4
    }]
  },
  {
    "code" : "N037",
    "display" : "Diagnostic par southern ou Northern blot",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-1"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 224.1
    }]
  },
  {
    "code" : "J091",
    "display" : "Acétylcholinestérase érythrocytaire",
    "property" : [{
      "code" : "parent",
      "valueCode" : "10-03"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 13.5
    }]
  },
  {
    "code" : "K096",
    "display" : "Myoglobine (dosage) (liquides biologiques autres que sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "En attente d'une modification potentielle du libellé de l'acte NABM [1575] prenant en compte les autres liquides biologiques que le sang."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 10.8
    }]
  },
  {
    "code" : "G204",
    "display" : "Ac anti-récepteur à l'asialoglycoprotéine",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Utile dans le diagnostic des hépatopathies"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 27.0
    }]
  },
  {
    "code" : "G229",
    "display" : "Titrage Ac Anti PLA2R",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 54.0
    }]
  },
  {
    "code" : "E134",
    "display" : "Thrombus Activatable Fibrinolysis Inhibitor (TAFI) Ag",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation. Marqueur de risque associé aux pathologies hypertensive, à l'obésité, au diabète de type 2"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 18.9
    }]
  },
  {
    "code" : "G205",
    "display" : "Hépatopathies : confirmation par immunodiffusion des Ac anti réticulum endoplasmique et anti cytosol quand les 2 marqueurs sont recherchés",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 10.8
    }]
  },
  {
    "code" : "E001",
    "display" : "Détection de l'hémoglobine fœtale (Test de l'APT)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "En attente de l'intégration potentielle au sein de l'acte NABM [2109] de la détection hémoglobine fœtale (Test d'APT)"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 5.4
    }]
  },
  {
    "code" : "E110",
    "display" : "Temps de reptilase",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Dépistage du syndrome de Scott"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 5.4
    }]
  },
  {
    "code" : "K181",
    "display" : "Coenzyme Q10",
    "property" : [{
      "code" : "parent",
      "valueCode" : "10-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2022-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 29.7
    }]
  },
  {
    "code" : "07-03-02",
    "display" : "07-03-02-Epreuves de compatibilité tissulaire (cross-match)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-03"
    },
    {
      "code" : "type",
      "valueString" : "Sous-chapitre"
    },
    {
      "code" : "child",
      "valueCode" : "07-03-02-01"
    }]
  },
  {
    "code" : "L161",
    "display" : "Magnésium ionisé (liquides biologiques autres que sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "12"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "En attente d'une modification potentielle du libellé de l'acte NABM [0584] prenant en compte les autres liquides biologiques que le sang."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 4.05
    }]
  },
  {
    "code" : "L052",
    "display" : "Profil des Caroténoïdes",
    "property" : [{
      "code" : "parent",
      "valueCode" : "10-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 81.0
    }]
  },
  {
    "code" : "G119",
    "display" : "Toxoplasmose : suivi du nourrisson ou du jeune enfant né d'une mère a risque toxoplasmique: suivi: sd de surveillance avec titrage des IgG et recherche de 2 autres isotypes dont obligatoirement IgM",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-06"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2020-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Cotation globale. examen réservé à des laboratoires agréés ou spécialisés. Importance du dépistage et du suivi spécialisé des nouveaus-né à risque de toxoplasmose congénitale de par son impact sur la prise en charge thérapeutique conformément aux recommandations du CNR des tooplasmoses:"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 27.0
    }]
  },
  {
    "code" : "E135",
    "display" : "Facteur 3 plaquettaire\nActivité procoagulante des microparticules",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation. Marqueur de risque de thrombose et de dissémination cancéreuse."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 27.0
    }]
  },
  {
    "code" : "G228",
    "display" : "Dépistage Ac Anti PLA2R",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 27.0
    }]
  },
  {
    "code" : "K180",
    "display" : "ADMA (asymetric diméthyl arginine)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 54.0
    }]
  },
  {
    "code" : "L099",
    "display" : "Test de perméabilité intestinale (TPI) au mannitol",
    "property" : [{
      "code" : "parent",
      "valueCode" : "12"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2019-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 13.5
    }]
  },
  {
    "code" : "L051",
    "display" : "Carbonyles",
    "property" : [{
      "code" : "parent",
      "valueCode" : "10-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2022-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 27.0
    }]
  },
  {
    "code" : "N450",
    "display" : "Quantification d'une cible d'immunogénétique (Ig/TCR) lors du suivi d'une leucémie lymphoblastique ou d'un syndrome lymphoprolifératif (ou Maladie Résiduelle)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-3-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Suivi d'une leucémie aigue lymphoblastique ou de certains lymphomes"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 315.9
    }]
  },
  {
    "code" : "F028",
    "display" : "Identification poussée jusqu'à l'espèce d'un Candida albicans dans le cadre d'un examen mycologique associé à un examen bactériologique, ou d'une souche de champignon reçue d'un autre laboratoire",
    "property" : [{
      "code" : "parent",
      "valueCode" : "06-04"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Importance de l'identification de l'espèce pour la mise en place d'une thérapeutique adaptée. Non cumulable avec le [0252]. L'acte [0280] n'est applicable que pour les C. non albicans mais n'est pas applicable pour l'identification de C. albicans. L'acte [0255] n'est prévue que pour les champignons exotiques. Nouvelle cotation introduite pour coter les identifications des C.albicans transmis par les Services de Bactériologie."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 13.5
    }]
  },
  {
    "code" : "N120",
    "display" : "Staphylococcus aureus: Identification (à partir de colonies) par hybridation sur bandelette + recherche toxine PVL + résistance à la méthicilline",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-2-1"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Inclus: extraction choc thermique + 3 oligo biotinylés + taq Sybr Green + PCR TR + hybridation nitrocellulose"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 129.6
    }]
  },
  {
    "code" : "N144",
    "display" : "Détection protéine 14.3.3 dans LCR par western blot",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-1"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 94.5
    }]
  },
  {
    "code" : "K050",
    "display" : "IgG + IgA + IgM + albumine + proteines + rapport: Ig/prot (LBA), IgG/Alb (LCR)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-04"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Dosage de routine sur indications précises ; interprétation biologique nécessitant une expertise"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 45.9
    }]
  },
  {
    "code" : "K183",
    "display" : "Delta et gamma tocophérol",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-06"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Spécialisé"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 29.7
    }]
  },
  {
    "code" : "K098",
    "display" : "Acide hyaluronique (liquides biologiques autres que sang, ponctions)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "En attente d'une modification potentielle du libellé de l'acte NABM [7308] prenant en compte les autres liquides biologiques que le sang."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 40.5
    }]
  },
  {
    "code" : "G202",
    "display" : "Ac anti-anhydrase carbonique II",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 18.9
    }]
  },
  {
    "code" : "C042",
    "display" : "Vitrification embryonnaire",
    "property" : [{
      "code" : "parent",
      "valueCode" : "03"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2020-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une cotation par cycle"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 216.0
    }]
  },
  {
    "code" : "E047",
    "display" : "Willebrand, fixation au facteur VIII",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation. Seul examen permettant le diagnostic du variant 2N de la VWD"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 81.0
    }]
  },
  {
    "code" : "E156",
    "display" : "Exploration de l’affinité de l’hémoglobine (Oxymétrie: Mesure de la P50)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation. P50 et toutes les anomalies d'affinité de l'hémoglobine qui ont peu d'impact sur la P50, mais qui peuvent avoir un impact sur la captation ou le relarguage de l'oxygène par l'hémoglobine"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 54.0
    }]
  },
  {
    "code" : "14-3-2",
    "display" : "Génétique somatique des cancer",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-3"
    },
    {
      "code" : "type",
      "valueString" : "Sous-chapitre"
    },
    {
      "code" : "child",
      "valueCode" : "N534"
    },
    {
      "code" : "child",
      "valueCode" : "N502"
    },
    {
      "code" : "child",
      "valueCode" : "N515"
    },
    {
      "code" : "child",
      "valueCode" : "N459"
    },
    {
      "code" : "child",
      "valueCode" : "N510"
    },
    {
      "code" : "child",
      "valueCode" : "N408"
    },
    {
      "code" : "child",
      "valueCode" : "N454"
    },
    {
      "code" : "child",
      "valueCode" : "N509"
    },
    {
      "code" : "child",
      "valueCode" : "N523"
    },
    {
      "code" : "child",
      "valueCode" : "N536"
    },
    {
      "code" : "child",
      "valueCode" : "N504"
    },
    {
      "code" : "child",
      "valueCode" : "N006"
    },
    {
      "code" : "child",
      "valueCode" : "N517"
    },
    {
      "code" : "child",
      "valueCode" : "N531"
    },
    {
      "code" : "child",
      "valueCode" : "N512"
    },
    {
      "code" : "child",
      "valueCode" : "N456"
    },
    {
      "code" : "child",
      "valueCode" : "N525"
    },
    {
      "code" : "child",
      "valueCode" : "N451"
    },
    {
      "code" : "child",
      "valueCode" : "N506"
    },
    {
      "code" : "child",
      "valueCode" : "N520"
    },
    {
      "code" : "child",
      "valueCode" : "N400"
    },
    {
      "code" : "child",
      "valueCode" : "N519"
    },
    {
      "code" : "child",
      "valueCode" : "N533"
    },
    {
      "code" : "child",
      "valueCode" : "N501"
    },
    {
      "code" : "child",
      "valueCode" : "N514"
    },
    {
      "code" : "child",
      "valueCode" : "N458"
    },
    {
      "code" : "child",
      "valueCode" : "N453"
    },
    {
      "code" : "child",
      "valueCode" : "N421"
    },
    {
      "code" : "child",
      "valueCode" : "N508"
    },
    {
      "code" : "child",
      "valueCode" : "N535"
    },
    {
      "code" : "child",
      "valueCode" : "N503"
    },
    {
      "code" : "child",
      "valueCode" : "N005"
    },
    {
      "code" : "child",
      "valueCode" : "N516"
    },
    {
      "code" : "child",
      "valueCode" : "N530"
    },
    {
      "code" : "child",
      "valueCode" : "N511"
    },
    {
      "code" : "child",
      "valueCode" : "N455"
    },
    {
      "code" : "child",
      "valueCode" : "N524"
    },
    {
      "code" : "child",
      "valueCode" : "N404"
    },
    {
      "code" : "child",
      "valueCode" : "N450"
    },
    {
      "code" : "child",
      "valueCode" : "N537"
    },
    {
      "code" : "child",
      "valueCode" : "N417"
    },
    {
      "code" : "child",
      "valueCode" : "N518"
    },
    {
      "code" : "child",
      "valueCode" : "N532"
    },
    {
      "code" : "child",
      "valueCode" : "N500"
    },
    {
      "code" : "child",
      "valueCode" : "N513"
    },
    {
      "code" : "child",
      "valueCode" : "N457"
    },
    {
      "code" : "child",
      "valueCode" : "N452"
    },
    {
      "code" : "child",
      "valueCode" : "N420"
    },
    {
      "code" : "child",
      "valueCode" : "V001"
    },
    {
      "code" : "child",
      "valueCode" : "V003"
    },
    {
      "code" : "child",
      "valueCode" : "N407"
    },
    {
      "code" : "child",
      "valueCode" : "N409"
    },
    {
      "code" : "child",
      "valueCode" : "V002"
    },
    {
      "code" : "child",
      "valueCode" : "N507"
    }]
  },
  {
    "code" : "G118",
    "display" : "Toxoplasmose : dépistage chez nouveau-né d'une mère à risque toxoplasmique :  profils immunologiques comparés mère-enfant, enfant-enfant,….par enzyme-linked-immunofiltration assay (ELIFA) ou par immuno-empreinte (WB) pour un isotype",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-06"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2020-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Maximum de trois isotypes. Examen réservé à des laboratoires agréés ou spécialisés. Importance du dépistage et du suivi spécialisé des nouveaus-né à risque de toxoplasmose congénitale de par son impact sur la prise en charge thérapeutique conformément aux recommandations du CNR des tooplasmoses:"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 86.4
    }]
  },
  {
    "code" : "E132",
    "display" : "Test RIPA (ristocetin-induced platelet agglutination)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "En attente de l'intégration potentielle au sein de l'acte NABM [1011] du test RIPA"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 16.2
    }]
  },
  {
    "code" : "L187",
    "display" : "Bilan d’absorption en double plateau",
    "property" : [{
      "code" : "parent",
      "valueCode" : "12"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Fusion des actes [L187], [L223] et [L224]"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 81.0
    }]
  },
  {
    "code" : "L054",
    "display" : "Malonaldéhyde (sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "12"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 48.6
    }]
  },
  {
    "code" : "F029",
    "display" : "Recherche de pneumocystis jiroveci",
    "property" : [{
      "code" : "parent",
      "valueCode" : "06-04"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2020-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Par 1 coloration,  maximum 2 cotations. Dans le cas d'un examen mycologique d'un LBA, sur demande ou après accord avec le clinicien, le biologiste peut effectuer la recherche de pneumocystis jiroveci. Importance clinique du dépistage de Pneumocystis à l'examen direct :"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 8.1
    }]
  },
  {
    "code" : "N145",
    "display" : "détection protéine PRPres dans biopsie cérébrale ou amygdale par Western blot",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-1"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 94.5
    }]
  },
  {
    "code" : "M056",
    "display" : "Recherche, identification et dosage d'anticoagulant par une méthode chromatographique, dans un liquide biologique",
    "property" : [{
      "code" : "parent",
      "valueCode" : "13-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 27.0
    }]
  },
  {
    "code" : "K182",
    "display" : "5 méthyl TétraHydroFolate (THF) (plasma , LCR)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-06"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2022-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Spécialisé"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 40.5
    }]
  },
  {
    "code" : "G225",
    "display" : "Définition des marqueurs informatifs pour le suivi du chimérisme post-greffe (chez donneur et receveur)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-03"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "A réaliser au sein de laboratoires accrédités par l'European Federation for Imunogenetics (EFI)"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 459.0
    }]
  },
  {
    "code" : "G116",
    "display" : "Toxoplasmose: Recherche d'autres marqueurs de toxoplasmose évolutive pour datation et évaluation du risque  si sérologie de dépistage évoquant une infection évolutive: IgA",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-06"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2020-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Examen réservé à des laboratoires agréés ou spécialisés. Valeur des IgA et IgM pour différencier une toxoplasmose évolutive d'une séquelle sérologique (selon les recommandations du CNR de la toxoplasmose):"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 8.1
    }]
  },
  {
    "code" : "G201",
    "display" : "MAI nso : recherche de spécificités autres que MPO et PR3",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Par spécificité, cotation maximum 4 spécificités"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 18.9
    }]
  },
  {
    "code" : "E049",
    "display" : "Anticorps anti-Willebrand protéase (anti-ADAMTS 13) :  recherche et titrage",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2025-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation. Dosage qui a montré son utilité dans le diagnostic du PTT et doit être disponible en urgence (Kit Technoclone)"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 67.5
    }]
  },
  {
    "code" : "14-3-1",
    "display" : "Génétique constitutionnelle postnatale",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-3"
    },
    {
      "code" : "type",
      "valueString" : "Sous-chapitre"
    },
    {
      "code" : "child",
      "valueCode" : "N353"
    },
    {
      "code" : "child",
      "valueCode" : "N315"
    },
    {
      "code" : "child",
      "valueCode" : "N019"
    },
    {
      "code" : "child",
      "valueCode" : "N355"
    },
    {
      "code" : "child",
      "valueCode" : "N350"
    },
    {
      "code" : "child",
      "valueCode" : "N317"
    },
    {
      "code" : "child",
      "valueCode" : "N352"
    },
    {
      "code" : "child",
      "valueCode" : "N314"
    },
    {
      "code" : "child",
      "valueCode" : "N354"
    },
    {
      "code" : "child",
      "valueCode" : "N351"
    },
    {
      "code" : "child",
      "valueCode" : "V006"
    },
    {
      "code" : "child",
      "valueCode" : "V005"
    },
    {
      "code" : "child",
      "valueCode" : "V004"
    },
    {
      "code" : "child",
      "valueCode" : "V015"
    }]
  },
  {
    "code" : "E048",
    "display" : "Willebrand, protéase (ADAMTS 13) : activité",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2025-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation. Dosage qui a montré son utilité dans le diagnostic du PTT et doit être disponible en urgence (Kit Technoclone)"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 67.5
    }]
  },
  {
    "code" : "C041",
    "display" : "Congélation du tissu ovarien",
    "property" : [{
      "code" : "parent",
      "valueCode" : "03"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 270.0
    }]
  },
  {
    "code" : "E157",
    "display" : "Frottis: Immunomarquage sur lame par Ac",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "A partir d'un frottis : technique d'immunomarquage sur lame par Ac. Une cotation par Ac. Exemple : mise en évidence de la localisation cytoplasmique ou nucléaire d'un antigène (e.g. NPM1), non accessible aux techniques classiques de cytométrie"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 40.5
    }]
  },
  {
    "code" : "G117",
    "display" : "Toxoplasmose : avidité IgG",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-06"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2020-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "L'avidité des IgG permet de dater l'infection toxoplasmique notamment chez les femmes enceintes avec des IgM positives au cours de la grossesse sans suivi sérologique régulier: (examen réservé à des laboratoires agréés ou spécialisés)."
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 32.4
    }]
  },
  {
    "code" : "L053",
    "display" : "Citrate (sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "12"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 9.45
    }]
  },
  {
    "code" : "F004",
    "display" : "Concentration des urines pour mise en évidence des Ag solubles",
    "property" : [{
      "code" : "parent",
      "valueCode" : "06-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Indiqué dans le REMIC"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 8.1
    }]
  },
  {
    "code" : "K105",
    "display" : "Ag carcino-embryonnaire (ACE) (liquides biologiques autres que sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-07"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "En attente d'une modification potentielle du libellé de l'acte NABM [7327] prenant en compte les autres liquides biologiques que le sang."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 20.25
    }]
  },
  {
    "code" : "G074",
    "display" : "PN : Explosion oxydative : cytométrie en flux",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-04"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Par inducteur. Acte devant être encadré pour sa prescription et les étapes pré et post analytiques"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 108.0
    }]
  },
  {
    "code" : "G050",
    "display" : "MAI du système nerveux périphérique : profil Ac anti-gangliosides IgM (GM1, GM2, GM3, GD1a, GD1b, GD3, GT1a, GT1b, GQ1b)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 40.5
    }]
  },
  {
    "code" : "K129",
    "display" : "Ag du carcinome à cellules squameuses (SCC) (dosage) (liquides biologiques autres que sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-07"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "En attente d'une modification potentielle du libellé de l'acte NABM [0812] prenant en compte les autres liquides biologiques que le sang."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 29.7
    }]
  },
  {
    "code" : "07-02",
    "display" : "auto-immunité",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07"
    },
    {
      "code" : "type",
      "valueString" : "Sous-chapitre"
    },
    {
      "code" : "child",
      "valueCode" : "G199"
    },
    {
      "code" : "child",
      "valueCode" : "G047"
    },
    {
      "code" : "child",
      "valueCode" : "G015"
    },
    {
      "code" : "child",
      "valueCode" : "G204"
    },
    {
      "code" : "child",
      "valueCode" : "G028"
    },
    {
      "code" : "child",
      "valueCode" : "G042"
    },
    {
      "code" : "child",
      "valueCode" : "G023"
    },
    {
      "code" : "child",
      "valueCode" : "G244"
    },
    {
      "code" : "child",
      "valueCode" : "G156"
    },
    {
      "code" : "child",
      "valueCode" : "G036"
    },
    {
      "code" : "child",
      "valueCode" : "G050"
    },
    {
      "code" : "child",
      "valueCode" : "G151"
    },
    {
      "code" : "child",
      "valueCode" : "G049"
    },
    {
      "code" : "child",
      "valueCode" : "G044"
    },
    {
      "code" : "child",
      "valueCode" : "K114"
    },
    {
      "code" : "child",
      "valueCode" : "G012"
    },
    {
      "code" : "child",
      "valueCode" : "G201"
    },
    {
      "code" : "child",
      "valueCode" : "G057"
    },
    {
      "code" : "child",
      "valueCode" : "G025"
    },
    {
      "code" : "child",
      "valueCode" : "G158"
    },
    {
      "code" : "child",
      "valueCode" : "G052"
    },
    {
      "code" : "child",
      "valueCode" : "G153"
    },
    {
      "code" : "child",
      "valueCode" : "G198"
    },
    {
      "code" : "child",
      "valueCode" : "G014"
    },
    {
      "code" : "child",
      "valueCode" : "G059"
    },
    {
      "code" : "child",
      "valueCode" : "G027"
    },
    {
      "code" : "child",
      "valueCode" : "G041"
    },
    {
      "code" : "child",
      "valueCode" : "K111"
    },
    {
      "code" : "child",
      "valueCode" : "G230"
    },
    {
      "code" : "child",
      "valueCode" : "G054"
    },
    {
      "code" : "child",
      "valueCode" : "G229"
    },
    {
      "code" : "child",
      "valueCode" : "G022"
    },
    {
      "code" : "child",
      "valueCode" : "G155"
    },
    {
      "code" : "child",
      "valueCode" : "G035"
    },
    {
      "code" : "child",
      "valueCode" : "G150"
    },
    {
      "code" : "child",
      "valueCode" : "G016"
    },
    {
      "code" : "child",
      "valueCode" : "G062"
    },
    {
      "code" : "child",
      "valueCode" : "G205"
    },
    {
      "code" : "child",
      "valueCode" : "G043"
    },
    {
      "code" : "child",
      "valueCode" : "K113"
    },
    {
      "code" : "child",
      "valueCode" : "G056"
    },
    {
      "code" : "child",
      "valueCode" : "G024"
    },
    {
      "code" : "child",
      "valueCode" : "G157"
    },
    {
      "code" : "child",
      "valueCode" : "G152"
    },
    {
      "code" : "child",
      "valueCode" : "G018"
    },
    {
      "code" : "child",
      "valueCode" : "K115"
    },
    {
      "code" : "child",
      "valueCode" : "K161"
    },
    {
      "code" : "child",
      "valueCode" : "G202"
    },
    {
      "code" : "child",
      "valueCode" : "G058"
    },
    {
      "code" : "child",
      "valueCode" : "G026"
    },
    {
      "code" : "child",
      "valueCode" : "G040"
    },
    {
      "code" : "child",
      "valueCode" : "K110"
    },
    {
      "code" : "child",
      "valueCode" : "G039"
    },
    {
      "code" : "child",
      "valueCode" : "G053"
    },
    {
      "code" : "child",
      "valueCode" : "G228"
    },
    {
      "code" : "child",
      "valueCode" : "G242"
    },
    {
      "code" : "child",
      "valueCode" : "G154"
    }]
  },
  {
    "code" : "L218",
    "display" : "Mannose",
    "property" : [{
      "code" : "parent",
      "valueCode" : "12"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 16.2
    }]
  },
  {
    "code" : "L109",
    "display" : "Triglycérides (liquides biologiques hors sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "12"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "En attente d'une modification potentielle du libellé de l'acte NABM [0590] prenant en compte les autres liquides biologiques que le sang."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 1.35
    }]
  },
  {
    "code" : "N506",
    "display" : "Séquençage CTNNB1 (exon 3)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-3-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 162.0
    }]
  },
  {
    "code" : "J015",
    "display" : "Lipase (liquides biologiques autres que le sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "10-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "En attente d'une modification potentielle du libellé de l'acte NABM [0524] prenant en compte les autres liquides biologiques que le sang."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 18.9
    }]
  },
  {
    "code" : "N942",
    "display" : "Forfait séquençage haut débit (NGS) > 100 kb et < 500 kb",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Selon indications des sociétés savantes. Hors pris en charge par le forfait séquencage de la NABM  [9007]"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 2205.9
    }]
  },
  {
    "code" : "B049",
    "display" : "Hybridation Génomique Comparative (CGH) sur billes",
    "property" : [{
      "code" : "parent",
      "valueCode" : "02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 297.0
    }]
  },
  {
    "code" : "14-3",
    "display" : "Détection du génome humain",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14"
    },
    {
      "code" : "type",
      "valueString" : "Sous-chapitre"
    },
    {
      "code" : "child",
      "valueCode" : "14-3-2"
    },
    {
      "code" : "child",
      "valueCode" : "14-3-1"
    },
    {
      "code" : "child",
      "valueCode" : "N903"
    },
    {
      "code" : "child",
      "valueCode" : "N904"
    },
    {
      "code" : "child",
      "valueCode" : "N318"
    }]
  },
  {
    "code" : "G073",
    "display" : "PN : Explosion oxydative : réduction du cytochrome c",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-04"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Acte devant être encadré pour sa prescription et les étapes pré et post analytiques"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 216.0
    }]
  },
  {
    "code" : "P069",
    "display" : "Etude métabolique in vitro (test fonctionnel sur cellules en culture)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "16-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 270.0
    }]
  },
  {
    "code" : "C004",
    "display" : "Maturation in vitro des ovocytes",
    "property" : [{
      "code" : "parent",
      "valueCode" : "03"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Mise en culture d'ovocytes en vue de leur maturation in vitro avant ICSI"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 378.0
    }]
  },
  {
    "code" : "07-03",
    "display" : "Histocompatibilité",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07"
    },
    {
      "code" : "type",
      "valueString" : "Sous-chapitre"
    },
    {
      "code" : "child",
      "valueCode" : "G305"
    },
    {
      "code" : "child",
      "valueCode" : "G300"
    },
    {
      "code" : "child",
      "valueCode" : "G257"
    },
    {
      "code" : "child",
      "valueCode" : "G225"
    },
    {
      "code" : "child",
      "valueCode" : "G252"
    },
    {
      "code" : "child",
      "valueCode" : "07-03-02"
    },
    {
      "code" : "child",
      "valueCode" : "G254"
    },
    {
      "code" : "child",
      "valueCode" : "G180"
    },
    {
      "code" : "child",
      "valueCode" : "G179"
    },
    {
      "code" : "child",
      "valueCode" : "G304"
    },
    {
      "code" : "child",
      "valueCode" : "G174"
    },
    {
      "code" : "child",
      "valueCode" : "G256"
    },
    {
      "code" : "child",
      "valueCode" : "G224"
    },
    {
      "code" : "child",
      "valueCode" : "G251"
    },
    {
      "code" : "child",
      "valueCode" : "G176"
    },
    {
      "code" : "child",
      "valueCode" : "07-03-01"
    },
    {
      "code" : "child",
      "valueCode" : "G301"
    },
    {
      "code" : "child",
      "valueCode" : "G258"
    },
    {
      "code" : "child",
      "valueCode" : "G303"
    },
    {
      "code" : "child",
      "valueCode" : "G255"
    }]
  },
  {
    "code" : "L217",
    "display" : "Xylosurie",
    "property" : [{
      "code" : "parent",
      "valueCode" : "12"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 16.2
    }]
  },
  {
    "code" : "N507",
    "display" : "Séquençage KIT : 3 exons",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-3-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2019-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Exons 11, 13 et 17 du gène KIT. Indication : mélanome acrolentigineux et mélanome de Dubreuillh ; Cumulable avec [N525]"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 113.4
    }]
  },
  {
    "code" : "J016",
    "display" : "Lipoprotéine lipase",
    "property" : [{
      "code" : "parent",
      "valueCode" : "10-04"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Comprend les 2 mesures d'activité de la LipoProtéine Lipase (LPL) et de la Lipase Hépatique (HL). Spécialisé"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 162.0
    }]
  },
  {
    "code" : "14-2",
    "display" : "Détection du génome infectieux (applicables aux détections de génômes bactériens, viraux, parasitaires ou fongiques)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14"
    },
    {
      "code" : "type",
      "valueString" : "Sous-chapitre"
    },
    {
      "code" : "child",
      "valueCode" : "N156"
    },
    {
      "code" : "child",
      "valueCode" : "14-2-3"
    },
    {
      "code" : "child",
      "valueCode" : "14-2-2"
    },
    {
      "code" : "child",
      "valueCode" : "14-2-1"
    },
    {
      "code" : "child",
      "valueCode" : "N140"
    },
    {
      "code" : "child",
      "valueCode" : "N139"
    },
    {
      "code" : "child",
      "valueCode" : "N941"
    },
    {
      "code" : "child",
      "valueCode" : "N134"
    },
    {
      "code" : "child",
      "valueCode" : "N155"
    },
    {
      "code" : "child",
      "valueCode" : "N131"
    },
    {
      "code" : "child",
      "valueCode" : "N157"
    },
    {
      "code" : "child",
      "valueCode" : "N138"
    },
    {
      "code" : "child",
      "valueCode" : "N940"
    },
    {
      "code" : "child",
      "valueCode" : "N942"
    },
    {
      "code" : "child",
      "valueCode" : "N135"
    },
    {
      "code" : "child",
      "valueCode" : "V012"
    },
    {
      "code" : "child",
      "valueCode" : "V014"
    },
    {
      "code" : "child",
      "valueCode" : "V008"
    },
    {
      "code" : "child",
      "valueCode" : "V011"
    },
    {
      "code" : "child",
      "valueCode" : "V013"
    },
    {
      "code" : "child",
      "valueCode" : "V007"
    },
    {
      "code" : "child",
      "valueCode" : "V010"
    },
    {
      "code" : "child",
      "valueCode" : "V009"
    }]
  },
  {
    "code" : "N195",
    "display" : "Western blot avec 1 Ac",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-1"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "En cas de génome infectieux, hors actes inscrits à la NABM"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 81.0
    }]
  },
  {
    "code" : "K301",
    "display" : "Placental Growth Factor",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Le potentiel du PlGF dans le dépistage de la prééclampsie (PE) est connu depuis 2004 mais les dernières études en confirment l'efficacité en l'associant aux données maternelles cliniques et échograhiques. L'efficacité clinique du PlGF seul est soit modeste, soit avérée, par contre son association à d'autres critères s'avère plus efficace. Aucun essai randomisé comparant la prise en charge classique versus le dépistage de la PE n'a été publié. Une étude récente a validé l'intérêt médico-économique du dépistage de la PE en incluant le PlGF"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 37.8
    }]
  },
  {
    "code" : "P068",
    "display" : "Mesure d'une activité enzymatique avec isolement et préparation des cellules",
    "property" : [{
      "code" : "parent",
      "valueCode" : "16-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Cotation limitée à un maximum de 8 enzymes. Indication: enzyme(s) connue(s) pour être en lien avec la pathologie héréditaire recherchée."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 27.0
    }]
  },
  {
    "code" : "K107",
    "display" : "Enolase (dosage)(liquides biologiques autres que sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-07"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Fusion des actes [K107], [J035] et [J084] en attente d'une modification potentielle du libellé de l'acte NABM [0814] prenant en compte les autres liquides biologiques que le sang."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 29.7
    }]
  },
  {
    "code" : "G072",
    "display" : "PN : NADPH oxydase : Western blot",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-04"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 216.0
    }]
  },
  {
    "code" : "N504",
    "display" : "Séquençage EGFR : 4 exons",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-3-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Dans la prise en charge du CBNPC, l'acte n'est pas à coder au RIHN, car il doit être intégré dans le panel, sauf en cas d'urgence, où une approche monogénique est à privilégier (source HAS)"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 315.9
    }]
  },
  {
    "code" : "Q024",
    "display" : "Quantification et qualification de progéniteurs hématopoiétiques/endothéliaux par culture",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Regroupe les anciens codes [Q023], [Q024] et Q025]"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 81.0
    }]
  },
  {
    "code" : "N940",
    "display" : "Forfait  séquençage haut débit (NGS) < 20 kb",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Selon indications des sociétés savantes. Hors pris en charge par le forfait séquencage de la NABM  [9007]"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 882.9
    }]
  },
  {
    "code" : "G180",
    "display" : "Etude du chimérisme (sur cellules triées du sang ou de la moelle)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-03"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "A réaliser au sein de laboratoires accrédités par l'European Federation for Imunogenetics (EFI)"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 189.0
    }]
  },
  {
    "code" : "K300",
    "display" : "S-Adenosyl méthionine ou S-Adenosyl homocystéine",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Fusion des actes [K177] et [K178]"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 54.0
    }]
  },
  {
    "code" : "A047",
    "display" : "Autopsie adulte (> 15 ans et 3 mois) : cerveau",
    "property" : [{
      "code" : "parent",
      "valueCode" : "01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Examen macroscopique et histologique après bloc paraffine du cerveau"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 33.6
    }]
  },
  {
    "code" : "P067",
    "display" : "Mesure d'une activité enzymatique par méthode utilisant un substrat isotopique",
    "property" : [{
      "code" : "parent",
      "valueCode" : "16-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Cotation limitée à un maximum de 8 enzymes. Indication: enzyme(s) connue(s) pour être en lien avec la pathologie héréditaire recherchée."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 324.0
    }]
  },
  {
    "code" : "K106",
    "display" : "Calcitonine (dosage) (liquides biologiques autres que sang, ponctions)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-07"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "En attente d'une modification potentielle du libellé de l'acte NABM [1132] prenant en compte les autres liquides biologiques que le sang."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 37.8
    }]
  },
  {
    "code" : "07-01",
    "display" : "allergie",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07"
    },
    {
      "code" : "type",
      "valueString" : "Sous-chapitre"
    },
    {
      "code" : "child",
      "valueCode" : "G161"
    },
    {
      "code" : "child",
      "valueCode" : "G195"
    },
    {
      "code" : "child",
      "valueCode" : "G160"
    }]
  },
  {
    "code" : "J103",
    "display" : "Activité TPMT (Thio-purine-méthyl transférase) érythrocytaire",
    "property" : [{
      "code" : "parent",
      "valueCode" : "10-03"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Prélèvement EDTA, 4°C, traitement immédiat. Une seule cotation. Comprend: culot globulaire -80°C, dilution 1/2 NaCl 0,9%,  numération GR, réaction enzymatique 1H à 37°C, CLHP gamme étalonnage 5 points incluse."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 67.5
    }]
  },
  {
    "code" : "N941",
    "display" : "Forfait séquençage haut débit (NGS) > 20 kb et < 100 kb",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Selon indications des sociétés savantes. Hors pris en charge par le forfait séquencage de la NABM  [9007]"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 1503.9
    }]
  },
  {
    "code" : "07-03-01",
    "display" : "Bilan d'allo-immunisation",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-03"
    },
    {
      "code" : "type",
      "valueString" : "Sous-chapitre"
    }]
  },
  {
    "code" : "J018",
    "display" : "Métalloprotéases matricielles (MMP-9, TIMP-1)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "10-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Spécialisé"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 32.4
    }]
  },
  {
    "code" : "G070",
    "display" : "PN : NADPH oxydase : dosage du cytochrome b par cytométrie en flux",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-04"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 27.0
    }]
  },
  {
    "code" : "K303",
    "display" : "PHI (-2proPSA + PSA +PSDAL (sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 40.5
    }]
  },
  {
    "code" : "K109",
    "display" : "TBG (Thyroxine Binding Globulin) (Sérum)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 40.5
    }]
  },
  {
    "code" : "I039",
    "display" : "Sulfatoxymélatonine (liquides biologiques sauf sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "09"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Spécialisé"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 37.8
    }]
  },
  {
    "code" : "E119",
    "display" : "tissue Plasminogen Activator (t-PA), activité",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Dosage chromogénique. Une seule cotation. Dépistage d’une anomalie de la fibrinolyse dans un contexte thrombotique\nDépistage d’une hyperfibrinolyse dans un contexte de pathologie hémorragique constitutionnelle"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 27.0
    }]
  },
  {
    "code" : "I100",
    "display" : "Acid-labile subunit (ALS)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "09"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 37.8
    }]
  },
  {
    "code" : "E204",
    "display" : "Mesure de longueur des télomères en cytométrie en flux par une technique de Flow-FISH",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Indications: (i) diagnostic étiologique d’une aplasie médullaire d’allure constitutionnelle, (ii) élimination du diagnostic de Dyskératose Congénitale chez tout patient atteint d’aplasie médullaire avant une greffe de moelle osseuse, (iii) cas frontières d’insuffisances médullaires qui n’ont pas fait la preuve de leur diagnostic, (iv) diagnostic des fibroses pulmonaires familiales ou fibrose pulmonaire du sujet jeune, (v) survenue d’un syndrome myélodysplasique (MDS) chez un sujet jeune (<50 ans) ou antécédents de leucémie aiguë (LA) dans la famille, (vi) hypersensibilité à la chimiothérapie ou absence de réponse au traitement conventionnel de première ligne : sérum antilymphocytaire/cyclosporine."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 414.45
    }]
  },
  {
    "code" : "J104",
    "display" : "Protéine Gs érythrocytaire",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2022-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 81.0
    }]
  },
  {
    "code" : "C024",
    "display" : "Décongélation des tissus germinaux (ovaire ou testicule)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "03"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation en vue d'une analyse tissulaire. Une à cinq cotations pour une décongélation en vue d'utilisation pour la patiente"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 121.5
    }]
  },
  {
    "code" : "08-02",
    "display" : "Sensibilité aux anti-virus",
    "property" : [{
      "code" : "parent",
      "valueCode" : "08"
    },
    {
      "code" : "type",
      "valueString" : "Sous-chapitre"
    },
    {
      "code" : "child",
      "valueCode" : "H007"
    },
    {
      "code" : "child",
      "valueCode" : "H006"
    }]
  },
  {
    "code" : "K302",
    "display" : "Human Epididymis 4  (sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 40.5
    }]
  },
  {
    "code" : "K108",
    "display" : "Thyroglobuline (liquides biologiques autres que sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-07"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "En attente d'une modification potentielle du libellé de l'acte NABM [0821] prenant en compte les autres liquides biologiques que le sang."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 18.9
    }]
  },
  {
    "code" : "C048",
    "display" : "Fixation des globules polaires ou blastomères en vue de DPC ou DPI",
    "property" : [{
      "code" : "parent",
      "valueCode" : "03"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une cotation par échantillon (globule polaire ou blastomère)"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 27.0
    }]
  },
  {
    "code" : "I101",
    "display" : "Insulin-like Growth Factor-II (IGF-II) forme mature",
    "property" : [{
      "code" : "parent",
      "valueCode" : "09"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 37.8
    }]
  },
  {
    "code" : "N151",
    "display" : "Détection par PCR classique ou temps réel simplex de champignons ou parasites (hors diagnostic prénatal de la toxoplasmose et hors les microorganismes inscrits à la NABM)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-2-3"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "La détection par biologie moléculaire, le génotypage des parasites et champignons sont des outils indispensables de diagnostic (grandes sensibilité et spécificité), de suivi thérapeutique (génotypage parfois associé à  une chimiorésistance, et/ou au caractère nosocomial de l'infection). Le caractère eucaryote des ces pathogènes rend souvent plus complex ces approches moléculaires."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 129.6
    }]
  },
  {
    "code" : "N196",
    "display" : "Western blot avec plusieurs Ac",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-1"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "En cas de génome infectieux, hors actes inscrits à la NABM"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 135.0
    }]
  },
  {
    "code" : "K305",
    "display" : "Endocan",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2022-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Dosage immunoenzymatique. Indication: détection précoce du risque de défaillance respiratoire ou syndrome de détresse respiratoire aigu (SDRA) chez le patient de soins intensifs."
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 54.0
    }]
  },
  {
    "code" : "I017",
    "display" : "Hormones hypophysaires (sous-unité alpha des -)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "09"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Spécialisé"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 37.8
    }]
  },
  {
    "code" : "I102",
    "display" : "18 hydroxycortisol",
    "property" : [{
      "code" : "parent",
      "valueCode" : "09"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 32.4
    }]
  },
  {
    "code" : "E117",
    "display" : "Thromboxane B2 (sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation. Marqueur d'efficacité du traitement par aspirine"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 37.8
    }]
  },
  {
    "code" : "N509",
    "display" : "Transcrit de fusion, sarcome d'Ewing",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-3-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Identification d'anomalies spécifiques dans les sarcomes"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 162.0
    }]
  },
  {
    "code" : "14-1",
    "display" : "Analyse élémentaire de biologie moléculaire (analyses réalisables en cas de détection de génome infectieux ou humain)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14"
    },
    {
      "code" : "type",
      "valueString" : "Sous-chapitre"
    },
    {
      "code" : "child",
      "valueCode" : "N196"
    },
    {
      "code" : "child",
      "valueCode" : "N906"
    },
    {
      "code" : "child",
      "valueCode" : "N145"
    },
    {
      "code" : "child",
      "valueCode" : "N195"
    },
    {
      "code" : "child",
      "valueCode" : "N144"
    },
    {
      "code" : "child",
      "valueCode" : "N037"
    }]
  },
  {
    "code" : "E201",
    "display" : "temps de thrombine",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Permet la détection du traitement par dabigatran en 1ère intention pour les laboratoires ne disposant pas de dosage spécifique de la molécule. Pour éliminer la présence de dabigatran dans le cas d'un acte invasif urgent, de chirurgie urgente ou d'hémorragie."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 13.5
    }]
  },
  {
    "code" : "N508",
    "display" : "Forfait mutationnel GIST (KIT/PDGFRA)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-3-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2025-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Non cumulable avec [N507]"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 315.9
    }]
  },
  {
    "code" : "L190",
    "display" : "Dosage du cholestérol LDL (C-LDL) (liquides biologiques autres que sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "12"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2019-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "En attente d'une modification potentielle du libellé de l'acte NABM [2001] prenant en compte les autres liquides biologiques que le sang."
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 8.1
    }]
  },
  {
    "code" : "K304",
    "display" : "Sous unité Béta libre (LCR- sang de cordon)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Utilisation empirique afin de déterminer l'origine d'un foyer tumoral suspect. Rôle en pédiatrie"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 40.5
    }]
  },
  {
    "code" : "A067",
    "display" : "Enzymologie sur coupe ≤ 3 enzymes",
    "property" : [{
      "code" : "parent",
      "valueCode" : "01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une cotation par lame"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 42.0
    }]
  },
  {
    "code" : "I018",
    "display" : "Human Epidermal growth factor Receptor 2 (HER2) soluble",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-07"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 54.0
    }]
  },
  {
    "code" : "E118",
    "display" : "Thromboxane B2 (urines de 24h)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation. Marqueur d'efficacité du traitement par aspirine"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 37.8
    }]
  },
  {
    "code" : "E203",
    "display" : "Génotypage RHCE ET KEL fœtal non invasif par l’analyse de l’ADN fœtal circulant dans le sang maternel",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-03"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Indication: femmes enceintes alloimmunisées pour Rhc, RHC, RHE ou KEL"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 102.6
    }]
  },
  {
    "code" : "E202",
    "display" : "Groupes sanguins en biologie moléculaire",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-03"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Par système de groupe sanguin"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 97.2
    }]
  },
  {
    "code" : "08-01",
    "display" : "Identification et cultures",
    "property" : [{
      "code" : "parent",
      "valueCode" : "08"
    },
    {
      "code" : "type",
      "valueString" : "Sous-chapitre"
    },
    {
      "code" : "child",
      "valueCode" : "H008"
    },
    {
      "code" : "child",
      "valueCode" : "H010"
    },
    {
      "code" : "child",
      "valueCode" : "H012"
    }]
  },
  {
    "code" : "K036",
    "display" : "Dosage fonctionnel du facteur I",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2025-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Examen de 2nde ou 3ième intention ; réalisation technique et interprétation biologique nécessitant une expertise"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 81.0
    }]
  },
  {
    "code" : "M106",
    "display" : "Dosage spécifique d'un barbiturique autre que le phénobarbital par une méthode chromatographique dans un liquide biologique",
    "property" : [{
      "code" : "parent",
      "valueCode" : "13-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Si suspicion d'intoxication"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 40.5
    }]
  },
  {
    "code" : "I051",
    "display" : "Parathormone (1-84 ou bioactive) (liquides biologiques autres que le sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "09"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "En attente d'une modification potentielle du libellé de l'acte NABM [0983] prenant en compte les autres liquides biologiques que le sang."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 18.9
    }]
  },
  {
    "code" : "G252",
    "display" : "Dépistage des Ac anti-HLA de classe I et II par technique sensible",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-03"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Indication : Post-greffe, selon recommandations de l'ABM. Prescriptions principalement en CHU, consultations externes ou hospitalisation. Technique sensible (ELISA, Multiplex, micropuces)"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 54.0
    }]
  },
  {
    "code" : "K012",
    "display" : "Homocystéine totale (liquides biologiques)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Fusion des actes [K012] et [L209]. Intérêt dans bilan de thrombophilie du sujet jeune."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 54.0
    }]
  },
  {
    "code" : "G058",
    "display" : "MAI de peau : anticorps anti-BP230, dosage par ELISA",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 18.9
    }]
  },
  {
    "code" : "J079",
    "display" : "Créatine phosphokinase (CPK) (liquides biologiques autres que sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "10-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "En attente d'une modification potentielle du libellé de l'acte NABM [1520] prenant en compte les autres liquides biologiques que le sang."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 5.4
    }]
  },
  {
    "code" : "L125",
    "display" : "Osmolalité (tous liquides biologiques)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "12"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Fusion des actes [L125], [L157] et [L179]"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 5.4
    }]
  },
  {
    "code" : "E097",
    "display" : "Plasminogen activator inhibitor-1 (PAI-1), Ag",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation. Etude de la fibrinolyse."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 37.8
    }]
  },
  {
    "code" : "P062",
    "display" : "Mesure d'une activité enzymatique par méthode spectrophotométrique ou spectrofluorométrique en l'absence de kit commercial",
    "property" : [{
      "code" : "parent",
      "valueCode" : "16-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Cotation limitée à un maximum de 8 enzymes. Indication: enzyme(s) connue(s) pour être en lien avec la pathologie héréditaire recherchée."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 27.0
    }]
  },
  {
    "code" : "E073",
    "display" : "Complexes thrombine-antithrombine (TAT)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation. Marqueur d'activation de la coagulation (génération de thrombine et son inhibition par l'antithrombine)"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 37.8
    }]
  },
  {
    "code" : "I052",
    "display" : "Insuline (liquides biologiques autres que le sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "09"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "En attente d'une modification potentielle du libellé de l'acte NABM [7422] prenant en compte les autres liquides biologiques que le sang."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 18.9
    }]
  },
  {
    "code" : "G251",
    "display" : "Recherche des Ac anti-lymphocytes par technique de lymphocytotoxicité (IgG+/- IgM)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-03"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Indication: hors greffe. Prescriptions principalement pour évènements post-transfusionnels (en hospitalisation ou HPDD, par CHU, hôpitaux généraux, voire établissements privés)"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 108.0
    }]
  },
  {
    "code" : "M107",
    "display" : "Dosage spécifique d'un neuroleptique par une méthode chromatographique dans un liquide biologique",
    "property" : [{
      "code" : "parent",
      "valueCode" : "13-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Si suspicion d'intoxication"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 40.5
    }]
  },
  {
    "code" : "G057",
    "display" : "MAI de peau : anticorps anti-BP180, dosage par ELISA",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 18.9
    }]
  },
  {
    "code" : "K035",
    "display" : "Dosage fonctionnel du facteur H",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "En attente d'inscription à la NABM"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 81.0
    }]
  },
  {
    "code" : "E098",
    "display" : "Plaquettes : Activation/cisaillement",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation. Marqueur d'efficacité du traitement anti-agrégant par inhibiteurs de P2Y12,  associé aux autres tests : VASP [E140] et  agrégation à ADP [E054]"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 135.0
    }]
  },
  {
    "code" : "N523",
    "display" : "Forfait mutationnel cancer colorectal métastatique (KRAS/NRAS) 6 exons.",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-3-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2025-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Lorsqu'il s'agit d'un acte qui concerne un test de détection des mutations génétiques [Test compagnon], l'acte n'est pas à coder au RAHN car il est inscrit à la CCAM :\nhttps://www.legifrance.gouv.fr/jorf/id/JORFTEXT000048998843"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 440.1
    }]
  },
  {
    "code" : "L100",
    "display" : "Test de perméabilité intestinale (TPI) épreuve mixte lactulose/mannitol",
    "property" : [{
      "code" : "parent",
      "valueCode" : "12"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 35.1
    }]
  },
  {
    "code" : "L124",
    "display" : "Magnésium (liquides biologiques autres que sang et urine)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "12"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "En attente d'une modification potentielle du libellé de l'acte NABM [2012] prenant en compte les autres liquides biologiques que l'urine ou du libellé de l'acte NABM [0584] prenant en compte les autres liquides biologiques que le sang."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 4.05
    }]
  },
  {
    "code" : "P061",
    "display" : "Profil métabolique (liquides biologiques, cellules, tissus)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "16-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 135.0
    }]
  },
  {
    "code" : "01",
    "display" : "Actes d’anatomie et de cytologie pathologiques",
    "property" : [{
      "code" : "parent",
      "valueCode" : "LAHN"
    },
    {
      "code" : "type",
      "valueString" : "Chapitre"
    },
    {
      "code" : "child",
      "valueCode" : "A122"
    },
    {
      "code" : "child",
      "valueCode" : "A047"
    },
    {
      "code" : "child",
      "valueCode" : "A093"
    },
    {
      "code" : "child",
      "valueCode" : "A095"
    },
    {
      "code" : "child",
      "valueCode" : "A121"
    },
    {
      "code" : "child",
      "valueCode" : "A033"
    },
    {
      "code" : "child",
      "valueCode" : "A092"
    },
    {
      "code" : "child",
      "valueCode" : "A086"
    },
    {
      "code" : "child",
      "valueCode" : "A067"
    },
    {
      "code" : "child",
      "valueCode" : "A070"
    },
    {
      "code" : "child",
      "valueCode" : "A120"
    },
    {
      "code" : "child",
      "valueCode" : "A091"
    }]
  },
  {
    "code" : "K038",
    "display" : "Facteur B antigènémie",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "En attente d'inscription à la NABM."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 10.8
    }]
  },
  {
    "code" : "K147",
    "display" : "Détection et/ou titration d'une sensibilisation à un anticorps monoclonal thérapeutique en ELISA",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-04"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Acte  codé par [K147 ou K148] selon l'approche méthodologique utilisée. Ces 2 actes concernent un  panel grandissant de molécules thérapeitiques (biomédicaments) ; il existe aujourd'hui une grande variabilité des performances analytiques et cliniques, spécifiques à chaque anticorps monoclonal thérapeutique ; données avancées pour infliximab et adalimumab. Doit se faire avec l'acte [M053] ou [M054]."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 40.5
    }]
  },
  {
    "code" : "M104",
    "display" : "Génotypage de l'uridine diphosphate-glucuronosyl-transférase 1A1 (UGT1A1) pour ajustement de la dose d'un traitement comprenant de l'irinotécan",
    "property" : [{
      "code" : "parent",
      "valueCode" : "13-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 78.3
    }]
  },
  {
    "code" : "G056",
    "display" : "MAI de peau : extraction et identification des Ac anti-épiderme par Western-blot",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 48.6
    }]
  },
  {
    "code" : "G189",
    "display" : "Dosage des IgG anti-toxine tétanique (réponse vaccinale)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-05"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 27.0
    }]
  },
  {
    "code" : "N459",
    "display" : "Forfait mutationnel leucémies aigues myéloïdes",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-3-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Mutations à impact diagnostique et/ou théranostique des leucémies aiguës myéloblastiques (forfait 2 à 5) : Flt3, NPM, CEBPA. Par cible"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 124.2
    }]
  },
  {
    "code" : "L236",
    "display" : "Dosage d'une lipoprotéine ou lipoparticule hors NABM, toute méthode",
    "property" : [{
      "code" : "parent",
      "valueCode" : "12"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Fusion des actes [L145], [L148], [L149], [L230]."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 35.1
    }]
  },
  {
    "code" : "E095",
    "display" : "Microvésicules, quantification (cytométrie en flux)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation. Facteur de risque associé aux pathologies cardio-vasculaires et à l'évolutivité de certaines tumeurs cancéreuses"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 27.0
    }]
  },
  {
    "code" : "E071",
    "display" : "Complexes plasmine-antiplasmine",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation. Marqueur de la fibrinolyse ayant un intérêt dans les études physiopathologiques évaluant les relation coagulation-fibrinolyse (coagulopathies de consommation dans contextes obstétricaux, traumatiques, septiques…)"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 37.8
    }]
  },
  {
    "code" : "N520",
    "display" : "PCA3 (urines, post toucher rectal): dosage des gènes PSA et PCA3 par TMA (transcription mediated amplification)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-3-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Recueilli dans le premier jet urinaire après toucher rectal."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 297.0
    }]
  },
  {
    "code" : "H012",
    "display" : "Recherche de Norovirus par immunocapture : détection rapide dans les selles",
    "property" : [{
      "code" : "parent",
      "valueCode" : "08-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 18.9
    }]
  },
  {
    "code" : "P060",
    "display" : "Dosage d'un métabolite isolé par technique spécifique (tous liquides biologiques, cellules, tissus)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "16-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Cotation limitée à un maximum de 4 métabolites. Par méthode spectrophotométrique, spectrofluorométrique, séparative ou immunologique. Indication: métabolite(s) connu(s)  pour être en lien avec la pathologie héréditaire recherchée"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 32.4
    }]
  },
  {
    "code" : "I054",
    "display" : "Endothéline (liquides biologiques)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "09"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Spécialisé"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 37.8
    }]
  },
  {
    "code" : "K146",
    "display" : "Dosage ultrasensible des sous-classes d'immunoglobuline G",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-04"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Par sous-classe"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 27.0
    }]
  },
  {
    "code" : "G140",
    "display" : "AC neutralisant anti IFN-alpha",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-04"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 40.5
    }]
  },
  {
    "code" : "M105",
    "display" : "Recherche, identification et dosages des benzodiazépines par une méthode chromatographique dans un liquide biologique",
    "property" : [{
      "code" : "parent",
      "valueCode" : "13-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Au moins 20 molécules recherchées et dosées"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 54.0
    }]
  },
  {
    "code" : "G079",
    "display" : "PN : étude du cytosquelette",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-04"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2022-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 108.0
    }]
  },
  {
    "code" : "L235",
    "display" : "Etude d'une apoprotéine, toute méthode,",
    "property" : [{
      "code" : "parent",
      "valueCode" : "12"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Fusion des actes [L035], [L167], [L168], [L169], [L174]."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 54.0
    }]
  },
  {
    "code" : "L017",
    "display" : "Cystatine C (sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "12"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Fusion des actes [L017] et [L061]."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 27.0
    }]
  },
  {
    "code" : "E096",
    "display" : "Plasminogen activator inhibitor-1 (PAI-1), activité (dosage chromogénique)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation. Etude de la fibrinolyse."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 27.0
    }]
  },
  {
    "code" : "J010",
    "display" : "Gamma glutamyl transférase (GGT) (liquides biologiques autres que sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "10-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "En attente d'une modification potentielle du libellé de l'acte NABM [0519] prenant en compte les autres liquides biologiques que le sang."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 5.4
    }]
  },
  {
    "code" : "K016",
    "display" : "Albumine modifiée (IMA)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2019-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 27.0
    }]
  },
  {
    "code" : "03",
    "display" : "Assistance médicale à la procréation (A.M.P.)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "LAHN"
    },
    {
      "code" : "type",
      "valueString" : "Chapitre"
    },
    {
      "code" : "child",
      "valueCode" : "C009"
    },
    {
      "code" : "child",
      "valueCode" : "C004"
    },
    {
      "code" : "child",
      "valueCode" : "C100"
    },
    {
      "code" : "child",
      "valueCode" : "C012"
    },
    {
      "code" : "child",
      "valueCode" : "C041"
    },
    {
      "code" : "child",
      "valueCode" : "C048"
    },
    {
      "code" : "child",
      "valueCode" : "C011"
    },
    {
      "code" : "child",
      "valueCode" : "C024"
    },
    {
      "code" : "child",
      "valueCode" : "C013"
    },
    {
      "code" : "child",
      "valueCode" : "C042"
    },
    {
      "code" : "child",
      "valueCode" : "C017"
    },
    {
      "code" : "child",
      "valueCode" : "C044"
    },
    {
      "code" : "child",
      "valueCode" : "C022"
    },
    {
      "code" : "child",
      "valueCode" : "C043"
    },
    {
      "code" : "child",
      "valueCode" : "C045"
    }]
  },
  {
    "code" : "P066",
    "display" : "Mesure d'une activité enzymatique par quantification du substrat ou du produit de technique séparative",
    "property" : [{
      "code" : "parent",
      "valueCode" : "16-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Cotation limitée à un maximum de 8 enzymes. Indication: enzyme(s) connue(s) pour être en lien avec la pathologie héréditaire recherchée."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 135.0
    }]
  },
  {
    "code" : "G078",
    "display" : "PN : bactéricidie",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-04"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 256.5
    }]
  },
  {
    "code" : "16-02",
    "display" : "Diagnostic biologique des maladies génétiques constitutionnelles",
    "property" : [{
      "code" : "parent",
      "valueCode" : "16"
    },
    {
      "code" : "type",
      "valueString" : "Sous-chapitre"
    }]
  },
  {
    "code" : "G054",
    "display" : "MAI du système nerveux périphérique : titrage des Ac anti-MAG par ELISA",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 18.9
    }]
  },
  {
    "code" : "C009",
    "display" : "Congélation du tissu testiculaire",
    "property" : [{
      "code" : "parent",
      "valueCode" : "03"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 189.0
    }]
  },
  {
    "code" : "I079",
    "display" : "Cortisol libre (sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "09"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Dosage par colonne filtration"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 37.8
    }]
  },
  {
    "code" : "H010",
    "display" : "Recherche directe par EIA: tous virus\nà l'exception de ceux notés à la NABM:\nadenovirus (4206), arenavirus (4213), astrovirus (4218), calcivirus, herpès simplex (4506), varicelle & zona (4507), grippe A & B (4241), parainfluenzae (4244), respiratoire syncitial (4247), oreillons (4251), rage (4260), rougeole (4263), rotavirus (4267)",
    "designation" : [{
      "language" : "fr",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009",
        "display" : "Synonym"
      },
      "value" : "Recherche directe par EIA: tous virus\nà l'exception de ceux notés à la NABM:\nadenovirus (4206), arenavirus (4213), astrovirus (4218), calcivirus, herpès simplex (4229), varicelle & zona (4233), grippe A & B (4241), parainfluenzae (4244), respiratoire syncitial (4247), oreillons (4251), rage (4260), rougeole (4263), rotavirus (4267)"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "08-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 18.9
    }]
  },
  {
    "code" : "N417",
    "display" : "Recherche ou quantification de la mutation  JAK2_V617F par PCR",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-3-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 116.1
    }]
  },
  {
    "code" : "N502",
    "display" : "Perte d'hétérozygotie, 1p19q",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-3-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Prise en charge des gliomes"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 183.6
    }]
  },
  {
    "code" : "E093",
    "display" : "Marqueurs d'activation plaquettaire (cytométrie en flux) : par Ac/ligand",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation. Conférence de consensus \"standardisation de l'exploration des pathologies plaquettaires\" (février 2009) du Centre de référence des pathologies plaquettaires : examen de niveau 2 (confirmation d'une orientation diagnostique)"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 27.0
    }]
  },
  {
    "code" : "J120",
    "display" : "Macro-enzymes (amylase, lipase, ALAT ou  ASAT) (sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "10-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Fusion des actes [J001],[J005],[J007] et [J089]"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 27.0
    }]
  },
  {
    "code" : "J011",
    "display" : "Créatine kinase (CK) isoenzymes",
    "property" : [{
      "code" : "parent",
      "valueCode" : "10-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 16.2
    }]
  },
  {
    "code" : "K148",
    "display" : "Détection et/ou titration d'une sensibilisation à un anticorps monoclonal thérapeutique en cytométrie",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-04"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "cf. commentaires acte [K147]"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 81.0
    }]
  },
  {
    "code" : "02",
    "display" : "Actes de cytogénétique",
    "property" : [{
      "code" : "parent",
      "valueCode" : "LAHN"
    },
    {
      "code" : "type",
      "valueString" : "Chapitre"
    },
    {
      "code" : "child",
      "valueCode" : "B101"
    },
    {
      "code" : "child",
      "valueCode" : "B034"
    },
    {
      "code" : "child",
      "valueCode" : "B050"
    },
    {
      "code" : "child",
      "valueCode" : "B049"
    },
    {
      "code" : "child",
      "valueCode" : "B100"
    }]
  },
  {
    "code" : "K015",
    "display" : "L-dopa",
    "property" : [{
      "code" : "parent",
      "valueCode" : "09"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Spécialisé"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 54.0
    }]
  },
  {
    "code" : "G053",
    "display" : "MAI du système nerveux périphérique : titrage des Ac anti-gangliosides GM1 d'isotype IgM",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 18.9
    }]
  },
  {
    "code" : "16-01",
    "display" : "Diagnostic biologique des maladies héréditaires du métabolisme",
    "property" : [{
      "code" : "parent",
      "valueCode" : "16"
    },
    {
      "code" : "type",
      "valueString" : "Sous-chapitre"
    },
    {
      "code" : "child",
      "valueCode" : "P068"
    },
    {
      "code" : "child",
      "valueCode" : "P050"
    },
    {
      "code" : "child",
      "valueCode" : "P063"
    },
    {
      "code" : "child",
      "valueCode" : "P057"
    },
    {
      "code" : "child",
      "valueCode" : "P052"
    },
    {
      "code" : "child",
      "valueCode" : "P065"
    },
    {
      "code" : "child",
      "valueCode" : "P060"
    },
    {
      "code" : "child",
      "valueCode" : "P059"
    },
    {
      "code" : "child",
      "valueCode" : "L027"
    },
    {
      "code" : "child",
      "valueCode" : "P054"
    },
    {
      "code" : "child",
      "valueCode" : "P067"
    },
    {
      "code" : "child",
      "valueCode" : "P062"
    },
    {
      "code" : "child",
      "valueCode" : "L150"
    },
    {
      "code" : "child",
      "valueCode" : "P056"
    },
    {
      "code" : "child",
      "valueCode" : "P070"
    },
    {
      "code" : "child",
      "valueCode" : "P069"
    },
    {
      "code" : "child",
      "valueCode" : "P051"
    },
    {
      "code" : "child",
      "valueCode" : "P064"
    },
    {
      "code" : "child",
      "valueCode" : "P058"
    },
    {
      "code" : "child",
      "valueCode" : "P053"
    },
    {
      "code" : "child",
      "valueCode" : "P066"
    },
    {
      "code" : "child",
      "valueCode" : "P061"
    },
    {
      "code" : "child",
      "valueCode" : "P055"
    }]
  },
  {
    "code" : "K100",
    "display" : "Alpha-fœtoprotéine (AFP) (dosage) (liquides biologiques autres que sang, ponctions)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-07"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Fusion des actes [K100] et [K101] en attente d'une modification potentielle du libellé de l'acte NABM [0320] prenant en compte les autres liquides biologiques que le sang."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 18.9
    }]
  },
  {
    "code" : "I056",
    "display" : "18 Hydroxydésoxycorticostérone (18 OHDOC) (sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "09"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Spécialisé"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 32.4
    }]
  },
  {
    "code" : "J036",
    "display" : "Enzyme de conversion de l'angiotensine (liquides biologiques autres que sang, ponctions)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "10-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Fusion des actes [J036] et [J037] en attente d'une modification potentielle du libellé de l'acte NABM [0523] prenant en compte les autres liquides biologiques que le sang et les ponctions."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 40.5
    }]
  },
  {
    "code" : "N503",
    "display" : "Séquençage EGFR : 2 exons",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-3-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2025-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Indication : suivi des adénocarcinomes du poumon métastatiques traités par inhibiteurs de tyrosine kinase : détection de la mutation activatrice connue et de résistance p.T790M"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 180.9
    }]
  },
  {
    "code" : "L128",
    "display" : "Cristaux (recherche) (biopsie)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "12"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 162.0
    }]
  },
  {
    "code" : "E094",
    "display" : "Microvésicules, origine cellulaire (cytométrie en flux) : par Ac/ligand",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation. Nouveau biomarqueur de fibrinolyse, remodelage vasculaire, angiogénese, thrombose et métastase tumorale"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 27.0
    }]
  },
  {
    "code" : "P065",
    "display" : "Mesure d'une activité enzymatique par méthode spectrophotométrique ou spectrofluorométrique nécessitant la synthèse d'un substrat spécifique",
    "property" : [{
      "code" : "parent",
      "valueCode" : "16-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Cotation limitée à un maximum de 8 enzymes. Indication: enzyme(s) connue(s) pour être en lien avec la pathologie héréditaire recherchée. (Exemple  enzymes de la voie de biosynthèse de l'hème)"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 405.0
    }]
  },
  {
    "code" : "E070",
    "display" : "Complexes plaquettes-leucocytes (cytométrie)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une cotation par anticorps. Marqueur de risque cardio-vasculaire"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 27.0
    }]
  },
  {
    "code" : "J012",
    "display" : "Lactate déshydrogénase (LDH) (érythrocytaire et musculaire)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "10-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Fusion des actes [J012] et [J077] en attente de fusion potentielle des actes NABM [0521]et [1521] et d'une modification potentielle du libellé de l'acte résultant prenant en compte les origines érythrocytaire et musculaire."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 13.5
    }]
  },
  {
    "code" : "J121",
    "display" : "LDH isoenzymes (liquides biologiques)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "10-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Fusion des actes [J013],[J014] et [J080]"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 16.2
    }]
  },
  {
    "code" : "K127",
    "display" : "Cyfra 21-1 (dosage)(liquides biologiques autres que sang, ponctions)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-07"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "En attente d'une modification potentielle du libellé de l'acte NABM [0822] prenant en compte les autres liquides biologiques que le sang."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 29.7
    }]
  },
  {
    "code" : "M108",
    "display" : "Recherche, identification et dosage des composés d'une classe thérapeutique non nommément inscrite, par une méthode chromatographique dans un liquide biologique",
    "property" : [{
      "code" : "parent",
      "valueCode" : "13-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 67.5
    }]
  },
  {
    "code" : "K103",
    "display" : "Ag CA 19-9 (liquides biologiques autres que sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-07"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "En attente d'une modification potentielle du libellé de l'acte NABM [7323] prenant en compte les autres liquides biologiques que le sang."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 21.6
    }]
  },
  {
    "code" : "05",
    "display" : "Hématologie",
    "property" : [{
      "code" : "parent",
      "valueCode" : "LAHN"
    },
    {
      "code" : "type",
      "valueString" : "Chapitre"
    },
    {
      "code" : "child",
      "valueCode" : "05-02"
    },
    {
      "code" : "child",
      "valueCode" : "05-01"
    },
    {
      "code" : "child",
      "valueCode" : "05-03"
    }]
  },
  {
    "code" : "G052",
    "display" : "MAI du système nerveux périphérique : titrage des Ac anti-gangliosides GM1 d'isotype IgG",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 18.9
    }]
  },
  {
    "code" : "G161",
    "display" : "Profil de sensibilisation IgE spécifiques par micropuce",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Réservé à un problème clinique sévère et non productivité des dosages classiques d'IgE monospécifiques. Encadrement pour le contrôle de la prescription et des étapes analytiques et post-analytiques"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 216.0
    }]
  },
  {
    "code" : "Q044",
    "display" : "Quantification et qualification de progéniteurs mésenchymateux par culture",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Hors préparation de médicaments de thérapie innovante (dont produit de thérapie cellulaire)"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 94.5
    }]
  },
  {
    "code" : "G076",
    "display" : "PN :Explosion oxydative : chimioluminescence",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-04"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Acte devant être encadré pour sa prescription et les étapes pré et post analytiques. Par condition"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 81.0
    }]
  },
  {
    "code" : "L107",
    "display" : "FLM- test (surfactant pulmonaire)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "12"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation. Sur prélèvement trachéal chez les prématurés. Détermination rapide du surfactant pulmonaire par polarisation de fluorescence."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 91.8
    }]
  },
  {
    "code" : "N524",
    "display" : "Forfait mutationnel adénocarcinome du poumon métastatique (EGFR/KRAS)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-3-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2025-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Lorsqu'il s'agit d'un acte qui concerne un test de détection des mutations génétiques [Test compagnon], l'acte n'est pas à coder au RAHN car il est inscrit à la CCAM :\nhttps://www.legifrance.gouv.fr/jorf/id/JORFTEXT000048998843"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 459.0
    }]
  },
  {
    "code" : "N500",
    "display" : "Instabilité microsatellitaire",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-3-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 162.0
    }]
  },
  {
    "code" : "P064",
    "display" : "Mesure d'une activité enzymatique par méthode spectrophotométrique ou spectrofluorométrique nécessitant une technique spécifique et/ou un substrat couteux",
    "property" : [{
      "code" : "parent",
      "valueCode" : "16-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Cotation limitée à un maximum de 8 enzymes. Indication: enzyme(s) connue(s) pour être en lien avec la pathologie héréditaire recherchée. Substrat couteux à préciser"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 135.0
    }]
  },
  {
    "code" : "E091",
    "display" : "Kininogène de haut poids moléculaire, activité",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation. A réserver à centre de référence ou centre expert."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 13.5
    }]
  },
  {
    "code" : "K017",
    "display" : "Albumine (liquides biologiques autres que le sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Fusion des actes [K017] et [K018] en attente d'une modification potentielle du libellé de l'acte NABM [1806] prenant en compte les autres liquides biologiques que le sang."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 2.7
    }]
  },
  {
    "code" : "I010",
    "display" : "Hormones glycoprotéiques (sous-unité alpha des -)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "09"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Spécialisé"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 37.8
    }]
  },
  {
    "code" : "K102",
    "display" : "Ag CA 15-3 (liquides biologiques autres que sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-07"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "En attente d'une modification potentielle du libellé de l'acte NABM [7321] prenant en compte les autres liquides biologiques que le sang."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 20.25
    }]
  },
  {
    "code" : "M109",
    "display" : "Recherche, identification et dosage des composés de la soumission chimique par des méthodes chromatographiques couplées à la spectrométrie de masse dans un liquide biologique",
    "property" : [{
      "code" : "parent",
      "valueCode" : "13-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Recherche obligatoires de toutes les benzodiazépines commercialisées et leurs principaux métabolites, les apparentés aux benzodiazépines tels zolpidem et zopiclone, les barbituriques, l'acool, l'acide"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 270.0
    }]
  },
  {
    "code" : "04",
    "display" : "Spermiologie",
    "property" : [{
      "code" : "parent",
      "valueCode" : "LAHN"
    },
    {
      "code" : "type",
      "valueString" : "Chapitre"
    },
    {
      "code" : "child",
      "valueCode" : "D100"
    }]
  },
  {
    "code" : "G075",
    "display" : "PN : Explosion oxydative : réduction du Nitrobleu de tétrazolium (NBT)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-04"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Acte devant être encadré pour sa prescription et les étapes pré et post analytiques"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 102.6
    }]
  },
  {
    "code" : "G160",
    "display" : "IgE totales lacrymales",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Ceci permet de diagnostiquer une allergie dans certains tableaux de conjonctivite ou kérato-conjonctivite, en particulier : - lorsque le dosage des IgE spécifiques sériques et les tests cutanés de type prick-tests sont pris en défaut pour confirmer la nature allergique de la conjonctivite, ce qui est souvent le cas, particulièrement dans les kérato-conjonctivites vernales et atopiques qui sont responsables d'une altération importante de la qualité de vie et peuvent mettre en jeu le pronostic visuel. Prélèvement des larmes par aspiration à la pipette de transfert et dosage quantitatif des IgE totales puis calcul du rapport IgE totales lacrymales dosées/filtrées. Encadrement  pour le contrôle de la prescription et des étapes analytiques et post-analytiques"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 13.5
    }]
  },
  {
    "code" : "I058",
    "display" : "18 Hydroxycorticostérone (18 OHB) (sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "09"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Spécialisé"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 32.4
    }]
  },
  {
    "code" : "I034",
    "display" : "POMC (Proopiomélanocortine)  (sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "09"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 54.0
    }]
  },
  {
    "code" : "N525",
    "display" : "Forfait mutationnel mélanome (BRAF V600/NRAS)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-3-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2025-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Non cumulable avec  [N501]\net\nLorsqu'il s'agit d'un acte qui concerne un test de détection des mutations génétiques [Test compagnon], l'acte n'est pas à coder au RAHN car il est inscrit à la CCAM :\nhttps://www.legifrance.gouv.fr/jorf/id/JORFTEXT000048998843"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 329.4
    }]
  },
  {
    "code" : "N501",
    "display" : "Recherche de la mutation BRAF V600 par technique moléculaire",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-3-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Dans le mélanome non résécable ou métastatique, le CBNPC et le cancer colorectal, le test pour thérapie ciblé (test compagnon) n'est pas à coder au RIHN, car il est inscrit à la NABM et à la CCAM"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 116.1
    }]
  },
  {
    "code" : "P063",
    "display" : "Mesure d'une activité enzymatique par méthode spectrophotométrique ou spectrofluorométrique nécessitant un substrat spécifique et/ou l'emploi d'une réaction d'inhibition",
    "property" : [{
      "code" : "parent",
      "valueCode" : "16-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Cotation limitée à un maximum de 8 enzymes. Indication: enzyme(s) connue(s) pour être en lien avec la pathologie héréditaire recherchée."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 54.0
    }]
  },
  {
    "code" : "E092",
    "display" : "Libération de sérotonine marquée\ninclus: isolement des plaquettes + marquage + stimulation + mesure\nNota: différents inducteurs inclus (HNF,HBPM…)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Différents inducteurs inclus (HNF,HBPM…). Une seule cotation. Gold standard de diagnostic de confirmation de thrombopénie induite par l'héparine de type 2"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 67.5
    }]
  },
  {
    "code" : "N005",
    "display" : "Sélection et préparation d'un échantillon tissulaire fixé et inclus en paraffine pour analyse de génétique somatique des cancers",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-3-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2025-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Inclut le compte rendu signé par un anatomocytopathologiste"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 56.0
    }]
  },
  {
    "code" : "K173",
    "display" : "NGAL (neutrophil gelatinase associated lipocalin)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 40.5
    }]
  },
  {
    "code" : "N138",
    "display" : "RT-PCR temps réel qualitative simplex en 1 étape sur ARN infectieux",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Inclus tous types d’extraction, contrôle interne, contrôle cellulaire, analyse des données. Selon indications des sociétés savantes. Hors actes inscrits à la NABM [4101], [4102], [5256], [4120], [4122], [4128], [0805], [0806], [4123], [4124], [4125], [4126], [4118], [4119], [4127], [4121], [5258], [5257], [1307], [5262], [4718], [5259], [1254], [3254], [5260], [4273], [1255], [3255], [5261], [5263], [5264], [5265], [5271], [5272], [5237], [5273]"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 108.0
    }]
  },
  {
    "code" : "M025",
    "display" : "Dosage d’un métabolite utile à l'interprétation pharmacologique et/ou toxicologique",
    "property" : [{
      "code" : "parent",
      "valueCode" : "13-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Limité à 1 métabolite"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 32.4
    }]
  },
  {
    "code" : "M001",
    "display" : "Dosage d'un antibactérien non nomément inscrit par une méthode chromatographique dans un liquide biologique",
    "property" : [{
      "code" : "parent",
      "valueCode" : "13-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "En attente d'une modification potentielle du libellé de l'acte NABM [1650] prenant en compte les autres antibactériens et liquides biologiques que le sang. Hors méthode bactériologique."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 40.5
    }]
  },
  {
    "code" : "G236",
    "display" : "Recherche d’anticorps IgM par IF (Générique tous virus, à l'exception de ceux déjà mentionnés explicitement dans la NABM)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-07"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 16.2
    }]
  },
  {
    "code" : "M110",
    "display" : "Dosage d'un alcool autre que l'éthanol dans un liquide biologique",
    "property" : [{
      "code" : "parent",
      "valueCode" : "13-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 13.5
    }]
  },
  {
    "code" : "K197",
    "display" : "Dosage du composant sC5b9",
    "designation" : [{
      "language" : "fr",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009",
        "display" : "Synonym"
      },
      "value" : "Dosages des fragments d’activation du Complément, C5a, C3a, soluble C5b9,  Bb (par protéine)"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "En attente d'incription à la NABM"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 18.9
    }]
  },
  {
    "code" : "K088",
    "display" : "Vitamine B1 (thiamine diphosphate)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-06"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2022-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Reco HAS (cf. chirurgie bariatrique, phénylcétonurie)"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 29.7
    }]
  },
  {
    "code" : "E057",
    "display" : "Alpha-2-antiplasmine, Ag",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation. A réaliser seulement si [E056] est diminué. A réserver à centre de référence ou centre expert."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 37.8
    }]
  },
  {
    "code" : "G128",
    "display" : "Avidité IgG  (tous virus)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-07"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 32.4
    }]
  },
  {
    "code" : "14-2-3",
    "display" : "détection du génome parasitaire ou fongique",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-2"
    },
    {
      "code" : "type",
      "valueString" : "Sous-chapitre"
    },
    {
      "code" : "child",
      "valueCode" : "N151"
    },
    {
      "code" : "child",
      "valueCode" : "N152"
    },
    {
      "code" : "child",
      "valueCode" : "N154"
    }]
  },
  {
    "code" : "E033",
    "display" : "Facteur de croissance : VEGF",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 27.0
    }]
  },
  {
    "code" : "L044",
    "display" : "Chylomicrons (sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "12"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 10.8
    }]
  },
  {
    "code" : "J083",
    "display" : "Lipoprotéine phospholipase A2 : Lp-PLA2",
    "property" : [{
      "code" : "parent",
      "valueCode" : "10"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 67.5
    }]
  },
  {
    "code" : "L177",
    "display" : "Pré-béta-HDL",
    "property" : [{
      "code" : "parent",
      "valueCode" : "12"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 118.8
    }]
  },
  {
    "code" : "L020",
    "display" : "LDL oxydés (sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "12"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2019-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 40.5
    }]
  },
  {
    "code" : "F039",
    "display" : "Recherche d'autres parasites que ceux inscrits à la NABM par culture",
    "property" : [{
      "code" : "parent",
      "valueCode" : "06-05"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 54.0
    }]
  },
  {
    "code" : "N115",
    "display" : "Identification d’espèce bactérienne par détermination de séquence de l’ARN16 S ou autre gène (séquençage sur les deux brins)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-2-1"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Inclus: extraction choc thermique + PCR + RT + purification colonne + séquençage 2 brins + analyse données"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 137.7
    }]
  },
  {
    "code" : "N006",
    "display" : "Sélection et préparation d'un échantillon tissulaire congelé pour analyse de génétique somatique des cancers",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-3-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2025-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Inclut le compte rendu signé par un anatomocytopathologiste"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 84.0
    }]
  },
  {
    "code" : "N139",
    "display" : "RT-PCR temps réel quantitative simplex en 1 étape ARN infectieux",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Inclus tous types d’extraction, contrôle interne, contrôle cellulaire, analyse des données. Selon indications des sociétés savantes. Hors actes inscrits à la NABM [4101], [4102], [5256], [4120], [4122], [4128], [0805], [0806], [4123], [4124], [4125], [4126], [4118], [4119], [4127], [4121], [5258], [5257], [1307], [5262], [4718], [5259], [1254], [3254], [5260], [4273], [1255], [3255], [5261], [5263], [5264], [5265], [4506]  [5269], [5301], [5302], [5303], [5271], [5272], [5237], [5273]"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 116.1
    }]
  },
  {
    "code" : "K196",
    "display" : "C1r, C1s, C2, antigénémie",
    "designation" : [{
      "language" : "fr",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009",
        "display" : "Synonym"
      },
      "value" : "C1r, C1s, C2, MBL, antigénémie"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une cotation par protéine.\nEn attente d'inscription à la NABM."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 27.0
    }]
  },
  {
    "code" : "M111",
    "display" : "Dosage d'acétone dans un liquide biologique",
    "property" : [{
      "code" : "parent",
      "valueCode" : "13-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 13.5
    }]
  },
  {
    "code" : "M002",
    "display" : "Dosage d'un antifongique par une méthode chomatographique dans un liquide biologique",
    "property" : [{
      "code" : "parent",
      "valueCode" : "13-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 40.5
    }]
  },
  {
    "code" : "G126",
    "display" : "Autres sérologies parasitaires ou fongiques rares (autres que AC anti-Saccharomyces)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-06"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Différentes parasitoses rares peuvent être diagnostiquées par sérologie : par exemple la gnathostomose, l'angyostrongilose, …"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 32.4
    }]
  },
  {
    "code" : "G235",
    "display" : "Recherche d’anticorps IgM par EIA (Générique tous virus, à l'exception de ceux déjà mentionnés explicitement dans la NABM)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-07"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 18.9
    }]
  },
  {
    "code" : "14-2-2",
    "display" : "détection du génome viral",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-2"
    },
    {
      "code" : "type",
      "valueString" : "Sous-chapitre"
    },
    {
      "code" : "child",
      "valueCode" : "N935"
    },
    {
      "code" : "child",
      "valueCode" : "N142"
    },
    {
      "code" : "child",
      "valueCode" : "N149"
    },
    {
      "code" : "child",
      "valueCode" : "N133"
    },
    {
      "code" : "child",
      "valueCode" : "N934"
    },
    {
      "code" : "child",
      "valueCode" : "N141"
    },
    {
      "code" : "child",
      "valueCode" : "N143"
    }]
  },
  {
    "code" : "07-03-02-01",
    "display" : "Typages HLA",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-03-02"
    },
    {
      "code" : "type",
      "valueString" : "Sous-chapitre"
    }]
  },
  {
    "code" : "G018",
    "display" : "Identification d'autres Ac anti-Ag nucléaires solubles SCL70, JO1, KU, PCNA, PMSCL, Mi2...",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Par spécificité. cotation maximum 2 spécificités. Par marqueur isotopique ou non."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 18.9
    }]
  },
  {
    "code" : "E034",
    "display" : "Dosage de l'Hémoglobine S (Dosage HbS)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2019-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "En attente de l'intégration potentielle au sein de l'acte NABM [1118]"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 16.2
    }]
  },
  {
    "code" : "L176",
    "display" : "Phénotypage des apolipoprotéines C et E par isofocalisation",
    "property" : [{
      "code" : "parent",
      "valueCode" : "12"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 81.0
    }]
  },
  {
    "code" : "F038",
    "display" : "Recherche de Leishmanies : (culture)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "06-05"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Isolement sur milieu axénique. Technique indispensable pour l'isolement de la souche de Leishmanie."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 54.0
    }]
  },
  {
    "code" : "L043",
    "display" : "Bêta hydroxybutyrate",
    "property" : [{
      "code" : "parent",
      "valueCode" : "12"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 8.1
    }]
  },
  {
    "code" : "K151",
    "display" : "Dosage de cytokines : test biologique",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-05"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Même acte et même remarque que pour les actes [K054] et [K055], mais il s'agit ici de l'étude fonctionnelle sur lignées cellulaires (méthode de référence)"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 81.0
    }]
  },
  {
    "code" : "G210",
    "display" : "Test de prolifération par mesure de la dilution du CFSE ou le degré d’incorporation de l'EdU par cytométrie en flux",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-04"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Pour une stimulation. 10 stimulations maximum. Acte devant être encadré pour sa prescription et les étapes pré et post analytiques"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 54.0
    }]
  },
  {
    "code" : "K199",
    "display" : "Recherche et quantification d'anticorps anti-protéine du complément : anti-C1q, anti-C1inh ou anti-Facteur H",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une cotation par protéine cible et par isotype. \nEn attente d'inscription à la NABM."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 18.9
    }]
  },
  {
    "code" : "G258",
    "display" : "Identification des Ac anti-HLA de classe II par technique sensible sur cibles HLA isolées",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-03"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Indication : Post-greffe, selon recommandations de l'ABM. Prescriptions principalement en CHU, consultations externes ou hospitalisation. Technique sensible (ELISA, Multiplex, micropuces)"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 324.0
    }]
  },
  {
    "code" : "G016",
    "display" : "MAI nso : Ac anti Ag nucléaires solubles : dépistage (par électrosynérèse)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 13.5
    }]
  },
  {
    "code" : "G234",
    "display" : "Sérodiagnostic des Mimivirus, Mamavirus + Sputnik, virus T19, Sénégal Virus : titrage + itératif",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-07"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2022-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Non cumulable avec [G232]"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 24.3
    }]
  },
  {
    "code" : "G125",
    "display" : "Infection parasitaire ou fongique non nommément inscrite a la NABM: diagnostic par IE (Western blot)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-06"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Importance des approches de Western blot dans le serodiagnostic parasitaire"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 48.6
    }]
  },
  {
    "code" : "14-2-1",
    "display" : "détection du génome bactérien",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-2"
    },
    {
      "code" : "type",
      "valueString" : "Sous-chapitre"
    },
    {
      "code" : "child",
      "valueCode" : "N118"
    },
    {
      "code" : "child",
      "valueCode" : "N115"
    },
    {
      "code" : "child",
      "valueCode" : "N117"
    },
    {
      "code" : "child",
      "valueCode" : "N120"
    },
    {
      "code" : "child",
      "valueCode" : "N119"
    }]
  },
  {
    "code" : "E079",
    "display" : "Facteur tissulaire circulant, Ag",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation. Marqueur d'hypercoagulabilité, associé aux pathologies thrombotiques et cancéreuses."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 37.8
    }]
  },
  {
    "code" : "E140",
    "display" : "VASP (vasodilator-stimulated phosphoprotein) (dosage)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation. Marqueur d'efficacité du traitement anti-agrégant par inhibiteurs de P2Y12,  associé aux autres tests : agregation à ADP [E054] et agrégation induite par les taux de cisaillement [E098]"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 54.0
    }]
  },
  {
    "code" : "L022",
    "display" : "Phospholipides (liquide biologiques)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "12"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Fusion des actes [L022] et [L192]"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 8.1
    }]
  },
  {
    "code" : "L046",
    "display" : "Glutathion érythrocytaire total (sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "10-03"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 13.5
    }]
  },
  {
    "code" : "J085",
    "display" : "Activité LCAT (lécithine cholestérol acyl transférase)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "10-04"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Méthode de Nagasaki et Ajanuma. Spécialisé."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 27.0
    }]
  },
  {
    "code" : "N354",
    "display" : "Détection de mutations par expansion de microsatellites",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-3-1"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 137.7
    }]
  },
  {
    "code" : "G233",
    "display" : "Sérodiagnostic de dépistage des des Mimivirus, Mamavirus + Sputnik, virus T19, Sénégal Virus",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-07"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2022-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 10.8
    }]
  },
  {
    "code" : "K174",
    "display" : "Vitamine C leucocytaire",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-06"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2019-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Spécialisé"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 91.8
    }]
  },
  {
    "code" : "G039",
    "display" : "Auto-Ac anti-transglutaminase IgA en radioligand assay",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 81.0
    }]
  },
  {
    "code" : "G015",
    "display" : "MAI nso : Ac anti-ADN natif par ELISA. Détermination d'un autre isotype que l'acte NABM [1455].",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Cas particulier des nouveaux traitements immunomodulateurs pouvant induire la synthèse de ce type d'anticorps. Intérêt = montrer que IgM peu de valeur. Non cumulable avec l'acte NABM [1454]"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 18.9
    }]
  },
  {
    "code" : "G124",
    "display" : "Toxoplasmose : profils immunologiques comparés compartiment / sérum par enzyme-linked-immunofiltration assay (ELIFA) ou par immuno-empreinte (WB)    pour un isotype",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-06"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2020-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Maximum de deux isotypes"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 86.4
    }]
  },
  {
    "code" : "G257",
    "display" : "Identification des Ac anti-HLA de classe I par technique sensible sur cibles HLA isolées",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-03"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Indication : Post-greffe, selon recommandations de l'ABM. Prescriptions principalement en CHU, consultations externes ou hospitalisation. Technique sensible (ELISA, Multiplex, micropuces)"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 324.0
    }]
  },
  {
    "code" : "K198",
    "display" : "Dosage du complément total, voie classique, et voie alterne par technique non hémolytique",
    "designation" : [{
      "language" : "fr",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009",
        "display" : "Synonym"
      },
      "value" : "Dosage du complément total, voie classique, voie des lectines et voie alterne par technique non hémolytique"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une cotation par protéine. \nEn attente d'inscription à la NABM."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 10.8
    }]
  },
  {
    "code" : "E056",
    "display" : "Alpha-2-antiplasmine, activité amidolytique",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation. A réserver à centre de référence ou centre expert."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 18.9
    }]
  },
  {
    "code" : "E032",
    "display" : "Facteur de croissance : Thrombopoïétine",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 27.0
    }]
  },
  {
    "code" : "L045",
    "display" : "Glutathion érythrocytaire (réduit et oxydé) (sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "10-03"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 81.0
    }]
  },
  {
    "code" : "N355",
    "display" : "Quantification des T-cell Receptor Excision Circles (TRECs) sur cartes de Guthrie",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-3-1"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Dépistage néonatal des Déficits Immunitaires Combinés Sévères (DICS)"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 7.35
    }]
  },
  {
    "code" : "L178",
    "display" : "Oxalate",
    "property" : [{
      "code" : "parent",
      "valueCode" : "12"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 29.7
    }]
  },
  {
    "code" : "L069",
    "display" : "Allantoïne",
    "property" : [{
      "code" : "parent",
      "valueCode" : "10-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2022-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 27.0
    }]
  },
  {
    "code" : "F036",
    "display" : "Parasites du sang autres que hématozoaires",
    "property" : [{
      "code" : "parent",
      "valueCode" : "06-05"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2020-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 27.0
    }]
  },
  {
    "code" : "L021",
    "display" : "Glycérol (sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "12"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 8.1
    }]
  },
  {
    "code" : "I083",
    "display" : "Adiponectine haut poids moléculaire",
    "property" : [{
      "code" : "parent",
      "valueCode" : "09"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 37.8
    }]
  },
  {
    "code" : "G232",
    "display" : "Sérodiagnostic des Mimivirus, Mamavirus + Sputnik, virus T19, Sénégal Virus : titrage",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-07"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2022-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Non cumulable avec [G234]"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 16.2
    }]
  },
  {
    "code" : "K020",
    "display" : "Alpha 1 anti-trypsine (dosage) (liquides biologiques autres que le sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2022-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "En attente d'une modification potentielle du libellé de l'acte NABM [1807] prenant en compte les autres liquides biologiques que le sang."
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 10.8
    }]
  },
  {
    "code" : "M114",
    "display" : "Dosage spécifique d'une molécule non nommément inscrite  par une méthode de chromatographie couplée à la  spectrométrie de masse dans un liquide biologique",
    "property" : [{
      "code" : "parent",
      "valueCode" : "13-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 67.5
    }]
  },
  {
    "code" : "G123",
    "display" : "Toxoplasmose : charge immunitaire",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-06"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2020-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 27.0
    }]
  },
  {
    "code" : "N118",
    "display" : "Comparaison de souches bactériennes (Analyse des profils génomiques)  par RFLP et hybridation sur membrane (Southern blot), par souche et par analyse",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-2-1"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Inclus:Contrôle préanalytique +  extraction ADN + dosage ADN + digestion + gel agarose +  blot + hybridation membrane + analyse données"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 159.3
    }]
  },
  {
    "code" : "G256",
    "display" : "Identification des Ac anti-HLA de classe II par technique sensible sur cibles HLA combinées et/ou détermination PRA",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-03"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Indication : Post-greffe, selon recommandations de l'ABM. Prescriptions principalement en CHU, consultations externes ou hospitalisation. Technique sensible (ELISA, Multiplex, micropuces)"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 148.5
    }]
  },
  {
    "code" : "K044",
    "display" : "Phénotypage du composant C4 (protéines du complément)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2025-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Examen de 2nde ou 3ième intention ; réalisation technique et interprétation biologique nécessitant une expertise"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 48.6
    }]
  },
  {
    "code" : "LAHN",
    "display" : "LAHN",
    "property" : [{
      "code" : "child",
      "valueCode" : "05"
    },
    {
      "code" : "child",
      "valueCode" : "11"
    },
    {
      "code" : "child",
      "valueCode" : "12"
    },
    {
      "code" : "child",
      "valueCode" : "09"
    },
    {
      "code" : "child",
      "valueCode" : "01"
    },
    {
      "code" : "child",
      "valueCode" : "10"
    },
    {
      "code" : "child",
      "valueCode" : "06"
    },
    {
      "code" : "child",
      "valueCode" : "13"
    },
    {
      "code" : "child",
      "valueCode" : "14"
    },
    {
      "code" : "child",
      "valueCode" : "03"
    },
    {
      "code" : "child",
      "valueCode" : "07"
    },
    {
      "code" : "child",
      "valueCode" : "02"
    },
    {
      "code" : "child",
      "valueCode" : "15"
    },
    {
      "code" : "child",
      "valueCode" : "08"
    },
    {
      "code" : "child",
      "valueCode" : "04"
    },
    {
      "code" : "child",
      "valueCode" : "17"
    },
    {
      "code" : "child",
      "valueCode" : "16"
    }]
  },
  {
    "code" : "G014",
    "display" : "MAI nso : Ac anti-ADN natif par Immunofluorescence indirecte (IFI). Détermination d'un autre isotype que l'acte NABM [1454].",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Cas particulier des nouveaux traitements immunomodulateurs pouvant induire la synthèse de ce type d'anticorps. Intérêt = montrer que IgM peu de valeur. Non cumulable avec l'acte NABM [1455]"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 10.8
    }]
  },
  {
    "code" : "L048",
    "display" : "Glutathion réduit (sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "10-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 27.0
    }]
  },
  {
    "code" : "E077",
    "display" : "Facteur IX, Ag",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation. Recommandations du CRMH, en cours de rédaction, préconiseront le dosage antigènique en complément de la caractérisation phénotypique basée sur les mesures d’activité, afin de reconnaître les hémophiles CRM."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 37.8
    }]
  },
  {
    "code" : "L133",
    "display" : "Acides biliaires et phospholipides biliaires (autres liquides hors sang et urine)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "12"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2022-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 54.0
    }]
  },
  {
    "code" : "N530",
    "display" : "Réarrangement du gène ALK",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-3-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Dans la prise en charge du CBNPC, l'acte n'est pas à coder au RIHN, car il doit être intégré dans le panel, sauf en cas d'urgence, où une approche monogénique est à privilégier (source HAS)"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 110.7
    }]
  },
  {
    "code" : "N421",
    "display" : "Recherche de la mutation du transcrit de fusion BCR-ABL1",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-3-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "par RT-PCR (Comprenant le séquençage de 2 amplicons et l'expertise informatique,  cotation ne comprenant pas les étapes pré-analytiques : extraction, RT et qualification ainsi que la QPCR)"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 272.7
    }]
  },
  {
    "code" : "F033",
    "display" : "Recherche de microsporidies (selles, urines)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "06-05"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Les microscporidies sont des parasites dont le rôle en pathologie humaine a été démontré depuis 15 ans, son diagnostic repose sur des techniques de coloration élective ou par IFI :"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 16.2
    }]
  },
  {
    "code" : "P070",
    "display" : "Exploration du métabolisme énergétique mitochondrial par polarographie",
    "property" : [{
      "code" : "parent",
      "valueCode" : "16-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 324.0
    }]
  },
  {
    "code" : "I084",
    "display" : "Hepcidine (liquides biologiques) par spectrométrie de masse",
    "property" : [{
      "code" : "parent",
      "valueCode" : "09"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation. L'ELISA n'est pas une méthode qui répond aux besoins analytiques, en conséquence la spectrométrie de masse de dernière génération avec préfractionnement est la méthode analytique à utiliser et ceci pour tous les fluides biologiques."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 54.0
    }]
  },
  {
    "code" : "M115",
    "display" : "Dosage spécifique d'une molécule par une méthode chromatographique et  spectrométrie de masse dans un milieu biologique non liquide (cheveux, tissus…)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "13-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 108.0
    }]
  },
  {
    "code" : "I060",
    "display" : "Stéroïdogramme urinaire",
    "property" : [{
      "code" : "parent",
      "valueCode" : "09"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Spécialisé"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 405.0
    }]
  },
  {
    "code" : "G122",
    "display" : "Toxoplasmose: autres liquides biologiques (humeur aqueuse, LCR…..): deux techniques décelant des Ac de 2 isotypes dont IgG",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-06"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2020-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 16.2
    }]
  },
  {
    "code" : "G255",
    "display" : "Identification des Ac anti-HLA de classe I par technique sensible sur cibles HLA combinées et/ou détermination PRA",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-03"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Indication : Post-greffe, selon recommandations de l'ABM. Prescriptions principalement en CHU, consultations externes ou hospitalisation. Technique sensible (ELISA, Multiplex, micropuces)"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 148.5
    }]
  },
  {
    "code" : "K152",
    "display" : "Haptoglobine (dosage) (liquides biologiques autres que sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2022-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "En attente d'une modification potentielle du libellé de l'acte NABM [1813] prenant en compte les autres liquides biologiques que le sang."
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 9.45
    }]
  },
  {
    "code" : "N119",
    "display" : "Staphylocoque: recherche gène mecA directement à partir d’un prélèvement positif à  l’examen microscopique, par PCR temps réel",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-2-1"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Inclus: contrôle préanalytique + extraction par kit sur automate + 2 couples amorces  supplémentaires + 3 sondes marquées + PCR TR"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 97.2
    }]
  },
  {
    "code" : "V015",
    "display" : "Détection de mutations par expansion de microsatellites",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-3-1"
    },
    {
      "code" : "created",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Indications évaluées par la HAS permettant une exemption à la décote.\nEn attente d'inscription aux nomenclatures"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 137.7
    }]
  },
  {
    "code" : "K176",
    "display" : "Carnitine",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 32.4
    }]
  },
  {
    "code" : "E078",
    "display" : "Facteur tissulaire circulant, activité",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation. Isolement des microparticules, dosage chromogénique ou colorimétrique avec protéines purifiées. Marqueur d'hypercoagulabilité, associé aux pathologies thrombotiques et cancéreuses."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 135.0
    }]
  },
  {
    "code" : "E054",
    "display" : "Agrégation plaquettaire en plasma riche en plaquettes (PRP)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Agrégation plaquettaire en PRP . Une cotation par agent inducteur, (hors analyses du code [1011]). Utilité pour la poursuite du diagnostic de certaines  thrombopathies en accord avec les recommandations du centre de référence des pathologies plaquettaires. Egalement utilisé pour la surveillance des traitements anti-agrégants plaquettaires par inhibiteurs de P2Y12"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 13.5
    }]
  },
  {
    "code" : "E030",
    "display" : "Facteur de croissance : FGF",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 27.0
    }]
  },
  {
    "code" : "F034",
    "display" : "Helminthes : recherche dans selles par culture",
    "property" : [{
      "code" : "parent",
      "valueCode" : "06-05"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "La culture permet l'identification au niveau de l'espèce pour les ankylostomoses, et augmente la senibilité de la recherche de ces parasites digestifs."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 40.5
    }]
  },
  {
    "code" : "N531",
    "display" : "Recherche de mutation PI3KCA (2 exons)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-3-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Indication à préciser par l'INCa"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 116.1
    }]
  },
  {
    "code" : "L047",
    "display" : "Glutathion leucocytaire (sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "10-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2022-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 13.5
    }]
  },
  {
    "code" : "J064",
    "display" : "Superoxyde dismutase (SOD) érythrocytaire",
    "property" : [{
      "code" : "parent",
      "valueCode" : "10-03"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 32.4
    }]
  },
  {
    "code" : "J088",
    "display" : "Macro CK",
    "property" : [{
      "code" : "parent",
      "valueCode" : "10-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 27.0
    }]
  },
  {
    "code" : "I061",
    "display" : "Fibroblast Growth Factor 23 (plasma)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "09"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 24.3
    }]
  },
  {
    "code" : "G254",
    "display" : "Identification des Ac  anti-MICA",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-03"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "A réaliser au sein de laboratoires accrédités par l'European Federation for Imunogenetics (EFI)"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 74.25
    }]
  },
  {
    "code" : "M003",
    "display" : "Dosage d'un antipaludéen par une méthode chromatographique dans un liquide biologique",
    "property" : [{
      "code" : "parent",
      "valueCode" : "13-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 40.5
    }]
  },
  {
    "code" : "G012",
    "display" : "PR : recherche et/ ou titrage des anticorps anti-vimentine citrullinée",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Diagnostic de certaines formes de polyarthrite rhumatoïde"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 18.9
    }]
  },
  {
    "code" : "G230",
    "display" : "Recherche des anti-envoplakine en ELISA",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 18.9
    }]
  },
  {
    "code" : "M112",
    "display" : "Dosage spécifique d'une molécule non nommément inscrite  par une méthode immunochimique, dans un liquide biologique",
    "property" : [{
      "code" : "parent",
      "valueCode" : "13-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 16.2
    }]
  },
  {
    "code" : "K046",
    "display" : "IgG (liquides biologiques autres que le sang, ponctions)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-04"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "En attente d'une modification potentielle du libellé de l'acte NABM [1815] prenant en compte les autres liquides biologiques que le sang."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 10.8
    }]
  },
  {
    "code" : "G036",
    "display" : "hépatopathies : Ac anti-SLA (Soluble Liver Antigen)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 18.9
    }]
  },
  {
    "code" : "E099",
    "display" : "Plaquettes : Récepteurs membranaires (par Ac)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une cotation par Ac. Conférence de consensus \"standardisation de l'exploration des pathologies plaquettaires\" (février 2009) du Centre de référence des pathologies plaquettaires : examen de niveau 2 (confirmation d'une orientation diagnostique)"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 27.0
    }]
  },
  {
    "code" : "E075",
    "display" : "Endothelial cell Protein C Receptor (EPCR) soluble",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation. Marqueur d'activation endothéliale et d'hypercoaguabilité"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 37.8
    }]
  },
  {
    "code" : "E051",
    "display" : "Agrégation en plaquettes lavées Isolement des plaquettes",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une cotation par agent inducteur/dilution. Si [E054] anormal permet la confirmation du diagnostic  de thrombopathie ."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 40.5
    }]
  },
  {
    "code" : "F031",
    "display" : "Recherche d' Ag de parasites digestifs par EIA",
    "property" : [{
      "code" : "parent",
      "valueCode" : "06-05"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Meilleure sensibilité pour la détection des parasites digestifs responsables de diarrhées que l'examen microscopique"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 27.0
    }]
  },
  {
    "code" : "L111",
    "display" : "Glucose (liquides biologiques hors sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "12"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "En attente d'une modification potentielle du libellé de l'acte NABM [0552] prenant en compte les autres liquides biologiques que le sang."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 2.7
    }]
  },
  {
    "code" : "E160",
    "display" : "Rapport Aγ/Gγ par CLHP en phase inverse",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2019-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 16.2
    }]
  },
  {
    "code" : "L002",
    "display" : "Pyruvate (liquides biologiques)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "12"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Fusion des actes [L002 et L060]"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 16.2
    }]
  },
  {
    "code" : "L135",
    "display" : "Bilirubine (liquides biologiques autre que sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "12"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "En attente d'une modification potentielle du libellé de l'acte NABM [1601] prenant en compte les autres liquides biologiques que le sang."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 4.05
    }]
  },
  {
    "code" : "J065",
    "display" : "Superoxyde dismutase (SOD) tissulaire",
    "property" : [{
      "code" : "parent",
      "valueCode" : "10-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2022-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 64.8
    }]
  },
  {
    "code" : "G035",
    "display" : "Hépatopathies : Ac anti-cytosol / LKM (microsomes de foie et de rein)…",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Identification par technique utilisant un marqueur autre que fluorochrome. Méthode de référence."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 18.9
    }]
  },
  {
    "code" : "M113",
    "display" : "Dosage spécifique d'une molécule non nommément inscrite  par une méthode chromatographique hors spectrométrie de masse, dans un liquide biologique",
    "property" : [{
      "code" : "parent",
      "valueCode" : "13-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 32.4
    }]
  },
  {
    "code" : "K130",
    "display" : "Phénotypage de l'alpha 1 anti trypsine (focalisation isoélectrique)(sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 32.4
    }]
  },
  {
    "code" : "N117",
    "display" : "Comparaison de souches bactériennes (analyse des profils génomiques)  par éléctrophorèse en champ pulsé (PFGE), 1 enzyme de restriction, par souche et par analyse",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-2-1"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Inclus: Contrôle préanalytique +  préparation plug + lyse-extraction en plug + digestion en plug + électrophorèse gel champ pulsé + analyse des données"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 135.0
    }]
  },
  {
    "code" : "M004",
    "display" : "Dosage d'un antiviral autre qu'un antirétroviral par une méthode de chromatographie dans un liquide biologique",
    "property" : [{
      "code" : "parent",
      "valueCode" : "13-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "En attente d'une modification potentielle du libellé de l'acte NABM [4117] prenant en compte les autres liquides biologiques que le sang."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 37.8
    }]
  },
  {
    "code" : "G120",
    "display" : "Toxoplasmose : suivi du nourrisson ou du jeune enfant né d'une mère à risque toxoplasmique: sd de surveillance avec titrage des IgG et recherche de 2 autres isotypes dont obligatoirement IgM",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-06"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2020-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Si reprise en parallèle du sérum précédent : cotation globale, examen réservé à des laboratoires agréés ou spécialisés. Ne peut être cumulé avec l'acte [1437]. Importance du dépistage et du suivi spécialisé des nouveaus-né à risque de toxoplasmose congénitale de par son impact sur la prise en charge thérapeutique conformément aux recommandations du CNR des tooplasmoses:"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 32.4
    }]
  },
  {
    "code" : "K045",
    "display" : "Recherche et quantification d'anticorps anti-protéine du complément : anti-C1q, anti-C1inh ou anti-Facteur H",
    "designation" : [{
      "language" : "fr",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009",
        "display" : "Synonym"
      },
      "value" : "IgA (liquides biologiques autres que le sang, ponctions)"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-04"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "En attente d'une modification potentielle du libellé de l'acte NABM [1814] prenant en compte les autres liquides biologiques que le sang."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 10.8
    }]
  },
  {
    "code" : "G059",
    "display" : "MAI de peau : anticorps anti-desmogléines dosage par ELISA (Dsg1 ou Dsg3) (maximum 2 cotations)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 18.9
    }]
  },
  {
    "code" : "K021",
    "display" : "Alpha 1 glycoprotéine acide, orosomucoïde (liquides biologiques autres que le sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Fusion des actes [K021] et [K155] en attente d'une modification potentielle du libellé de l'acte NABM [1808] prenant en compte les autres liquides biologiques que le sang."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 9.45
    }]
  },
  {
    "code" : "K154",
    "display" : "Protéine C réactive (CRP) (liquides biologiques autres que sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "En attente d'une modification potentielle du libellé de l'acte NABM [1804] prenant en compte les autres liquides biologiques que le sang."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 5.67
    }]
  },
  {
    "code" : "L049",
    "display" : "Rétinoïques  (sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "12"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 54.0
    }]
  },
  {
    "code" : "F032",
    "display" : "Recherche de parasites par anticorps monoclonal (IFI) exclut la recherche de cryptosporidium",
    "property" : [{
      "code" : "parent",
      "valueCode" : "06-05"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "La détection de Giardia intestinalis par IFI est utilisée dans certains laboratoires"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 16.2
    }]
  },
  {
    "code" : "L110",
    "display" : "Cholestérol total (chol) (liquides biologiques hors sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "12"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "En attente d'une modification potentielle du libellé de l'acte NABM [0580] prenant en compte les autres liquides biologiques que le sang."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 1.35
    }]
  },
  {
    "code" : "L001",
    "display" : "Acéto-acétate (sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "12"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 8.1
    }]
  },
  {
    "code" : "N420",
    "display" : "Séquençage d'une cible d'immunogénétique (Ig/TCR) lors du diagnsotic d'une leucémie aigue lymphoblastique  ou d'un syndrome lymphoprolifératif",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-3-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Par cible"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 167.4
    }]
  },
  {
    "code" : "N154",
    "display" : "Typage moléculaire par microsatellite (par locus) (Inclus la PCR avec amorce fluorescente)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-2-3"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Même commentaire que pour l'acte [N151]"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 81.0
    }]
  },
  {
    "code" : "05-01",
    "display" : "cytologie - chimie - divers",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05"
    },
    {
      "code" : "type",
      "valueString" : "Sous-chapitre"
    },
    {
      "code" : "child",
      "valueCode" : "Q024"
    },
    {
      "code" : "child",
      "valueCode" : "E015"
    },
    {
      "code" : "child",
      "valueCode" : "E204"
    },
    {
      "code" : "child",
      "valueCode" : "E156"
    },
    {
      "code" : "child",
      "valueCode" : "E012"
    },
    {
      "code" : "child",
      "valueCode" : "G208"
    },
    {
      "code" : "child",
      "valueCode" : "E033"
    },
    {
      "code" : "child",
      "valueCode" : "E001"
    },
    {
      "code" : "child",
      "valueCode" : "E014"
    },
    {
      "code" : "child",
      "valueCode" : "E155"
    },
    {
      "code" : "child",
      "valueCode" : "Q044"
    },
    {
      "code" : "child",
      "valueCode" : "E035"
    },
    {
      "code" : "child",
      "valueCode" : "E003"
    },
    {
      "code" : "child",
      "valueCode" : "E030"
    },
    {
      "code" : "child",
      "valueCode" : "E149"
    },
    {
      "code" : "child",
      "valueCode" : "E200"
    },
    {
      "code" : "child",
      "valueCode" : "E157"
    },
    {
      "code" : "child",
      "valueCode" : "E125"
    },
    {
      "code" : "child",
      "valueCode" : "E018"
    },
    {
      "code" : "child",
      "valueCode" : "E032"
    },
    {
      "code" : "child",
      "valueCode" : "E040"
    },
    {
      "code" : "child",
      "valueCode" : "E034"
    },
    {
      "code" : "child",
      "valueCode" : "E160"
    }]
  },
  {
    "code" : "V012",
    "display" : "PCR classique ou temps réel quantitative simplex sur ADN infectieux (hors parasites et champignons) - Indications évaluées par la HAS",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2025-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Indications évaluées par la HAS permettant une exemption à la décote."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 75.6
    }]
  },
  {
    "code" : "E018",
    "display" : "Numération CD34",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation. Examen comportant des anticorps anti-CD34 et anti- CD45, un colorant vital et des billes de comptage."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 54.0
    }]
  },
  {
    "code" : "E102",
    "display" : "Prékallikréine, activité",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation.  A réserver à un centre de référence ou centre expert"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 13.5
    }]
  },
  {
    "code" : "06-05",
    "display" : "parasitologie",
    "property" : [{
      "code" : "parent",
      "valueCode" : "06"
    },
    {
      "code" : "type",
      "valueString" : "Sous-chapitre"
    },
    {
      "code" : "child",
      "valueCode" : "F041"
    },
    {
      "code" : "child",
      "valueCode" : "F032"
    },
    {
      "code" : "child",
      "valueCode" : "F101"
    },
    {
      "code" : "child",
      "valueCode" : "F039"
    },
    {
      "code" : "child",
      "valueCode" : "F034"
    },
    {
      "code" : "child",
      "valueCode" : "F031"
    },
    {
      "code" : "child",
      "valueCode" : "F038"
    },
    {
      "code" : "child",
      "valueCode" : "F033"
    },
    {
      "code" : "child",
      "valueCode" : "F036"
    }]
  },
  {
    "code" : "L084",
    "display" : "Densité urinaire mesurée par réfractomètre",
    "property" : [{
      "code" : "parent",
      "valueCode" : "12"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 2.7
    }]
  },
  {
    "code" : "A095",
    "display" : "Biopsie de greffon",
    "property" : [{
      "code" : "parent",
      "valueCode" : "01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 56.0
    }]
  },
  {
    "code" : "N131",
    "display" : "PCR classique ou temps réel qualitative multiplex pour < 10 couples d'amorces (ADN/ARN)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Cotation : par réaction PCR. Inclus tous types d’extraction, contrôle interne, contrôle cellulaire, analyse des données. <10 couples d'amorces. Selon indications des sociétés savantes."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 135.0
    }]
  },
  {
    "code" : "N155",
    "display" : "PCR classique ou temps réel quantitative multiplex pour < 10 couples d'amorces (ADN/ARN)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Cotation : par réaction PCR. Inclus tous types d’extraction, contrôle interne, contrôle cellulaire, analyse des données. <10 couples d'amorces. Selon indications des sociétés savantes."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 170.1
    }]
  },
  {
    "code" : "L083",
    "display" : "Dosage des sulfates par HPLC (urines)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "12"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 21.6
    }]
  },
  {
    "code" : "K306",
    "display" : "Dosage de l'hémoglobine libre plasmatique",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Indications : assistance cardio-respiratoire par circulation extra-corporelle"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 8.5
    }]
  },
  {
    "code" : "V011",
    "display" : "PCR classique ou temps réel qualitative simplex sur ADN -  infectieux (hors parasites et champignons)  - Indications évaluées par la HAS",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2025-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Indications évaluées par la HAS permettant une exemption à la décote."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 67.5
    }]
  },
  {
    "code" : "E128",
    "display" : "Protéine C Activité amidolytique.",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation. Examen non systématique, à faire si [0191] anormal. Fait partie du diagnostic de déficit en protéine C consitutionnel."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 13.5
    }]
  },
  {
    "code" : "N903",
    "display" : "PCR ADN simplex fluorescente et analyse sur séquenceur automatique",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-3"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation. Inclus: PCR + migration capillaire + analyse"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 37.8
    }]
  },
  {
    "code" : "G305",
    "display" : "Typage d'un locus HLA de classe I ou de classe II par Next Generation Sequencing (NGS)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-03"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "A réaliser au sein de laboratoires accrédités par l'European Federation for Imunogenetics (EFI)"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 270.0
    }]
  },
  {
    "code" : "06-04",
    "display" : "mycologie",
    "property" : [{
      "code" : "parent",
      "valueCode" : "06"
    },
    {
      "code" : "type",
      "valueString" : "Sous-chapitre"
    },
    {
      "code" : "child",
      "valueCode" : "F028"
    },
    {
      "code" : "child",
      "valueCode" : "F029"
    }]
  },
  {
    "code" : "N152",
    "display" : "Typage moléculaire par séquençage ADN double brin 1 séquence (Exclu: PCR diagnostique de détection initiale)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-2-3"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Même commentaire que pour l'acte [N151]"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 148.5
    }]
  },
  {
    "code" : "05-03",
    "display" : "immunohématologie",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05"
    },
    {
      "code" : "type",
      "valueString" : "Sous-chapitre"
    },
    {
      "code" : "child",
      "valueCode" : "E151"
    },
    {
      "code" : "child",
      "valueCode" : "E203"
    },
    {
      "code" : "child",
      "valueCode" : "E202"
    }]
  },
  {
    "code" : "G303",
    "display" : "Caractérisation de la cytotoxicité des Ac anti-HLA de classe I par technique sensible sur antigènes isolés ( C1q, C3d, classes et sous-classes Ig ….)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-03"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "A réaliser au sein de laboratoires accrédités par l'European Federation for Imunogenetics (EFI)"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 351.0
    }]
  },
  {
    "code" : "V014",
    "display" : "RT-PCR temps réel quantitative simplex en 1 étape ARN infectieux - Indications évaluées par la HAS",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2025-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Indications évaluées par la HAS permettant une exemption à la décote."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 116.1
    }]
  },
  {
    "code" : "E149",
    "display" : "Mise en évidence d'anomalies du cytosquelette du GR en cytométrie en flux",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 10.8
    }]
  },
  {
    "code" : "E015",
    "display" : "Hémoglobine + myoglobine ( recherche )",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 2.7
    }]
  },
  {
    "code" : "G304",
    "display" : "Caractérisation de la cytotoxicité des Ac anti-HLA de classe II par technique sensible sur antigènes isolés  ( C1q, C3d, classes et sous-classes Ig ….)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-03"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "A réaliser au sein de laboratoires accrédités par l'European Federation for Imunogenetics (EFI)"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 351.0
    }]
  },
  {
    "code" : "E100",
    "display" : "Plasminogène, activité amidolytique (dosage chromogénique)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation. Examen à réserver à un centre de référence ou centre expert pour le diagnostic de déficit en plasminogène associé aux conjonctivites ligneuses"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 27.0
    }]
  },
  {
    "code" : "L170",
    "display" : "Apolipoprotéine A2  (dosage)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "12"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Intérêt diagnostique et pratique hospitalière"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 10.8
    }]
  },
  {
    "code" : "05-02",
    "display" : "hémostase et coagulation",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05"
    },
    {
      "code" : "type",
      "valueString" : "Sous-chapitre"
    },
    {
      "code" : "child",
      "valueCode" : "E135"
    },
    {
      "code" : "child",
      "valueCode" : "E079"
    },
    {
      "code" : "child",
      "valueCode" : "E047"
    },
    {
      "code" : "child",
      "valueCode" : "E093"
    },
    {
      "code" : "child",
      "valueCode" : "E148"
    },
    {
      "code" : "child",
      "valueCode" : "E116"
    },
    {
      "code" : "child",
      "valueCode" : "E130"
    },
    {
      "code" : "child",
      "valueCode" : "E082"
    },
    {
      "code" : "child",
      "valueCode" : "E137"
    },
    {
      "code" : "child",
      "valueCode" : "E049"
    },
    {
      "code" : "child",
      "valueCode" : "E095"
    },
    {
      "code" : "child",
      "valueCode" : "E063"
    },
    {
      "code" : "child",
      "valueCode" : "E118"
    },
    {
      "code" : "child",
      "valueCode" : "E132"
    },
    {
      "code" : "child",
      "valueCode" : "E100"
    },
    {
      "code" : "child",
      "valueCode" : "E044"
    },
    {
      "code" : "child",
      "valueCode" : "E201"
    },
    {
      "code" : "child",
      "valueCode" : "E057"
    },
    {
      "code" : "child",
      "valueCode" : "E071"
    },
    {
      "code" : "child",
      "valueCode" : "E140"
    },
    {
      "code" : "child",
      "valueCode" : "E084"
    },
    {
      "code" : "child",
      "valueCode" : "E139"
    },
    {
      "code" : "child",
      "valueCode" : "E107"
    },
    {
      "code" : "child",
      "valueCode" : "E097"
    },
    {
      "code" : "child",
      "valueCode" : "E134"
    },
    {
      "code" : "child",
      "valueCode" : "E102"
    },
    {
      "code" : "child",
      "valueCode" : "E078"
    },
    {
      "code" : "child",
      "valueCode" : "E046"
    },
    {
      "code" : "child",
      "valueCode" : "E092"
    },
    {
      "code" : "child",
      "valueCode" : "E115"
    },
    {
      "code" : "child",
      "valueCode" : "E073"
    },
    {
      "code" : "child",
      "valueCode" : "E128"
    },
    {
      "code" : "child",
      "valueCode" : "E110"
    },
    {
      "code" : "child",
      "valueCode" : "E086"
    },
    {
      "code" : "child",
      "valueCode" : "E054"
    },
    {
      "code" : "child",
      "valueCode" : "E099"
    },
    {
      "code" : "child",
      "valueCode" : "E067"
    },
    {
      "code" : "child",
      "valueCode" : "E081"
    },
    {
      "code" : "child",
      "valueCode" : "E136"
    },
    {
      "code" : "child",
      "valueCode" : "E048"
    },
    {
      "code" : "child",
      "valueCode" : "E094"
    },
    {
      "code" : "child",
      "valueCode" : "E117"
    },
    {
      "code" : "child",
      "valueCode" : "E131"
    },
    {
      "code" : "child",
      "valueCode" : "E075"
    },
    {
      "code" : "child",
      "valueCode" : "E043"
    },
    {
      "code" : "child",
      "valueCode" : "E112"
    },
    {
      "code" : "child",
      "valueCode" : "E056"
    },
    {
      "code" : "child",
      "valueCode" : "E070"
    },
    {
      "code" : "child",
      "valueCode" : "E051"
    },
    {
      "code" : "child",
      "valueCode" : "E138"
    },
    {
      "code" : "child",
      "valueCode" : "E106"
    },
    {
      "code" : "child",
      "valueCode" : "E152"
    },
    {
      "code" : "child",
      "valueCode" : "E120"
    },
    {
      "code" : "child",
      "valueCode" : "E096"
    },
    {
      "code" : "child",
      "valueCode" : "E064"
    },
    {
      "code" : "child",
      "valueCode" : "E119"
    },
    {
      "code" : "child",
      "valueCode" : "E101"
    },
    {
      "code" : "child",
      "valueCode" : "E077"
    },
    {
      "code" : "child",
      "valueCode" : "E091"
    },
    {
      "code" : "child",
      "valueCode" : "E114"
    },
    {
      "code" : "child",
      "valueCode" : "E108"
    },
    {
      "code" : "child",
      "valueCode" : "E154"
    },
    {
      "code" : "child",
      "valueCode" : "E122"
    },
    {
      "code" : "child",
      "valueCode" : "E098"
    }]
  },
  {
    "code" : "V013",
    "display" : "RT-PCR temps réel qualitative simplex en 1 étape sur ARN infectieux - Indications évaluées par la HAS",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2025-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Indications évaluées par la HAS permettant une exemption à la décote."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 108.0
    }]
  },
  {
    "code" : "E125",
    "display" : "PEC (progéniteurs endothéliaux circulants) : quantification par cytométrie en flux",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 162.0
    }]
  },
  {
    "code" : "G218",
    "display" : "Hépatite E (VHE) : sd : IgM anti-VHE par EIA",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-07"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2020-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 18.9
    }]
  },
  {
    "code" : "E101",
    "display" : "Plasminogène, Ag",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation. A réserver à un centre de référence ou centre expert si l'acte [E100] est diminué"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 37.8
    }]
  },
  {
    "code" : "K081",
    "display" : "Quantification par dosage protéique d'une cryoglobuline ou d'un cryofibrinogène",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-04"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 10.8
    }]
  },
  {
    "code" : "K190",
    "display" : "Chromogranine (dosage) (liquides biologiques autres que sang)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-07"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "En attente d'une modification potentielle du libellé de l'acte NABM [1824] prenant en compte les autres liquides biologiques que le sang."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 28.35
    }]
  },
  {
    "code" : "L085",
    "display" : "Oses (recherche) (selles)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "12"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 21.6
    }]
  },
  {
    "code" : "06-06",
    "display" : "sensibilité des bactéries et des champignons aux antibiotiques",
    "property" : [{
      "code" : "parent",
      "valueCode" : "06"
    },
    {
      "code" : "type",
      "valueString" : "Sous-chapitre"
    },
    {
      "code" : "child",
      "valueCode" : "F046"
    }]
  },
  {
    "code" : "07-06",
    "display" : "sérologie parasitaire",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07"
    },
    {
      "code" : "type",
      "valueString" : "Sous-chapitre"
    },
    {
      "code" : "child",
      "valueCode" : "G111"
    },
    {
      "code" : "child",
      "valueCode" : "G126"
    },
    {
      "code" : "child",
      "valueCode" : "G110"
    },
    {
      "code" : "child",
      "valueCode" : "G125"
    },
    {
      "code" : "child",
      "valueCode" : "G207"
    },
    {
      "code" : "child",
      "valueCode" : "G215"
    },
    {
      "code" : "child",
      "valueCode" : "G116"
    },
    {
      "code" : "child",
      "valueCode" : "G124"
    },
    {
      "code" : "child",
      "valueCode" : "G118"
    },
    {
      "code" : "child",
      "valueCode" : "G115"
    },
    {
      "code" : "child",
      "valueCode" : "G123"
    },
    {
      "code" : "child",
      "valueCode" : "G117"
    },
    {
      "code" : "child",
      "valueCode" : "G120"
    },
    {
      "code" : "child",
      "valueCode" : "G119"
    },
    {
      "code" : "child",
      "valueCode" : "G114"
    },
    {
      "code" : "child",
      "valueCode" : "G122"
    }]
  },
  {
    "code" : "N134",
    "display" : "PCR classique ou temps réel qualitative simplex sur ADN infectieux (hors parasites et champignons)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Inclus tous types d’extraction, contrôle interne, contrôle cellulaire, analyse des données. Selon indications des sociétés savantes. Hors actes inscrits à la NABM [4101], [4102], [5256], [4120], [4122], [4128], [0805], [0806], [4123], [4124], [4125], [4126], [4118], [4119], [4127], [4121], [5258], [5257], [1307], [5262], [4718], [5259], [1254], [3254], [5260], [4273],,[1255], [3255], [5261], [5263], [5264], [5265], [4506]  [5269], [5301], [5302], [5303], [5271], [5272], [5237], [5273]"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 67.5
    }]
  },
  {
    "code" : "06-01-02",
    "display" : "Recherche d'une bactérie nommément désignée",
    "property" : [{
      "code" : "parent",
      "valueCode" : "06-01"
    },
    {
      "code" : "type",
      "valueString" : "Sous-chapitre"
    }]
  },
  {
    "code" : "K193",
    "display" : "Progranuline (plasma et LCR)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Intérêt dans les démences fronto-temporales. Par méthode ELISA"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 67.5
    }]
  },
  {
    "code" : "G301",
    "display" : "Recherche de la présence ou affirmation de l'absence d'un allèle HLA (liste restreinte des indications de prescription)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-03"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Acte permettant de recentrer les actes NABM [1180] et [1181]"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 47.25
    }]
  },
  {
    "code" : "06-01",
    "display" : "examens microbiologiques d'un ou plusieurs prélèvements de même nature",
    "property" : [{
      "code" : "parent",
      "valueCode" : "06"
    },
    {
      "code" : "type",
      "valueString" : "Sous-chapitre"
    },
    {
      "code" : "child",
      "valueCode" : "06-01-01"
    },
    {
      "code" : "child",
      "valueCode" : "F004"
    },
    {
      "code" : "child",
      "valueCode" : "06-01-02"
    }]
  },
  {
    "code" : "A091",
    "display" : "Autopsie enfant (> 4 jours et < 15 ans et 3 mois) :  bloc viscéral",
    "property" : [{
      "code" : "parent",
      "valueCode" : "01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Examen externe, prélèvement et dissection du bloc viscéral, examen macroscopique et histologique après bloc paraffine des organes individualisés"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 1337.0
    }]
  },
  {
    "code" : "E122",
    "display" : "Glycoprotéine V (GPV) soluble",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation. Marqueur d'activation de la coagulation car clivage de la GPV par la thrombine"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 27.0
    }]
  },
  {
    "code" : "N352",
    "display" : "Forfait séquençage haut débit (NGS) > 100 kb et < 500 kb (cas index)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-3-1"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Comprend le forfait \"accueil  cas index\" (BHN 370), le forfait analytique NGS > 100 kb et < 500 kb (BHN 6000) et le forfait \"interprétation\" (BHN 1800). Le détail de ces forfaits est précisé dans le document  de l'ANPGM en Annexe du RIHN. Concerne un nombre limité de maladie héréditaires pour lesquelles cet examen est nécessaire au diagnostic (cf. arbres décisionnels de l'ANPGM)"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 2205.9
    }]
  },
  {
    "code" : "L173",
    "display" : "Apolipoprotéine C3 (dosage)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "12"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Pratique hospitalière"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 10.8
    }]
  },
  {
    "code" : "L064",
    "display" : "Ammonium",
    "property" : [{
      "code" : "parent",
      "valueCode" : "12"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2019-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 13.5
    }]
  },
  {
    "code" : "07-07",
    "display" : "sérologie virale",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07"
    },
    {
      "code" : "type",
      "valueString" : "Sous-chapitre"
    },
    {
      "code" : "child",
      "valueCode" : "G236"
    },
    {
      "code" : "child",
      "valueCode" : "G194"
    },
    {
      "code" : "child",
      "valueCode" : "G132"
    },
    {
      "code" : "child",
      "valueCode" : "G233"
    },
    {
      "code" : "child",
      "valueCode" : "G214"
    },
    {
      "code" : "child",
      "valueCode" : "G235"
    },
    {
      "code" : "child",
      "valueCode" : "G128"
    },
    {
      "code" : "child",
      "valueCode" : "G136"
    },
    {
      "code" : "child",
      "valueCode" : "G131"
    },
    {
      "code" : "child",
      "valueCode" : "G232"
    },
    {
      "code" : "child",
      "valueCode" : "G133"
    },
    {
      "code" : "child",
      "valueCode" : "G234"
    },
    {
      "code" : "child",
      "valueCode" : "G218"
    }]
  },
  {
    "code" : "N135",
    "display" : "PCR classique ou temps réel quantitative simplex sur ADN infectieux (hors parasites et champignons)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Inclus tous types d’extraction, contrôle interne, contrôle cellulaire, analyse des données. Selon indications des sociétés savantes. Hors actes inscrits à la NABM [4101], [4102], [5256], [4120], [4122], [4128], [0805], [0806], [4123], [4124], [4125], [4126], [4118], [4119], [4127], [4121], [5258], [5257], [1307], [5262], [4718], [5259], [1254], [3254], [5260], [4273], [1255], [3255], [5261], [5263], [5264], [5265],  [4506], [5269], [5301], [5302], [5303], [5271], [5272], [5237], [5273]"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 75.6
    }]
  },
  {
    "code" : "06-01-01",
    "display" : "Examens affectés d'une codification forfaitaire",
    "property" : [{
      "code" : "parent",
      "valueCode" : "06-01"
    },
    {
      "code" : "type",
      "valueString" : "Sous-chapitre"
    }]
  },
  {
    "code" : "K083",
    "display" : "Analyse immunohistochimique d'une cryoglobuline isolée ou d'un cryofibrinogène",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-04"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Fusion des actes [K083] et [K145]"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 70.2
    }]
  },
  {
    "code" : "G215",
    "display" : "Infections Fongiques Invasives (IFI): recherche de béta-glucanes circulants",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-06"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "La détection des glucanes augmente le sensibilité au diagnostic des infections fongiques; c'est un outil  de diagnostic \"panfongique\" très efficient pour les cliniciens dans le diagnostic des PcP, des candidémies et  d'infections fongiques rares."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 27.0
    }]
  },
  {
    "code" : "G300",
    "display" : "Typage en urgence d'un locus HLA de classe I ou de classe II en biologie moléculaire, résolution basse ou intermédiaire",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-03"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Selon standards EFI"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 270.0
    }]
  },
  {
    "code" : "E148",
    "display" : "Thromboélastogramme",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Thromboélastographie/Thromboélastométrie rotative. Une seule cotation."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 18.9
    }]
  },
  {
    "code" : "E014",
    "display" : "Hémoglobine (autres liquides biologiques)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 10.8
    }]
  },
  {
    "code" : "G216",
    "display" : "Diphtérie : sérologie (par EIA)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-05"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 18.9
    }]
  },
  {
    "code" : "K192",
    "display" : "Ostéopontine plasmatique (dosage)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-07"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2022-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Spécialisé"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 35.1
    }]
  },
  {
    "code" : "N353",
    "display" : "Forfait recherche chez apparenté d'une mutation identifiée par NGS",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-3-1"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Comprend le forfait \"accueil  apprenté\" (BHN 220)et le forfait \"Recherche chez un apparenté  d'une mutation identifiée par NGS\"  (BHN 500). Le détail de ces forfaits est précisé dans le document  de l'ANPGM en Annexe du RIHN. Concerne un nombre limité de maladie héréditaires pour lesquelles cet examen est nécessaire au diagnostic (cf. arbres décisionnels de l'ANPGM)"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 194.4
    }]
  },
  {
    "code" : "L172",
    "display" : "Apolipoprotéine C2  (dosage)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "12"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Intérêt diagnostique et pratique hospitalière"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 10.8
    }]
  },
  {
    "code" : "A092",
    "display" : "Autopsie enfant (> 4 jours et < 15 ans et 3 mois) : cerveau",
    "property" : [{
      "code" : "parent",
      "valueCode" : "01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Examen macroscopique et histologique après bloc paraffine du cerveau"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 33.6
    }]
  },
  {
    "code" : "L087",
    "display" : "Calprotectine fécale (selles)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "12"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2025-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "1 recueil unique"
    },
    {
      "code" : "deprecated",
      "valueBoolean" : true
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 43.2
    }]
  },
  {
    "code" : "07-04",
    "display" : "Immunité-cellulaire",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07"
    },
    {
      "code" : "type",
      "valueString" : "Sous-chapitre"
    },
    {
      "code" : "child",
      "valueCode" : "G079"
    },
    {
      "code" : "child",
      "valueCode" : "G074"
    },
    {
      "code" : "child",
      "valueCode" : "G068"
    },
    {
      "code" : "child",
      "valueCode" : "G063"
    },
    {
      "code" : "child",
      "valueCode" : "G076"
    },
    {
      "code" : "child",
      "valueCode" : "G090"
    },
    {
      "code" : "child",
      "valueCode" : "G089"
    },
    {
      "code" : "child",
      "valueCode" : "G140"
    },
    {
      "code" : "child",
      "valueCode" : "G139"
    },
    {
      "code" : "child",
      "valueCode" : "G065"
    },
    {
      "code" : "child",
      "valueCode" : "G078"
    },
    {
      "code" : "child",
      "valueCode" : "G073"
    },
    {
      "code" : "child",
      "valueCode" : "G067"
    },
    {
      "code" : "child",
      "valueCode" : "G081"
    },
    {
      "code" : "child",
      "valueCode" : "G075"
    },
    {
      "code" : "child",
      "valueCode" : "G200"
    },
    {
      "code" : "child",
      "valueCode" : "G088"
    },
    {
      "code" : "child",
      "valueCode" : "G070"
    },
    {
      "code" : "child",
      "valueCode" : "G213"
    },
    {
      "code" : "child",
      "valueCode" : "G072"
    },
    {
      "code" : "child",
      "valueCode" : "G085"
    },
    {
      "code" : "child",
      "valueCode" : "G210"
    }]
  },
  {
    "code" : "B050",
    "display" : "Réinterprétation d'une puce à ADN",
    "property" : [{
      "code" : "parent",
      "valueCode" : "02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Comprend la réanalyse des données d'une CGH déjà réalisée et la rédaction d'un nouveau compte rendu / d'un courrier si l'interprétation ne change pas. BHN 800 pour cet acte en raison du temps médical requis estimé à environ 2h en moyenne."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 216.0
    }]
  },
  {
    "code" : "N156",
    "display" : "PCR classique ou temps réel qualitative multiplex pour ≥ 10 couples d'amorces (ADN/ARN)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Cotation : par réaction PCR. Inclus tous types d’extraction, contrôle interne, contrôle cellulaire, analyse des données. ≥10 couples d'amorces. Selon indications des sociétés savantes."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 270.0
    }]
  },
  {
    "code" : "K086",
    "display" : "Recherche d'une maladie des chaînes lourdes (alpha, mu, gamma) par technique d'immunoselection.",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-04"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Acte de seconde intention permettant d'affirmer le diagnostic de maladie des chaines lourdes ; réalisation technique et interprétation biologique nécessitant une expertise"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 48.6
    }]
  },
  {
    "code" : "V010",
    "display" : "PCR classique ou temps réel quantitative multiplex pour ≥ 10 couples d'amorces (ADN/ARN)  - Indications évaluées par la HAS",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2025-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Indications évaluées par la HAS permettant une exemption à la décote."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 340.2
    }]
  },
  {
    "code" : "G214",
    "display" : "Recherche d’anticorps IgG par IF (Générique tous virus)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-07"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 16.2
    }]
  },
  {
    "code" : "E035",
    "display" : "Hémoglobinopathies : phosphatidylsérine érythrocytaire (cytométrie en flux)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 27.0
    }]
  },
  {
    "code" : "G239",
    "display" : "Sérodiagnostic des Bartonella et Rickettsia non incluses à la NABM , Borrelia, Ehrlichia, Orientia, Wolbachia, Parachlamydia acanthamoebae Hall's coccus et Protéobacteria BN9 : titrage + itératif",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-05"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Non cumulable avec l'acte [G237]"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 24.3
    }]
  },
  {
    "code" : "N904",
    "display" : "PCR ELISA",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-3"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation. PCR et hybridation biopuce de haute densité. Inclus: N901 + révélation microplaque + analyse des résultats"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 54.0
    }]
  },
  {
    "code" : "E120",
    "display" : "tissue Plasminogen Activator (t-PA), Ag",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation. Dépistage d’une anomalie de la fibrinolyse dans un contexte thrombotique\nDépistage d’une hyperfibrinolyse dans un contexte de pathologie hémorragique constitutionnelle"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 37.8
    }]
  },
  {
    "code" : "06-03",
    "display" : "actes isolés - examens divers - bactériologie",
    "property" : [{
      "code" : "parent",
      "valueCode" : "06"
    },
    {
      "code" : "type",
      "valueString" : "Sous-chapitre"
    },
    {
      "code" : "child",
      "valueCode" : "F062"
    },
    {
      "code" : "child",
      "valueCode" : "F025"
    }]
  },
  {
    "code" : "A093",
    "display" : "Autopsie enfant (> 4jours et < 15 ans et 3 mois) : moelle épinière",
    "property" : [{
      "code" : "parent",
      "valueCode" : "01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Examen macroscopique et histologique après bloc paraffine de la moelle épinière"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 33.6
    }]
  },
  {
    "code" : "L042",
    "display" : "Bêta carotène",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-06"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 54.0
    }]
  },
  {
    "code" : "N350",
    "display" : "Forfait  séquençage haut débit (NGS) < 20 kb (cas index)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-3-1"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Comprend le forfait \"accueil  cas index\" (BHN 370), le forfait analytique NGS < 20 kb (BHN 2000) et le forfait \"interprétation\" (BHN 400). Le détail de ces forfaits est précisé dans le document  de l'ANPGM en Annexe du RIHN. Concerne un nombre limité de maladie héréditaires pour lesquelles cet examen est nécessaire au diagnostic (cf. arbres décisionnels de l'ANPGM)"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 882.9
    }]
  },
  {
    "code" : "07-05",
    "display" : "sérologie bactérienne",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07"
    },
    {
      "code" : "type",
      "valueString" : "Sous-chapitre"
    },
    {
      "code" : "child",
      "valueCode" : "G238"
    },
    {
      "code" : "child",
      "valueCode" : "G191"
    },
    {
      "code" : "child",
      "valueCode" : "G216"
    },
    {
      "code" : "child",
      "valueCode" : "G237"
    },
    {
      "code" : "child",
      "valueCode" : "G190"
    },
    {
      "code" : "child",
      "valueCode" : "G189"
    },
    {
      "code" : "child",
      "valueCode" : "G240"
    },
    {
      "code" : "child",
      "valueCode" : "G239"
    }]
  },
  {
    "code" : "N133",
    "display" : "PCR ADN viral \"classique\" (sérique, plasmatique, LCR, cellules, tissu, biopsie…): Qualitative avec extraction par kit (colonnes), 2 couples d’amorces et hybridation sur plaque",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-2-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Inclus: analyse des données"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 99.9
    }]
  },
  {
    "code" : "N157",
    "display" : "PCR classique ou temps réel quantitative multiplex pour ≥ 10 couples d'amorces (ADN/ARN)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-2"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Cotation : par réaction PCR. Inclus tous types d’extraction, contrôle interne, contrôle cellulaire, analyse des données.  ≥10 couples d'amorces. Selon indications des sociétés savantes."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 340.2
    }]
  },
  {
    "code" : "K085",
    "display" : "Dépistage d'un cryofibrinogène après séparation extemporanée du plasma (non héparine) à la température de 37°C",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-04"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 5.4
    }]
  },
  {
    "code" : "K194",
    "display" : "C1q, C5, C6, C7, C8, C9, Facteur H, Facteur I, C4Bp, properdine, antigénémie",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une cotation par protéine.\nEn attente d'inscription à la NABM"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 18.9
    }]
  },
  {
    "code" : "N906",
    "display" : "Détection de mutations ponctuelles par Sanger",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-1"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Pour analyse à faible débit. Réaction de séquençage double brin d'un produit PCR  (< 800 nt) (Inclus: PCR + purification de la PCR + quantification sur gel + réaction de séquençage et l'analyse)"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 153.9
    }]
  },
  {
    "code" : "G237",
    "display" : "Sérodiagnostic des Bartonella et Rickettsia non incluses à la NABM , Borrelia, Ehrlichia, Orientia, Wolbachia, Parachlamydia acanthamoebae Hall's coccus et Protéobacteria BN9 : titrage",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-05"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Non cumulable avec l'acte [G239]"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 16.2
    }]
  },
  {
    "code" : "G213",
    "display" : "Etude microscopie optique du cheveu (sans coloration)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-04"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Indication: dans le cadre du diagnostic d’un Déficit Immunitaire Primitif (DIP). Acte devant être encadré pour sa prescription et les étapes pré et post analytiques"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 14.85
    }]
  },
  {
    "code" : "M020",
    "display" : "Spéciation par couplage HPLC / ICP-MS",
    "property" : [{
      "code" : "parent",
      "valueCode" : "13-02"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 108.0
    }]
  },
  {
    "code" : "06-02",
    "display" : "actes isolés - examens divers - examens microscopiques",
    "property" : [{
      "code" : "parent",
      "valueCode" : "06"
    },
    {
      "code" : "type",
      "valueString" : "Sous-chapitre"
    },
    {
      "code" : "child",
      "valueCode" : "F063"
    }]
  },
  {
    "code" : "G238",
    "display" : "Sérodiagnostic de dépistage des Bartonella et Rickettsia non incluses à la NABM , Borrelia, Ehrlichia, Orientia, Wolbachia, Parachlamydia acanthamoebae Hall's coccus et Protéobacteria BN9",
    "property" : [{
      "code" : "parent",
      "valueCode" : "07-05"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 10.8
    }]
  },
  {
    "code" : "E012",
    "display" : "Recherche des pathologies constitutionnelles de la membrane du GR",
    "property" : [{
      "code" : "parent",
      "valueCode" : "05-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une seule cotation. Numération formule, ektacytométrie, commentaire cytologique, EMA non systématique"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 81.0
    }]
  },
  {
    "code" : "L150",
    "display" : "Exploration d'une hypobétalipoprotéine, recherche d'une Apo B tronquée",
    "property" : [{
      "code" : "parent",
      "valueCode" : "16-01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 209.25
    }]
  },
  {
    "code" : "F101",
    "display" : "Etude in vitro de chimiosensiblité de parasite",
    "property" : [{
      "code" : "parent",
      "valueCode" : "06-05"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "La surveillance de la chimiosensiblité parasitaire est un outil indispensable pour l'identification et la prise en charge de nouvelles résistances"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 108.0
    }]
  },
  {
    "code" : "L041",
    "display" : "Acides biliaires totaux (liquides biologiques, ponctions)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "12"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Fusion des actes[L041], [L076], [L131] et [L134]"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 13.5
    }]
  },
  {
    "code" : "N351",
    "display" : "Forfait séquençage haut débit (NGS) > 20 kb et < 100 kb (cas index)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "14-3-1"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Comprend le forfait \"accueil  cas index\" (BHN 370), le forfait analytique > 20 kb et < 100 kb (BHN 4000) et le forfait \"interprétation\" (BHN 1200). Le détail de ces forfaits est précisé dans le document  de l'ANPGM en Annexe du RIHN. Concerne un nombre limité de maladie héréditaires pour lesquelles cet examen est nécessaire au diagnostic (cf. arbres décisionnels de l'ANPGM)"
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 1503.9
    }]
  },
  {
    "code" : "A070",
    "display" : "Examen par HIS, FISH, SISH  (hors indications CCAM et autres actes inscrits au RIHN ou sur la liste complémentaire)",
    "property" : [{
      "code" : "parent",
      "valueCode" : "01"
    },
    {
      "code" : "created",
      "valueDateTime" : "2018-01-01T00:00:00+00:00"
    },
    {
      "code" : "modified",
      "valueDateTime" : "2026-01-01T00:00:00+00:00"
    },
    {
      "code" : "type",
      "valueString" : "code"
    },
    {
      "code" : "note",
      "valueString" : "Une cotation par sonde. Avec quantification. Selon Indications définies par CNPath. Pour mémoire, les indications prises en charge au titre de la CCAM sont : HER2 dans le cadre du cancer du sein, EBER (Virus EBV) dans le cadre des carcinomes de site primitif inconnu et oncogène N+ myc dans le neuroblastome de l’enfant."
    },
    {
      "code" : "prixMaximal",
      "valueDecimal" : 95.2
    }]
  }]
}

```
