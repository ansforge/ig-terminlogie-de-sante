# Identifiants - Terminologies de Santé v1.10.0

## Identifiants

 
There is no translation page available for the current page, so it has been rendered in the default language 

Les systèmes d'identification définis ici sont destinés à la commodité des implémenteurs HL7. Ces ressources ont pour objectif particulier de capturer, pour un accès facile, des informations de métadonnées descriptives sur chaque système d'identifiants enregistré ici.

* [ADICAP](NamingSystem-ADICAP.md)
* [IHERoleCode_Vocabulary](NamingSystem-IHERoleCodeVocabulary.md)
* [LOINC](NamingSystem-v3-loinc.md)
* [MEDDRA](NamingSystem-MEDDRA.md)
* [NCIT](NamingSystem-NCIT.md)
* [PCS](NamingSystem-PCS.md)
* [SERAFIN](NamingSystem-SERAFIN.md)
* [Snomed_CT_core_900000000000207008](NamingSystem-Snomed-CT-core.md)
* [UCUM](NamingSystem-UCUM.md)

